import React, {useState, useEffect} from "react";
import ViolationFunc from "../services/Functions";
import {IonButton, IonButtons, IonBackButton, IonCheckbox, IonContent, IonDatetime, IonHeader, IonItem, IonItemDivider, IonList, IonModal, IonPage, IonTitle, IonToolbar, IonIcon, IonLoading} from "@ionic/react";
import {Chart as ChartJS, ArcElement, Tooltip, Legend, Title } from "chart.js";
import {Pie} from "react-chartjs-2";
import "../theme/Charts.css";


// all the props that come from Charts-menu.js
interface Props {
  allVio: boolean;
  overOcc: boolean;
  illCons: boolean;
  sanitation: boolean;
  maintenance: boolean;
  illSign: boolean;
  Vis: boolean;
  row: boolean;
  permit: boolean;
  other: boolean;
  SortBy: string;
  startDate: string;
  endDate: string;
  table: number;
}



ChartJS.register(ArcElement, Tooltip, Legend, Title);



const ShowPieChart: React.FC<Props> = (props) => {
  const [LengendLabel, setLegendLabel] = useState<string>(""); // useState for the graph's title
  const [Numbers, setNumbers] = useState<number[]>([]); // useState for the graph's data
  const [Labels, setLabels] = useState<any[]>([]); // useState for the graph's legend
  // backColor aand borderColor are 2 useStates that by default will have  9 colors that the pie chart will use in graphing. Most of the pie charting options use at most 9, so having 9 by default would be ideal. If more is needed then the colors are generated with function "addMoreColor()"
  const [backColor, setBackColor] = useState<string[]>([
    'rgba(153, 0, 0, 0.2)',
    'rgba(255, 51, 255, 0.2)',
    'rgba(0, 76, 153, 0.2)',
    'rgba(255, 255, 0, 0.2)',
    'rgba(0, 255, 0, 0.2)',
    'rgba(255, 128, 0, 0.2)',
    'rgba(51, 255, 255, 0.2)',
    'rgba(127, 0, 255, 0.2)',
    'rgba(76, 153, 0, 0.2)',
  ]);
  const [borderColor, setBorderColor] = useState<string[]>([
    'rgba(153, 0, 0, 1)',
    'rgba(255, 51, 255, 1)',
    'rgba(0, 76, 153, 1)',
    'rgba(255, 255, 0, 1)',
    'rgba(0, 255, 0, 1)',
    'rgba(255, 128, 0, 1)',
    'rgba(51, 255, 255, 1)',
    'rgba(127, 0, 255, 1)',
    'rgba(76, 153, 0, 1)',
  ]);
  const [datasetLabel, setDatasetLabel] = useState<string>(""); // useState for the title of the legend 
  const [showLoading, setShowLoading] = useState<boolean>(true); // useState for detailing if the loading popup will occur


  useEffect(() => {
    grabNumbers(); // immediately start making make the data and labels for pie chart
  }, []);


   const grabNumbers = () => {
     // call the function for the webhook to get the data from MongoDB for a chart that generates the frequencies of the different violation types
    if(props.SortBy == "Only Violations"){
    ViolationFunc.getPieNumbers(props.allVio, props.overOcc, props.illCons, props.illSign, props.sanitation, props.maintenance, props.Vis, props.row, props.permit, props.other, props.startDate, props.endDate, props.table)
      .then(response => {
        setNumbers(createData(response.data)); // format the data from the response to be usable for the pie chart
        setLabels(createLabels()); // format the labels that are needed for the chart. Make only what is needed from the props
      })
      .catch(e => { // error catch
        console.log(e);
      });
    }
    // call function for the webhook associated that will get the number of violaations at each address
    if(props.SortBy == "Addresses"){
      ViolationFunc.getPieByAddr(props.startDate, props.endDate, props.table).then(
        response => {
          createDataAndLabels(response.data); // format the data to be usable for the pie chart and make the labels associated with those numbers
        }).catch(e => { // error catch
          console.log(e);
        });
    }
    // call function for the webhook associated with the number of times a number of violations occurs
    if(props.SortBy == "# of Violations"){
      ViolationFunc.getPieByNumOfVio(props.startDate, props.endDate, props.table).then(
        (response: { data: any[]; }) => {
          createDataAndLabels(response.data);
        }).catch((e: any) => {
          console.log(e);
        })
    }

    }


  // creates the Data and Label arrays for the Addresses and # of Violations charting options
  const createDataAndLabels = (_data: Array<any>) => {
    var data: number[] = []; // will be used for setNumbers at the end of the function
    var labels: any[] = []; // will be used for setLabels at the end of the function

  // when formating for an "Addresses" pie chart
  if(props.SortBy == "Addresses"){
    _data.forEach((element) => {
      labels.push(element.label); // add the address into the labels array
      // if else if block used as mongoDb uses "$numberInt", "$numberDouble", and "$numberLong" for numbers (varies on what type of numbers and how they are made), but future proof with checking for all 3 now. The numbers from the same object as the address above is added into the number array
      if(element.value.$numberInt){
        data.push(element.value.$numberInt)
      }
      else if(element.value.$numberDouble){
        data.push(element.value.$numberDouble)
      }
      else if(element.value.$numberLong){
        data.push(element.value.$numberLong)
      }
    })}
    // when formating for a "# of Violations" pie chart
    else if(props.SortBy == "# of Violations"){
      setLegendLabel("Locations with " + props.SortBy) // generate a graph title
      _data.forEach((element) => {
        // if else if for the labels array
        if(element.label.$numberInt){
          labels.push(element.label.$numberInt + " Violations")
        }
        else if(element.label.$numberDouble){
          labels.push(element.label.$numberDouble + "Violations")
        }
        else if(element.label.$numberLong){
          labels.push(element.label.$numberLong + " Violations")
        }
        // if else if for the numbers associated with frequency of the label above
        if(element.value.$numberInt){
          data.push(element.value.$numberInt)
        }
        else if(element.value.$numberDouble){
          data.push(element.value.$numberDouble)
        }
        else if(element.value.$numberLong){
          data.push(element.value.$numberLong)
        }
      })
    }
    setLabels(labels);
    setNumbers(data);
    // if there are more than 9 labels in the legend, more will need to be generated. Should only be used currently with "Address" pie chart
    if(labels.length > backColor.length){
      addMoreColor(labels.length);
    }
    setDatasetLabel('Number of Violations') // title of the legend
  }
// adds more chart colors in the case of more than 9 items for the legend
  const addMoreColor = (arrayLength: number) => {
    const tempBackColors = [...backColor];
    const tempBorderColors = [...borderColor];
    // make 3 colors at a time for R G B
    var addColor1: number;
    var addColor2: number;
    var addColor3: number;
    // loop until there are enough colors. 3 rgb colors are generated per iteration of the loop
    while(arrayLength > tempBackColors.length){
      addColor1 = Math.floor(Math.random() * 256); // Red color
      addColor2 = Math.floor(Math.random() * 256); // Green color
      addColor3 = Math.floor(Math.random() * 256); // Blue color
      tempBackColors.push('rgba(' + addColor1 + ', ' + addColor2 + ', ' + addColor3 + ', 0.2)');
      tempBorderColors.push('rgba(' + addColor1 + ', ' + addColor2 + ', ' + addColor3 + ', 1)');
      addColor1 = Math.floor(Math.random() * 256);
      addColor2 = Math.floor(Math.random() * 256);
      addColor3 = Math.floor(Math.random() * 256);
      tempBackColors.push('rgba(' + addColor1 + ', ' + addColor2 + ', ' + addColor3 + ', 0.2)');
      tempBorderColors.push('rgba(' + addColor1 + ', ' + addColor2 + ', ' + addColor3 + ', 1)');
      addColor1 = Math.floor(Math.random() * 256);
      addColor2 = Math.floor(Math.random() * 256);
      addColor3 = Math.floor(Math.random() * 256);
      tempBackColors.push('rgba(' + addColor1 + ', ' + addColor2 + ', ' + addColor3 + ', 0.2)');
      tempBorderColors.push('rgba(' + addColor1 + ', ' + addColor2 + ', ' + addColor3 + ', 1)');
    }
    // sets the color useStates
    setBackColor(tempBackColors);
    setBorderColor(tempBorderColors);
  }


  // creates the data array for when charting the frequencies of the different violations
  const createData = (_data: any) => {

        var finalArray = [];  
        const end = _data.length-1
        // This loop alone is enough for when all 9 violations are being displayed
        for(var i = 0; i < end; i++) // Have 3 types of number from MongoDB ("$numberInt", "$numberDouble", "$numberLong") just to future proof
        {
            if(_data[i].$numberInt)
            {
                finalArray.push(parseFloat((_data[i].$numberInt/_data[end].$numberDouble).toFixed(3))*100);
            }
            if(_data[i].$numberDouble)
            {
                finalArray.push(parseFloat((_data[i].$numberDouble/_data[end].$numberDouble).toFixed(3))*100);
            }
            if(_data[i].$numberLong)
            {
                finalArray.push(parseFloat((_data[i].$numberDouble/_data[end].$numberDouble).toFixed(3))*100);
            }
        }
        // used for if not all violations are being charted individually, so it can display the rest of the violations. This is the "Remaining issues" part of the graph
        if(finalArray.length < 9)
        {
          const leftSum = parseFloat((100 - finalArray.reduce((prev, curr) => {
            return prev + curr;
          }, 0)).toFixed(3));

          finalArray.push(leftSum);
        }
        setDatasetLabel('Frequency of Violations')
        return finalArray;
  }

  // creates the label array for when charting the frequencies of the different violations
  const createLabels = () => {
    var labelArray: string[] = [];

    if(props.allVio) // "All Violations"
    {
      labelArray.push("Illegal Occupancy Use")
      labelArray.push("Illegal Construction")
      labelArray.push("Illegal Signage")
      labelArray.push("Sanitation Issues")
      labelArray.push("Maintenance Issues")
      labelArray.push("Visibility Issues")
      labelArray.push("Right-of-Way Issues")
      labelArray.push("Permit Assistance")
      labelArray.push("Other")
    }
    if(props.overOcc)
    {
      labelArray.push("Illegal Occupancy Use")
    }
    if(props.illCons)
    {
      labelArray.push("Illegal Construction")
    }
    if(props.illSign)
    {
      labelArray.push("Illegal Signage")
    }
    if(props.sanitation)
    {
      labelArray.push("Sanitation Issues")
    }
    if(props.maintenance)
    {
      labelArray.push("Maintenance Issues")
    }
    if(props.Vis)
    {
      labelArray.push("Visibility Issues")
    }
    if(props.row)
    {
      labelArray.push("Right-of-Way Issues")
    }
    if(props.permit)
    {
      labelArray.push("Permit Assistance")
    }
    if(props.other)
    {
      labelArray.push("Other")
    }
    if(labelArray.length < 9)
    {
      labelArray.push("Remaining Issues");
    }
    return labelArray;
  }

  const options = {
    responsive: true, // Can change the size of the graph
    maintainAspectRatio: false, // graph will adjust depending on the size of the physical display
    plugins: {
      legend: {
        position: 'right' as const, // legend is placed right of the chart
        title: { // title for the legend
          display: true,
          text: datasetLabel
        }
      },
      title: { // title for the chart
        display: true,
        text: LengendLabel,
      },
    },

  }
  const data = {
    labels: Labels, // labels when hover over the charts
    datasets: [ // data object that will have the colors and the array of data that will be displayed
      {
        label: datasetLabel,
        data: Numbers,
        backgroundColor: backColor,
        borderColor: borderColor,
        borderWidth: 2,
      },
    ],
  };

  // choose what to display depending on if the graph is made yet
  const displayPie = () => {
  if(Numbers.length != 0){
    // displays the graph once all the data and labels are formated and set
    return (
      <Pie data={data} width={"30%"} options={options}/>
    );
  }
  else{ 
    // have a loading screen until the pie chart could be generated
    return(
    <IonLoading cssClass='my-custom-class'
    isOpen={showLoading}
    onDidDismiss={() => {setShowLoading(false); console.log("error")}}
    message={'Please wait...'}
    duration={5000}
    spinner = "bubbles"
    />
    )
  }
}



  return(
        <IonPage>
        <IonHeader>
          <IonToolbar>
          <IonTitle>Pie Chart</IonTitle>
          <IonButtons slot="start">
            <IonBackButton defaultHref="charts" color="goblin"/>
         </IonButtons> 
          </IonToolbar>
        </IonHeader>
        <IonContent >
          {displayPie()}
        </IonContent>
  </IonPage>
    );
};

export default ShowPieChart;