import React, {useState, useEffect} from "react";
import ViolationFunc from "../services/Functions";
import {IonButton, IonButtons, IonBackButton, IonCheckbox, IonContent, IonDatetime, IonHeader, IonItem, IonItemDivider, IonList, IonModal, IonPage, IonTitle, IonToolbar, IonIcon, IonLoading } from "@ionic/react";
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, registerables,} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import "../theme/Charts.css";

// all the props that come from Charts-menu.js
interface Props {
  allVio: boolean;
  overOcc: boolean;
  illCons: boolean;
  sanitation: boolean;
  maintenance: boolean;
  illSign: boolean;
  Vis: boolean;
  row: boolean;
  permit: boolean;
  other: boolean;
  SortByX: string;
  SortByY: string;
  startDate: string;
  endDate: string;
  table: number;
}

ChartJS.register( CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);


const ShowBarChart: React.FC<Props> = (props) => {
  // useStates the will be used for generating the legend, the dataset, titles
  const [Numbers, setNumbers] = useState<number[]>([]); // useState for the graph's data
  const [Labels, setLabels] = useState<string[]>([]); // useState for the graph's legend
  const [graphTitle, setGraphTitle] = useState<string>(""); // useState for the graph's title
  const [xTitle, setXTitle] = useState<string>(""); // useState for the X axis title
  const [yTitle, setYTitle] = useState<string>(""); // useState for the Y axis title
  const [showLoading, setShowLoading] = useState<boolean>(true); // useState for detailing if the loading popup will occur

  // immediately call a function that will grab the numbers from the MongoDB for the dataset
  useEffect(() => {
    grabNumbers();
  }, []);

   const grabNumbers = () => {
     setGraphTitle(props.SortByY + " vs " + props.SortByX); // set the title to by Y axis by X axis
     setXTitle(props.SortByX); // set the X axis title
     setYTitle(props.SortByY); // set the Y axis title
    // call the function with the webhook that will get the data from MongoDB with the number of occurrences of the appropriate violation types
    if(props.SortByX == "Violation Type"){
    ViolationFunc.getPieNumbers(props.allVio, props.overOcc, props.illCons, props.illSign, props.sanitation, props.maintenance, props.Vis, props.row, props.permit, props.other, props.startDate, props.endDate, props.table)
      .then(response => {
        setNumbers(createData(response.data)); // set the Numbers useState from the formated return data
        setLabels(createLabels()); // set the Labels useState from the formated return data
    })
    .catch(e => {
      console.log(e);
    });}
    // call the function that has the webhook that will give the number of documents with the months they were created
    if(props.SortByX == "Month of Creation"){
      ViolationFunc.getBarMonths(props.startDate, props.endDate, props.table).then(response => {
        MonthLabels(response.data); // format the data returned forusability of the bar graph
      }).catch(
        e => {
          console.log(e)
        }
      )
    }
    // call the function that has the webhook that will give the number of violations with appropriate address
    if(props.SortByX == "Addresses"){
      ViolationFunc.getPieByAddr(props.startDate, props.endDate, props.table).then(
        response => {
          createDataAndLabels(response.data); // format the data and labels to fit the bar graph format requirements
        }).catch(e => {
          console.log(e);
        });
    }
    // call the function that has the webhook that will give the number of documents that are solved and not solved
    if(props.SortByX == "Open/Solved"){
      ViolationFunc.getBarOpenAndSolved(props.startDate, props.endDate).then(
        response => {
          openSolvedLabels(response.data) // format the data and labels to be usable by the bar graph
        }).catch(e => {console.log(e)})
    }
  }
// create teh data and labels array for the "Addresses" option
  const createDataAndLabels = (_data: any) => {

    var data: number[] = [];
    var labels: any[] = [];
    for(var i = 0; i < _data.length; i++) {
      labels.push(_data[i].label); // add the address to the label array
      // if else if block used as mongoDb uses "$numberInt", "$numberDouble", and "$numberLong" for numbers (varies on what type of numbers and how they are made), but future proof with checking for all 3 now. The numbers from the same object as the address above is added into the number array
      if(_data[i].value.$numberInt){
        data.push(_data[i].value.$numberInt)
      }
      else if(_data[i].value.$numberDouble){
        data.push(_data[i].value.$numberDouble)
      }
      else if(_data[i].value.$numberLong){
        data.push(_data[i].value.$numberLong)
      }
    }
    setLabels(labels); // set the labels data
    setNumbers(data); // set the numbers data
  }
// create the data and labels array for the "Month of Creation"  option
  const MonthLabels = (_data: any) => {
    // set all the months in a year that will be graphed
    setLabels(["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]);
    var data = [];
    for(var i = 0; i < _data.length; i++)
    {
      // if else if block used as mongoDb uses "$numberInt", "$numberDouble", and "$numberLong" for numbers (varies on what type of numbers and how they are made), but future proof with checking for all 3 now. The numbers from the same object as the address above is added into the number array. Datqa comes back in subarrays of a big array
      if(_data[i][0].value.$numberLong){
        data.push(parseInt(_data[i][0].value.$numberLong));
      }
      if(_data[i][0].value.$numberInt){
        data.push(parseInt(_data[i][0].value.$numberInt));
      }
      if(_data[i][0].value.$numberDouble){
        data.push(parseInt(_data[i][0].value.$numberDouble));
      }
    }
    setNumbers(data); // set numbers data
  }
// creates the data and labels array for the "Open/Solved" option
  const openSolvedLabels = (_data: any) => {
    setLabels(["Open", "Solved"]); // set the 2 labels for the X axis
    var data = []
    for(var i = 0; i < _data.length; i++)
    {
      // if else if block used as mongoDb uses "$numberInt", "$numberDouble", and "$numberLong" for numbers (varies on what type of numbers and how they are made), but future proof with checking for all 3 now. The numbers from the same object as the address above is added into the number array. Data comes back in the form of subarrays of an array
      if(_data[i][0].value.$numberLong){
        data.push(parseInt(_data[i][0].value.$numberLong));
      }
      if(_data[i][0].value.$numberInt){
        data.push(parseInt(_data[i][0].value.$numberInt));
      }
      if(_data[i][0].value.$numberDouble){
        data.push(parseInt(_data[i][0].value.$numberDouble));
      }
    }
    setNumbers(data); // set Numbers data
  }
// creates the data array (Numbers) for the "Violation Type" option
  const createData = (_data: any) => {

        var finalArray = [];
        const end = _data.length-1
        // alone is enough for when all violations are being displayed
        for(var i = 0; i < end; i++)
        {
            if(_data[i].$numberInt)
            {
                finalArray.push(parseFloat((_data[i].$numberInt)));
            }
            if(_data[i].$numberDouble)
            {
                finalArray.push(parseFloat((_data[i].$numberDouble)));
            }
        }
        // used for if not all violations are being charted individually, so it can display the rest of the violations
        if(finalArray.length < 9)
        {
          const leftSum = parseFloat((parseFloat(_data[end].$numberDouble) - finalArray.reduce((prev, curr) => {
            return prev + curr;
          }, 0)).toFixed(3));

          finalArray.push(leftSum);
        }
        return finalArray;
  }

// creates the label array for the "Violation Type" option
  const createLabels = () => {
    var labelArray: string[] = [];
    if(props.allVio) // "All Violations"
    {
      labelArray.push("Illegal Occupancy Use")
      labelArray.push("Illegal Construction")
      labelArray.push("Illegal Signage")
      labelArray.push("Sanitation Issues")
      labelArray.push("Maintenance Issues")
      labelArray.push("Visibility Issues")
      labelArray.push("Right-of-Way Issues")
      labelArray.push("Permit Assistance")
      labelArray.push("Other")
    }
    if(props.overOcc)
    {
      labelArray.push("Illegal Occupancy Use")
    }
    if(props.illCons)
    {
      labelArray.push("Illegal Construction")
    }
    if(props.illSign)
    {
      labelArray.push("Illegal Signage")
    }
    if(props.sanitation)
    {
      labelArray.push("Sanitation Issues")
    }
    if(props.maintenance)
    {
      labelArray.push("Maintenance Issues")
    }
    if(props.Vis)
    {
      labelArray.push("Visibility Issues")
    }
    if(props.row)
    {
      labelArray.push("Right-of-Way Issues")
    }
    if(props.permit)
    {
      labelArray.push("Permit Assistance")
    }
    if(props.other)
    {
      labelArray.push("Other")
    }
    if(labelArray.length < 9)
    {
      labelArray.push("Remaining Issues");
    }
    return labelArray;
  }

  const options = {
    indexAxis: 'x' as const, // vetical bars, not horizontal bars
    responsive: true, // Can change the size of the graph
    maintainAspectRatio: false, // graph will adjust depending on the size of the physical display
    plugins: {
      legend: {
        position: 'top' as const, // legend is placed at top of the chart
      },
      title: { // title for the legend
        display: true,
        text: graphTitle,
      },
    },
    scales: {
      x: { // X axis options
          title: { // X axis title
            display: true,
            text: xTitle
          }
      },
      y: { // Y axis options
        title: { // Y axis title
          display: true,
          text: yTitle,
        }
      }
    }
  };
  // set the labels for the bar chart from the Labels useState
  const labels = Labels;
  // sets the data for the bar for the bar chart from the Numbers useState
  const data = {
    labels,
    datasets: [
      {
        label: 'Violation Count',
        data: Numbers,
        backgroundColor: 'rgba(0, 255, 0, 0.5)',
        borderColor: 'rgba(0, 255, 0, 1)',
        borderWidth: 1
      }, 
    ],
  };
  
  // choose what to display depending on if the graph is made yet
  const displayBar = () => {
    if(Numbers.length != 0){
      // displays the graph once all the data and labels are formated and set
      return (
        <Bar data={data} width={"25%"} options ={options}/>      );
    }
    else{ 
      // have a loading screen until the line chart could be generated
      return(
      <IonLoading cssClass='my-custom-class'
      isOpen={showLoading}
      onDidDismiss={() => {setShowLoading(false); console.log("error")}}
      message={'Please wait...'}
      duration={5000}
      spinner = "bubbles"
      />
      )
    }
  }


    return(
        <IonPage>
        <IonHeader>
          <IonToolbar>
              <IonTitle>Bar Chart</IonTitle>
              <IonButtons slot="start">
            <IonBackButton defaultHref="charts" color="goblin" />
         </IonButtons> 
          </IonToolbar>
        </IonHeader>
        <IonContent >
          {displayBar()}
        </IonContent>
  </IonPage>
    );
};

export default ShowBarChart;