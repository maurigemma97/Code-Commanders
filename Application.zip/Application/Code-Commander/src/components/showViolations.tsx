import React, {useState, useEffect} from "react";
import ViolationFunc from "../services/Functions";
import {IonButton, IonButtons, IonBackButton, IonCheckbox, IonContent, IonDatetime, IonHeader, IonItem, IonItemDivider, IonList, IonModal, IonPage, IonTitle, IonToolbar, IonFab, IonInput, IonTextarea } from "@ionic/react";
import * as writeTxt from "../services/writeTxt.js";
import '../theme/ShowVio.css';

// props from VioLocation-menu page for each type of possible violation
interface Props {
    overocc: boolean;
    illCons: boolean;
    vioCount: number;
    sanitation: boolean;
    maintenance: boolean;
    illSign: boolean;
    Vis: boolean;
    row: boolean;
    permit: boolean;
    other: boolean;
    dateStart: string;
    dateEnd: string;
    table: number;
}

var violationInfo = [{}]    //object array that will have each respective violation's address, latitude, longitude, and number of violations
var violationDetails = [{}] //object array that will have each respective violation's notes, date added, date updated, and date resolved
var violationVios = [{}]    //object array that will have each respective violation's specific violation values

const eCheck = [ {emailVal: true, tester:"cool"}];


const ShowViolations = (props:Props) => {

    const [violations, setViolations] = useState<any[]>([]);

    useEffect(() => {
        grabViolations();
    },[]);
    // function used to call the getViolations function to get all the appropriate violations
    const grabViolations = () => { 
        ViolationFunc.getViolations(props.vioCount, props.overocc, props.illCons, props.illSign, props.sanitation, props.maintenance, props.Vis, props.row, props.permit, props.other, props.dateStart, props.dateEnd, props.table)
            .then(response => {
                
                //database response is saved
                var violationAll = (response.data);

                
                for (let i = 0; i < violationAll.length; i++){

                    //address, long and lat coordinates, and number of violations are pushed to the violationInfo object array
                    violationInfo.push({
                        addr: violationAll[i].address, 
                        lat: parseFloat(violationAll[i].coordinates[0].$numberDouble), 
                        long: parseFloat(violationAll[i].coordinates[1].$numberDouble), 
                        numVios: parseFloat(violationAll[i].violations.$numberInt)
                    })


                    violationDetails.push({
                        notes: "", 
                        dateAdd: 20220112, 
                        dateUpd: 20220115, 
                        dateRes: 0})

                    violationVios.push({
                        overOcc: violationAll[i].over_occupancy.toString(), 
                        illConst: violationAll[i].illegal_construction.toString(),
                        illSign: violationAll[i].illegal_signage.toString(), 
                        issSan: violationAll[i].sanitation_issues.toString(), 
                        issMait: violationAll[i].maintenance_issues.toString(), 
                        issVis: violationAll[i].maintenance_issues.toString(), 
                        issRWay: violationAll[i].right_of_way_issues.toString(), 
                        issPerm: violationAll[i].permit_issues.toString(), 
                        other: violationAll[i].other.toString()})
                    }

            // console.log(violationInfo);
            // console.log(violationDetails);
            // console.log(violationVios);


            //info for the violations is saved to local sotrage to be collected on the home page to create violation markers
            localStorage.setItem("VioInfo", JSON.stringify(violationInfo));
            localStorage.setItem("VioDetails", JSON.stringify(violationDetails));
            localStorage.setItem("VioVios", JSON.stringify(violationVios));

            setViolations(response.data);

            })
            .catch(e => {
                console.log(e);
            });

            //violations.map(vio => {

            //    violationInfo.push({addr: vio.address, lat: vio.coordinates[0].$numberDouble, long:vio.coordinates[1].$numberDouble,numVios: vio.violations.$numberInt})

            //    violationDetails.push({notes: vio.notes, dateAdd: 0, dateUpd: 0, dateRes: 0})

            //    violationVios.push({overOcc: vio.over_occupancy.toString(), illConst:vio.illegal_construction.toString(), illSign: vio.illegal_signage.toString(), sanIss: vio.sanitation_issues.toString(), 
            //            maitIss: vio.maintenance_issues.toString(), visIss: vio.visibility_issues.toString(), rightWay:vio.right_of_way_issues.toString(), permit: vio.permit_issues.toString(), 
            //            other: vio.other.toString()})
            //})

            //sessionStorage.setItem("VioInfo", JSON.stringify(violationInfo));
            //sessionStorage.setItem("VioDetails", JSON.stringify(violationDetails));
            //sessionStorage.setItem("VioVios", JSON.stringify(violationVios));
    };


    return(
        <IonPage>
        <IonHeader>
          <IonToolbar>
            <IonButtons slot="start">
              <IonBackButton defaultHref="/home" color = "goblin" />
            </IonButtons>
              <IonTitle>List for Selected Violations</IonTitle>
          </IonToolbar>
          <IonInput type="email" mode="ios" inputMode="email" placeholder="Email Here" onIonChange={(e) => {writeTxt.default.setEmail(e.detail.value); eCheck[0].emailVal = writeTxt.default.emailCheck(e.detail.value);}} required>Write Your Email Here: </IonInput>
          <IonButton color="goblin" type="submit" size="small" onClick={() => {writeTxt.default.sendEmail()}}>Send Email</IonButton>
        </IonHeader>
            
        <IonContent>
            {/* details for each address is printed on the page */}
            {violations.map(vio => {
                writeTxt.default.setData('<h1>' + vio.address + '</h1>\n' +
                '<p>Date Added: ' + vio.date_added + '</p>\n' +
                '<p>Number of Violations: ' + vio.violations.$numberInt + '</p>\n' +
                '<p>Over Occupancy Violation: ' + vio.over_occupancy.toString() + '</p>\n' +
                '<p>Illegal Construction Violation: ' + vio.illegal_construction.toString() + '</p>\n' +
                '<p>Illegal Signage Violation: ' + vio.illegal_signage.toString() + '</p>\n' +
                '<p>Sanitation Issue Violation: ' + vio.sanitation_issues.toString() + '</p>\n' +
                '<p>Maintenance Issue Violation: ' + vio.maintenance_issues.toString() + '</p>\n' +
                '<p>Visibility Issue Violation: ' + vio.visibility_issues.toString() + '</p>\n' +
                '<p>Right Of Way Issue Violation: ' + vio.right_of_way_issues.toString() + '</p\n>' +
                '<p>Permit Issue Violation: ' + vio.permit_issues.toString() + '</p\n>' +
                '<p>Other Violation: ' + vio.other.toString() + '</p\n>' +
                '<p>Latitude: ' + vio.coordinates[0].$numberDouble + 'Longitude:' + vio.coordinates[1].$numberDouble + '</p>\n'
                );
                return (
            <div key={vio._id.$oid}>
            <h1>{vio.address}</h1>
            <p>Date Added: {vio.date_added}</p>
            <p className="numV">Number of Violations: {vio.violations.$numberInt}</p>
            <p className="OO">Over Occupancy Violation: {vio.over_occupancy.toString()}</p>
            <p className="IC">Illegal Construction Violation: {vio.illegal_construction.toString()}</p>
            <p className="IS">Illegal Signage Violation: {vio.illegal_signage.toString()}</p>
            <p className="SI">Sanitation Issue Violation: {vio.sanitation_issues.toString()}</p>
            <p className="MI">Maintenance Issue Violation: {vio.maintenance_issues.toString()}</p>
            <p className="VS">Visibility Issue Violation: {vio.visibility_issues.toString()}</p>
            <p className="ROW">Right Of Way Issue Violation: {vio.right_of_way_issues.toString()}</p>
            <p className="PI">Permit Issue Violation: {vio.permit_issues.toString()}</p>
            <p>Other Violation: {vio.other.toString()}</p>
            <p>Latitude: {vio.coordinates[0].$numberDouble} Longitude: {vio.coordinates[1].$numberDouble}</p>
            </div>
            );})}
        </IonContent>
  </IonPage>
    );


};

export default ShowViolations;
