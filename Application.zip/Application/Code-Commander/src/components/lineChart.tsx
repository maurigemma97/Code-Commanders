import React, {useState, useEffect} from "react";
import ViolationFunc from "../services/Functions";
import {IonButton, IonButtons, IonBackButton, IonCheckbox, IonContent, IonDatetime, IonHeader, IonItem, IonItemDivider, IonList, IonModal, IonPage, IonTitle, IonToolbar, IonIcon, IonLoading } from "@ionic/react";
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend,} from 'chart.js';
import { Line } from 'react-chartjs-2';
import "../theme/Charts.css";

// all the props that come from Charts-menu.js
interface Props {
  allVio: boolean;
  overOcc: boolean;
  illCons: boolean;
  sanitation: boolean;
  maintenance: boolean;
  illSign: boolean;
  Vis: boolean;
  row: boolean;
  permit: boolean;
  other: boolean;
  SortByX: string;
  SortByY: string;
  startDate: string;
  endDate: string;
  table: number;
}



ChartJS.register( CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);


const ShowLineChart: React.FC<Props> = (props) => {
  // useStates the will be used for generating the legend, the dataset, titles
  const [Numbers, setNumbers] = useState<any[]>([]); // useState for the graph's data
  const [Labels, setLabels] = useState<string[]>([]); // useState for the graph's legend
  const [graphTitle, setGraphTitle] = useState<string>(""); // useState for the graph's title
  const [xTitle, setXTitle] = useState<string>(""); // useState for the X axis title
  const [yTitle, setYTitle] = useState<string>(""); // useState for the Y axis title
  const [showLoading, setShowLoading] = useState<boolean>(true); // useState for detailing if the loading popup will occur

  // immediately call a function that will grab the numbers from the MongoDB for the dataset
  useEffect(() => {
    grabNumbers();
  }, []);

   const grabNumbers = () => {


     // get the data using the function with the appropriate webhook with data spread by in weeks
    if(props.SortByX == "Weeks"){
      ViolationFunc.getLineChartWeeks(props.allVio, props.overOcc, props.illCons, props.illSign, props.sanitation, props.maintenance, props.Vis, props.row, props.permit, props.other, props.startDate, props.endDate, props.table).then(response => {
        createData(response.data); //format the response data to be usable for the line chart
        createLabels(); // get the labels (the dates) for the X axis
      })
    }
     // get the data using the function with the appropriate webhook with data spread by in Years
     if(props.SortByX == "Years"){
      ViolationFunc.getLineChartYears(props.allVio, props.overOcc, props.illCons, props.illSign, props.sanitation, props.maintenance, props.Vis, props.row, props.permit, props.other, props.startDate, props.endDate, props.table).then(response => {
        createData(response.data); //format the response data to be usable for the line chart
        createLabels(); // get the labels (the dates) for the X axis
      })
    }
     // get the data using the function with the appropriate webhook with data spread by in Months
     if(props.SortByX == "Months"){
      ViolationFunc.getLineChartMonths(props.allVio, props.overOcc, props.illCons, props.illSign, props.sanitation, props.maintenance, props.Vis, props.row, props.permit, props.other, props.startDate, props.endDate, props.table).then(response => {
        createData(response.data); //format the response data to be usable for the line chart
        createLabels(); // get the labels (the dates) for the X axis
      })
    }

  }

  // fills the numbers array for the data set based on which violations are selected
  /*
      {
        label: "Other", // the title for the line
        data: [], // data points for the line
        borderColor: 'rgb(50, 255, 175)', // color of the line and inner color of the legend block
        backgroundColor: 'rgba(50, 255, 175, 0.5)', // color outline for the legend block
      }
      the format for a line generation in the line chart
  */
  const createData = (_data: any) => {
    const dataArray: any[] = [];
    setGraphTitle(props.SortByY + " vs " + props.SortByX); // set the title to by Y axis by X axis
    setXTitle("Dates by " + props.SortByX); // set the X axis title
    setYTitle(props.SortByY); // set the Y axis title
    if(props.allVio) // add data objects for all the types of violations
    {
      dataArray.push({
        label: "Illegal Occupancy Use",
        data: [],
        borderColor: 'rgb(255, 0, 0)',
        backgroundColor: 'rgba(255, 0, 0, 0.5)',
      })
      dataArray.push({
        label: "Illegal Construction",
        data: [],
        borderColor: 'rgb(0, 0, 255)',
        backgroundColor: 'rgba(0, 0, 255, 0.5)',
      })
      dataArray.push({
        label: "Illegal Signage",
        data: [],
        borderColor: 'rgb(0, 255, 0)',
        backgroundColor: 'rgba(0, 255, 0, 0.5)',
      })
      dataArray.push({
        label: "Sanitation Issues",
        data: [],
        borderColor: 'rgb(255, 255, 0)',
        backgroundColor: 'rgba(255, 255, 0, 0.5)',
      })
      dataArray.push({
        label: "Maintenance Issues",
        data: [],
        borderColor: 'rgb(255, 0, 255)',
        backgroundColor: 'rgba(255, 0, 255, 0.5)',
      })
      dataArray.push({
        label: "Visibility Issues",
        data: [],
        borderColor: 'rgb(0, 255, 255)',
        backgroundColor: 'rgba(0, 255, 255, 0.5)',
      })
      dataArray.push({
        label: "Right-of-Way Issues",
        data: [],
        borderColor: 'rgb(250, 0, 150)',
        backgroundColor: 'rgba(250, 0, 150, 0.5)',
      })
      dataArray.push({
        label: "Permit Assistance",
        data: [],
        borderColor: 'rgb(255, 150, 0)',
        backgroundColor: 'rgba(255, 150, 0, 0.5)',
      })
      dataArray.push({
        label: "Other",
        data: [],
        borderColor: 'rgb(50, 255, 175)',
        backgroundColor: 'rgba(50, 255, 175, 0.5)',
      })
    }
    if(props.overOcc)
    {
      dataArray.push({
        label: "Illegal Occupancy Use",
        data: [],
        borderColor: 'rgb(255, 0, 0)',
        backgroundColor: 'rgba(255, 0, 0, 0.5)',
      })
    }
    if(props.illCons)
    {
      dataArray.push({
        label: "Illegal Construction",
        data: [],
        borderColor: 'rgb(0, 0, 255)',
        backgroundColor: 'rgba(0, 0, 255, 0.5)',
      })
    }
    if(props.illSign)
    {
      dataArray.push({
        label: "Illegal Signage",
        data: [],
        borderColor: 'rgb(0, 255, 0)',
        backgroundColor: 'rgba(0, 255, 0, 0.5)',
      })
    }
    if(props.sanitation)
    {
      dataArray.push({
        label: "Sanitation Issues",
        data: [],
        borderColor: 'rgb(255, 255, 0)',
        backgroundColor: 'rgba(255, 255, 0, 0.5)',
      })
    }
    if(props.maintenance)
    {
      dataArray.push({
        label: "Maintenance Issues",
        data: [],
        borderColor: 'rgb(255, 0, 255)',
        backgroundColor: 'rgba(255, 0, 255, 0.5)',
      })
    }
    if(props.Vis)
    {
      dataArray.push({
        label: "Visibility Issues",
        data: [],
        borderColor: 'rgb(0, 255, 255)',
        backgroundColor: 'rgba(0, 255, 255, 0.5)',
      })
    }
    if(props.row)
    {
      dataArray.push({
        label: "Right-of-Way Issues",
        data: [],
        borderColor: 'rgb(250, 0, 150)',
        backgroundColor: 'rgba(250, 0, 150, 0.5)',
      })
    }
    if(props.permit)
    {
      dataArray.push({
        label: "Permit Assistance",
        data: [],
        borderColor: 'rgb(255, 150, 0)',
        backgroundColor: 'rgba(255, 150, 0, 0.5)',
      })
    }
    if(props.other)
    {
      dataArray.push({
        label: "Other",
        data: [],
        borderColor: 'rgb(50, 255, 175)',
        backgroundColor: 'rgba(50, 255, 175, 0.5)',
      })
    }
    // double loop that will go through each of the subarrays and fills the appropriate data array (inside the object) in the dataArray that was filled above. numbers could come in the form of "$numberInt", "$numberDouble", "$numberLong". 
    for(var i = 0; i < _data.length; i++){
      for(var j = 0; j < _data[i].length; j++){
        if(_data[i][j].$numberInt){
        dataArray[j].data.push(_data[i][j].$numberInt)
        }
        if(_data[i][j].$numberDouble){
          dataArray[j].data.push(_data[i][j].$numberDouble)
        }
        if(_data[i][j].$numberLong){
          dataArray[j].data.push(_data[i][j].$numberLong)
        }
      }
    }
    setNumbers(dataArray); // set the Numbers useState with the array of objects
  }


  const createLabels = () => {
    // function that will get the dates for the line charts X-axis that is used to get the data from getLineChartsWeeks/Months/Years above in grabNumbers()
    ViolationFunc.getLineChartDates(props.startDate, props.endDate, props.SortByX).then(response => {
    setLabels(response.data); // the labels are set in the useState; already formated when returned
    }).catch(e => {console.log(e)});

  }
  // options formating for the line graph
  const options = {
    responsive: true, // Can change the size of the graph
    maintainAspectRatio: false, // graph will adjust depending on the size of the physical display
    plugins: {
      legend: {
        position: 'top' as const, // legend is placed at top of the chart
      },
      title: { // title for the legend
        display: true,
        text: graphTitle,
      },
    },
      scales: {
        x: { // X axis options
            title: { // X axis title
              display: true,
              text: xTitle
            }
        },
        y: { // Y axis options
          title: { // Y axis title
            display: true,
            text: yTitle
          }
      }
    },
  };
  // set the labels for the line chart from the Labels useState
  const labels = Labels;
  // sets the data for the line for the line chart from the Numbers useState
  const data = {
    labels,
    datasets: Numbers,
  };


  // choose what to display depending on if the graph is made yet
  const displayLine = () => {
    if(Numbers.length != 0){
      // displays the graph once all the data and labels are formated and set
      return (
          <Line data={data} width={"25%"} options ={options}/>      );
    }
    else{ 
      // have a loading screen until the line chart could be generated
      return(
      <IonLoading cssClass='my-custom-class'
      isOpen={showLoading}
      onDidDismiss={() => {setShowLoading(false); console.log("error")}}
      message={'Please wait...'}
      duration={5000}
      spinner = "bubbles"
      />
      )
    }
  }

  
    return(
        <IonPage>
        <IonHeader>
          <IonToolbar>
            <IonTitle>Line Chart</IonTitle>
            <IonButtons slot="start">
            <IonBackButton defaultHref="charts" color="goblin" />
         </IonButtons> 
          </IonToolbar>
        </IonHeader>
        <IonContent >
                {displayLine()}
        </IonContent>
  </IonPage>
    );
};

export default ShowLineChart;