import axios from "axios";

export default axios.create({
    baseURL: "https://us-east-1.aws.data.mongodb-api.com/app/code_commander-nxdva/endpoint",
    headers: {
        "Content-type": "applicaiton/json"
    }
});