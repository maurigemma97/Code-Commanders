import React, { useEffect, useState } from "react";
import {IonIcon, IonButton, IonButtons, IonBackButton, IonCheckbox, IonCol, IonContent, IonDatetime, IonGrid, IonHeader, IonItem, IonItemDivider, IonLabel, IonList, IonModal, IonPage, IonRow, IonTitle, IonToolbar, IonSelect, IonSelectOption } from "@ionic/react";
import { barChartOutline, analytics, barChartSharp, pieChartSharp } from 'ionicons/icons';
import ShowPieChart from "../components/pieChart";
import ShowBarChart from "../components/barChart";
import ShowLineChart from "../components/lineChart";
import ReactDOM from 'react-dom';
import "../theme/Charts-menu.css";


// global array for the Show All Violations checkbox
const allViolationsList = [
  {val: "Show All Violations", isChecked: true, isDisabled: false}
];

// global array for the individual violation type checkboxes 
const violationsCheckboxList = [
  {val: "Illegal Occupancy Use", isChecked: false, isDisabled: true},
  {val: "Illegal Construction", isChecked: false, isDisabled: true},
  {val: "Sanitation Issues", isChecked: false, isDisabled: true},
  {val: "Maitenance Issues", isChecked: false, isDisabled: true},
  {val: "Illegal Signage", isChecked: false, isDisabled: true},
  {val: "Visibility Issues", isChecked: false, isDisabled: true},
  {val: "Right-of-Way Issues", isChecked: false, isDisabled: true},
  {val: "Permit Assistance", isChecked: false, isDisabled: true},
  {val: "Other", isChecked: false, isDisabled: true}
];

// global array for the resolved options checkboxes
const resolvedList = [
  {val: "Show Resolved Violations", isChecked: false, isDisabled: false},
  {val: "Show Only Resolved Violations", isChecked: false, isDisabled: true}
];

// global array for the updated options checkboxes
const updatedList = [
  {val: "Show Updated Violations", isChecked: false, isDisabled: false},
  {val: "Show Only Updated Violations", isChecked: false, isDisabled: true}
];

// global array for the all wards checkbox (location groupings through the city)
const allWardsList = [
  {val: "Show All Wards", isChecked: true, isDisabled: false}
];

// global array for the individual wards checkboxes; currently only used as a space filler for later use in development
const wardsCheckboxList = [
  {val: "Ward 1", isChecked: false, isDisabled: true},
  {val: "Ward 2", isChecked: false, isDisabled: true},
  {val: "Ward 3", isChecked: false, isDisabled: true},
  {val: "Ward 4", isChecked: false, isDisabled: true}
];

// global array for the different variables correlated to the different graphs used with the top buttons
const graphSelect = [
  {val: "Line", isChecked: false, color: "goblin", route: "lineChart", icon: analytics},
  {val: "Bar", isChecked: false, color: "goblin", route: "barChart", icon: barChartSharp},
  {val: "Pie", isChecked: false, color: "goblin", route: "pieChart", icon: pieChartSharp},
];

// global array for the graph generation button at the bottom of the screen
const generateButtonList = [
    {val: "Generate", isChecked: false, color: "dark", route: ""}
];


// global array for the select options for the pie chart's select
const pieDropOptions = [
{val: "-Select One-", display: " "},
{val: "Only Violations", display: "Only Violations"},
{val: "Addresses", display: "Addresses"},
{val: "# of Violations", display: "# of Violations"},
];

// global array for the select options for the bar chart's Y axis 
const barYDropOptions = [
{val: "-Select One-", display: " "},
{val: "# of Violations", display: "# of Violations"}
];

// global array for the select options for the bar chart's X axis 
const barXDropOptions = [
  {val: "-Select One-", display: " "},
  {val: "Addresses", display: "Addresses"},
  {val: "Violation Type", display: "Violation Type"},
  {val: "Month of Creation", display: "Month of Creation"},
  {val: "Open/Solved", display: "Open/Solved"},
];

// global array for the select options for the line chart's Y axis 
const lineYDropOptions = [
  {val: "-Select One-", display: " "},
  {val: "# of Violations", display: "# of Violations"}
  ];

  // global array for the select options for the line chart's X axis 
  const lineXDropOptions = [
    {val: "-Select One-", display: " "},
    {val: "Weeks", display: "Weeks"},
    {val: "Months", display: "Months"},
    {val: "Years", display: "Years"},
  ];

  // function that will send the props to the correct charting page based on which graph is selected
async function Generate(pieChoice: string, BarXChoice: string, BarYChoice: string, LineXChoice: string, LineYChoice: string, readStart: string, readEnd: string) {

  // determine which table to in mongoDB
  var table = 0; // default to "Violations" table
  // shift to "All" table
  if(resolvedList[0].isChecked){ 
    table = 1;
  }
  // shift to "Completed" table
  if(resolvedList[1].isChecked){
    table = 2;
  }

  // route to "linechart" and send props so the appropriate line chart can be made
  if(graphSelect[0].isChecked){
    ReactDOM.render(
      <React.StrictMode>
        <ShowLineChart allVio = {allViolationsList[0].isChecked} overOcc = {violationsCheckboxList[0].isChecked} illCons = {violationsCheckboxList[1].isChecked} sanitation = {violationsCheckboxList[2].isChecked} maintenance = {violationsCheckboxList[3].isChecked} illSign = {violationsCheckboxList[4].isChecked} Vis = {violationsCheckboxList[5].isChecked} row = {violationsCheckboxList[6].isChecked} permit = {violationsCheckboxList[7].isChecked} other = {violationsCheckboxList[8].isChecked}SortByX = {LineXChoice} SortByY = {LineYChoice} startDate = {readStart} endDate = {readEnd} table = {table}/>
      </React.StrictMode>,
      document.getElementById('root')
    )
  }
  // route to "barchart" and send props so the appropriate bar chart can be made
  if(graphSelect[1].isChecked){
    ReactDOM.render(
      <React.StrictMode>
        <ShowBarChart allVio = {allViolationsList[0].isChecked} overOcc = {violationsCheckboxList[0].isChecked} illCons = {violationsCheckboxList[1].isChecked} sanitation = {violationsCheckboxList[2].isChecked} maintenance = {violationsCheckboxList[3].isChecked} illSign = {violationsCheckboxList[4].isChecked} Vis = {violationsCheckboxList[5].isChecked} row = {violationsCheckboxList[6].isChecked} permit = {violationsCheckboxList[7].isChecked} other = {violationsCheckboxList[8].isChecked}SortByX = {BarXChoice} SortByY = {BarYChoice} startDate = {readStart} endDate = {readEnd} table = {table}/>
      </React.StrictMode>,
      document.getElementById('root')
    )
  }
  // route to "piechart" ans send props so the appropriate pie chart can be made
  if(graphSelect[2].isChecked){
  ReactDOM.render(
    <React.StrictMode>
      <ShowPieChart allVio = {allViolationsList[0].isChecked} overOcc = {violationsCheckboxList[0].isChecked} illCons = {violationsCheckboxList[1].isChecked} sanitation = {violationsCheckboxList[2].isChecked} maintenance = {violationsCheckboxList[3].isChecked} illSign = {violationsCheckboxList[4].isChecked} Vis = {violationsCheckboxList[5].isChecked} row = {violationsCheckboxList[6].isChecked} permit = {violationsCheckboxList[7].isChecked} other = {violationsCheckboxList[8].isChecked} SortBy = {pieChoice} startDate={readStart} endDate={readEnd} table = {table}/>
    </React.StrictMode>,
    document.getElementById('root')
  );
  }
}


const Charts_page: React.FC = () => {
  
  const [checked, setChecked] = useState(allViolationsList); // useState for setting check properties in arrays above
  const [disabled, setUsable] = useState(allViolationsList); // useState for setting disable properties in arrays above
  const [graphCheck, setGraphCheck] = useState(graphSelect); // useState for setting which graph to be made (and what page to route to)
  const [PieChoice, setPieChoice] = useState<string>(""); // useState for the pie chart's R axis
  const [BarXAxis, setBarXAxis] = useState<string>(""); // useState for the bar chart's X axis
  const [BarYAxis, setBarYAxis] = useState<string>(""); // useState for the bar chart's Y axis
  const [LineXAxis, setLineXAxis] = useState<string>(""); // useState for the line chart's X axis
  const [LineYAxis, setLineYAxis] = useState<string>(""); // useState for the line chart's Y axis
  const [generate, setGenerate] = useState(generateButtonList); // useState to set the properties of the "generateButtonList" array for the "generate" button

  // One piece to note for the two initial state for the two next useStates. When the Date objects are made, they are created with timezones of UTC. When changed to ISO string, time zones would be eliminated. Though a problem here is that when it is about 9PM in Eastern Time Zone, the ISO string will think it is the next day. So April 15 2022 @ 9PM in Date object is April 16 2022 in ISO string
  const [initialDate, setInitialDate] = useState<string>((new Date()).toISOString()); // useState for  ionDateTime "Start Date" calender. 
  const [endDate, setEndDate] = useState<string>((new Date()).toISOString()); // useState for ionDateTime "End Date" calender
  
  

  const [readStart, setReadStart] = useState<string>("0000-00-00");
  const [readEnd, setReadEnd] = useState<string>("9999-99-99");

  // function: change allows indivdual violation boxes to have their values of being checked to change from true and false.
  async function change(val: string, check: boolean, i: number) {
    violationsCheckboxList[i].isChecked = check;
  }
  // function changes the color of selected graph types and activates/changes color of the generate button; 0 is for line charts, 1 for bar charts, 2 for pie charts
  async function graphChange(i: number){
    const tempList = [...graphSelect];
    const tempMoreList = [...generateButtonList];

  // changes the button properties based on which button is selected
  if(tempList[i].isChecked === false)
  {
    tempList[i].isChecked = true;
    tempList[i].color = "goblin";

    // i = 0 [1] and i = 1 || i = 2 [0]
    tempList[(i**2+2)%3/2].isChecked = false;
    tempList[(i**2+2)%3/2].color = "dark";

    // i = 0 || i = 1 [2] and i = 2 [1]
    tempList[(3*Math.floor(i/2) + 2) % 4].isChecked = false;
    tempList[(3*Math.floor(i/2) + 2) % 4].color = "dark";
    tempMoreList[0].route = tempList[i].route;

    // clears out the drop down menu options
    setBarYAxis("");
    setBarXAxis("");
    setPieChoice("");
    setLineYAxis("");
    setLineXAxis("");
  }
  else{
    tempList[i].isChecked = false;
    tempList[i].color = "goblin";

    // i = 0 [1] and i = 1 || i = 2 [0]
    tempList[(i**2+2)%3/2].isChecked = false;
    tempList[(i**2+2)%3/2].color = "goblin";

    // i = 0 || i = 1 [2] and i = 2 [1]
    tempList[(3*Math.floor(i/2) + 2) % 4].isChecked = false;
    tempList[(3*Math.floor(i/2) + 2) % 4].color = "goblin";
    tempMoreList[0].route = "";
  }
    setGraphCheck(tempList);
    setGenerate(tempMoreList);
  }

  // Controls when the resolved/updated violations can be selected and whcih ward to select from
  const changeSubCheckboxes = (value: string, check: boolean) =>{
    if(value === "Show Resolved Violations") { 
      const tempListPrime = [...resolvedList] 
    
      if (check === true) {
        tempListPrime[0].isChecked = check
        tempListPrime[1].isChecked = false
        tempListPrime[1].isDisabled = false
      }
      if (check === false) {
        tempListPrime[0].isChecked = check
        tempListPrime[1].isChecked = false
        tempListPrime[1].isDisabled = true
      }

      setChecked(tempListPrime)
      setUsable(tempListPrime)
    }
    if(value === "Show Only Resolved Violations") { 
      const tempListPrime = [...resolvedList] 
    
      if (check === true) {
        tempListPrime[1].isChecked = check
        tempListPrime[0].isDisabled = true
      }
      if (check === false) {
        tempListPrime[1].isChecked = check
        tempListPrime[0].isDisabled = false

      }

      setUsable(tempListPrime);
      setChecked(tempListPrime)
    } 
    if(value === "Show Updated Violations") { 
      const tempListPrime = [...updatedList] 
    
      if (check === true) {
        tempListPrime[0].isChecked = check
        tempListPrime[1].isChecked = false
        tempListPrime[1].isDisabled = false
      }
      if (check === false) {
        tempListPrime[0].isChecked = check
        tempListPrime[1].isChecked = false
        tempListPrime[1].isDisabled = true
      }

      setChecked(tempListPrime)
      setUsable(tempListPrime)
    }
    if(value === "Show All Wards") {
      const tempListPrime = [...allWardsList]  
      const tempList = [...wardsCheckboxList]

      if (check === true) {
        tempListPrime[0].isChecked = check

        tempList.forEach(function(item){
        item.isChecked = false
        item.isDisabled = true
        })
      }
      if (check === false) {
        tempListPrime[0].isChecked = check

        tempList.forEach(function(item){
          item.isChecked = true
          item.isDisabled = false
        })
      }
      setChecked(tempListPrime)
      setUsable(tempListPrime)
      setChecked(tempList)
      setUsable(tempList)       
    }
  }

  // controls when violations checkboxes can be selected.
  const changeViolationSubboxes = (value: string, check: boolean) => {
    const tempListPrime = [...allViolationsList]  
    const tempList = [...violationsCheckboxList]

    // if "Show All Violations" is true (box is checked), then each of the violation types become false (boxes become unchecked) and are disabled
    if (check === true) {
      tempListPrime[0].isChecked = check

      tempList.forEach(function(item){
      item.isChecked = false
      item.isDisabled = true
      })
    }
    // if "Show All Violations" is false (box is unchecked), then each of the violation types become true (boxes become checked) and are enabled
    else if (check === false) {
      tempListPrime[0].isChecked = check

      tempList.forEach(function(item){
        item.isChecked = true
        item.isDisabled = false
      })
    }
    setChecked(tempListPrime)
    setUsable(tempListPrime)   
    setChecked(tempList)
    setUsable(tempList) 
  }

  // changes in the bar graph's x-axis based on which select option is chosen
  const BarXShift = (barShift: string) => {
    const tempMoreList = [...generateButtonList];
    const tempListPrime = [...resolvedList];
    // if the blank or "Violation Type" select option is not selected then the  "Show All Violations" checkbox will become disabled
    if(barShift != "Violation Type" && barShift != "-Select One-"){
      setBarXAxis(barShift);
      allViolationsList[0].isDisabled = true;
      changeViolationSubboxes(allViolationsList[0].val, true);
    }
    else{// if the blank or "Violation Type" select option is selected then the  "Show All Violations" checkbox will become enabled enabled
      setBarXAxis(barShift);
      allViolationsList[0].isDisabled = false;
      changeViolationSubboxes(allViolationsList[0].val, true);
    }
    // change the "generate" button depending on selection of X and Y axis options
    // if the selected X and Y axis options are blank or the value (-Select One-) for blank the "generate" button will remain unchecked, dark, and will not route anywhere
    if((barShift == "-Select One-" || BarYAxis == "-Select One-") || (barShift == "" || BarYAxis == "")){ 
      tempMoreList[0].isChecked = false;
      tempMoreList[0].color = "dark";
      tempMoreList[0].route = "";
      }
      else{ // if the X and Y axis options are not blank then the "generate" button will be clickable, colored, and route to "barChart" page
      tempMoreList[0].isChecked = true;
      tempMoreList[0].color = "goblin";
      tempMoreList[0].route = "barChart";
      }
      setChecked(tempListPrime)
      setUsable(tempListPrime)
      setGenerate(tempMoreList);
  }

  // changes in the bar graph's y-axis based on which select option is chosen
  const BarYShift = (barShift: string) => {
    const tempMoreList = [...generateButtonList];
      // set the bar chart's Y axis
      setBarYAxis(barShift);
    // change the "generate" button depending on selection of X and Y axis options
    // if the selected X and Y axis options are blank or the value (-Select One-) for blank the "generate" button will remain unchecked, dark, and will not route anywhere
    if((BarXAxis == "-Select One-" || barShift == "-Select One-") || (BarXAxis == "" || barShift == "")){
      tempMoreList[0].isChecked = false;
      tempMoreList[0].color = "dark";
      tempMoreList[0].route = "";
      }
      else{ // if the X and Y axis options are not blank then the "generate" button will be clickable, colored, and route to "barChart" page
      tempMoreList[0].isChecked = true;
      tempMoreList[0].color = "goblin";
      tempMoreList[0].route = "barChart";
      }
      setGenerate(tempMoreList);
  }

  // changes in the line graph's x-axis based on which select option is chosen
  const lineXShift = (lineShift: string) => {
    const tempMoreList = [...generateButtonList];
    if(lineShift == "-Select One-"){
      // if the blank select option is selected then the "Show All Violations" checkbox will be disabled
      setLineXAxis(lineShift);
      allViolationsList[0].isDisabled = true;
      changeViolationSubboxes(allViolationsList[0].val, true);
    }
    else{
      // if the blank select option is not selected then the  "Show All Violations" checkbox will be enabled
      setLineXAxis(lineShift);
      allViolationsList[0].isDisabled = false;
      changeViolationSubboxes(allViolationsList[0].val, true);
    }
    // change the "generate" button depending on selection of X and Y axis options
    // if the selected X and Y axis options are blank or the value (-Select One-) for blank the "generate" button will remain unchecked, dark, and will not route anywhere
    if((lineShift == "-Select One-" || LineYAxis == "-Select One-") || (lineShift == "" || LineYAxis == "")){
      tempMoreList[0].isChecked = false;
      tempMoreList[0].color = "dark";
      tempMoreList[0].route = "";
      }
      else{// if the X and Y axis options are not blank then the "generate" button will be clickable, colored, and route to "lineChart" page
      tempMoreList[0].isChecked = true;
      tempMoreList[0].color = "goblin";
      tempMoreList[0].route = "lineChart";
      }
      setGenerate(tempMoreList);

  }
  // changes in the line graph's y-axis based on which select option is chosen
  const lineYShift = (lineShift: string) => {
    const tempMoreList = [...generateButtonList];
      // set the Line chart's Y axis
      setLineYAxis(lineShift);
    // change the "generate" button depending on selection of X and Y axis options
    // if the selected X and Y axis options are blank or the value (-Select One-) for blank the "generate" button will remain unchecked, dark, and will not route anywhere
    if((LineXAxis == "-Select One-" || lineShift == "-Select One-") || (LineXAxis == "" || lineShift == "")){
      tempMoreList[0].isChecked = false;
      tempMoreList[0].color = "dark";
      tempMoreList[0].route = "";
      }
      else{// if the X and Y axis options are not blank then the "generate" button will be clickable, colored, and route to "lineChart" page
      tempMoreList[0].isChecked = true;
      tempMoreList[0].color = "goblin";
      tempMoreList[0].route = "lineChart";
      }
      setGenerate(tempMoreList);
  }

  // changes the Violation checkbox options based on which option is selected from the drop menu
  // all will enable or disable the usability of the generate button
  const pieShift = (pieShift:string) => {
    const tempMoreList = [...generateButtonList];
    // if the select option is blank or "Only Violations", the "Show All Violations" will be checked off, disabled, and pie chart's choice (R axis) will be set
    if(pieShift != "Only Violations" && pieShift != "-Select One-"){
    setPieChoice(pieShift);
    allViolationsList[0].isDisabled = true;
    changeViolationSubboxes(allViolationsList[0].val, true);
    }
        // if the select option is "Address" or "# of Violations", the "Show All Violations" will be checked off, disabled, and pie chart's choice (R axis) will be set
    if(pieShift != "Addresses" && pieShift != "# of Violations"){
    setPieChoice(pieShift);
    allViolationsList[0].isDisabled = false;
    changeViolationSubboxes(allViolationsList[0].val, true);
    }
    // If the select option is the blank option then the "generate" button will not be checked, become dark, and route to nowhere
    if(pieShift == "-Select One-"){
    tempMoreList[0].isChecked = false;
    tempMoreList[0].color = "dark";
    tempMoreList[0].route = "";
    }
    else{ /// if the select option is anything but blank then the "generate" button will be checked, become colored, and route to the "pieChart" page
    tempMoreList[0].isChecked = true;
    tempMoreList[0].color = "goblin";
    tempMoreList[0].route = "pieChart";
    }
    setGenerate(tempMoreList);
  }
  // displays which axis choices can be displayed to be selected based on the graph choice
  const Axis_Choice = () => {
  // If the line chart button is selected, then the line chart's select options is available for X and Y axis
  if(graphSelect[0].isChecked === true){
    return(
      <IonGrid>
        <IonRow>
          <IonCol>
          <IonItemDivider>X-Axis</IonItemDivider>
        <IonItem>
          <IonSelect interface="popover" placeholder="-Select One-" value={LineXAxis}
          onIonChange={e => lineXShift(e.detail.value)}>
            {lineXDropOptions.map(({val, display}, i) => (
            <IonSelectOption key = {i} value = {val}>{display}</IonSelectOption>
            ))}
          </IonSelect>
        </IonItem>
        </IonCol>
        <IonCol>
        <IonItemDivider>Y-Axis</IonItemDivider>
        <IonItem>
          <IonSelect interface="popover" placeholder="-Select One-" value={LineYAxis}
          onIonChange={e => lineYShift(e.detail.value)}>
            {lineYDropOptions.map(({val, display}, i) => (
              <IonSelectOption key = {i} value = {val}>{display}</IonSelectOption>
            ))}
          </IonSelect>
        </IonItem>
        </IonCol>
        </IonRow>
        </IonGrid>
    )}
  // If the bar chart button is selected, then the bar chart's select options is available for X and Y axis
  else if(graphSelect[1].isChecked === true){
    return(
      <IonGrid>
        <IonRow>
          <IonCol>
          <IonItemDivider>X-Axis</IonItemDivider>
        <IonItem>
          <IonSelect interface="popover" placeholder="-Select One-" value={BarXAxis}
          onIonChange={e => BarXShift(e.detail.value)}>
            {barXDropOptions.map(({val, display}, i) => (
            <IonSelectOption key = {i} value = {val}>{display}</IonSelectOption>
            ))}
          </IonSelect>
        </IonItem>
          </IonCol>
          <IonCol>
          <IonItemDivider>Y-Axis</IonItemDivider>
        <IonItem>
          <IonSelect interface="popover" placeholder="-Select One-" value={BarYAxis}
          onIonChange={e => BarYShift(e.detail.value)}>
            {barYDropOptions.map(({val, display}, i) => (
              <IonSelectOption key = {i} value = {val}>{display}</IonSelectOption>
            ))}
          </IonSelect>
        </IonItem>
        </IonCol>
        </IonRow>
        </IonGrid>
    )}
  // If the piee chart button is selected, then the pie chart's select options is available
  else if (graphSelect[2].isChecked === true){
    return(
      <IonGrid>
        <IonRow>
          <IonCol>
          <IonItemDivider>Sorted By:</IonItemDivider>
        <IonItem>
          <IonSelect interface="popover" placeholder="-Select One-" value={PieChoice}
          onIonChange = {e => pieShift(e.detail.value)}>
            {pieDropOptions.map(({val, display}, i) => (
              <IonSelectOption key = {i} value = {val}>{display}</IonSelectOption>
            ))}
          </IonSelect>

        </IonItem>
        </IonCol>
        </IonRow>
        </IonGrid>
    )}
  }

    // saves the starting date from the calender that the user chose for the date range
const startChange = (tempStart: string) => {
  setReadStart(tempStart.slice(0, 10));
  // double set to get the correct date inside the "setReadStart" useState
  setReadStart(tempStart.slice(0, 10));
}
    // saves the ending date from the calender that the user chose for the date range
const endChange = (tempEnd: string) => {
  setReadEnd(tempEnd.slice(0, 10));
  // double set to get the correct date inside the "setReadEnd" useState
  setReadEnd(tempEnd.slice(0, 10));
}

    return (
      <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonButtons slot="start">
            <IonBackButton defaultHref="home" color="goblin"/>
         </IonButtons>             
          <IonTitle>Violation Charting and Graphing</IonTitle>
        </IonToolbar>
      </IonHeader>
  
    <IonContent>

    <IonList>
      <IonItemDivider>Chart Type</IonItemDivider>
        <IonGrid>
          <IonRow>
            {/* display the 3 graph buttons */}
          {graphSelect.map(({val, isChecked, color, route, icon}, i) => (
              <IonCol key = {i}>
                <IonButton class = "button" size = "default" expand = "block" color = {color} 
                onClick = {() => graphChange(i)}><IonIcon icon = {icon} />
                  {val}
                </IonButton>
              </IonCol>
            ))}
          </IonRow>
      </IonGrid>
    </IonList>

    <IonList>
      <IonItemDivider>Adjust Violation Date Range</IonItemDivider>
      {/*Grid for the calenders*/}
      <IonGrid>
          <IonRow>
            <IonCol>
              <IonItem>
                <IonLabel>Start Date</IonLabel>
                <IonDatetime color="goblin" value = {initialDate} presentation="date" placeholder="Select Date" onIonChange={e => startChange(e.detail.value!)}></IonDatetime>
              </IonItem>
            </IonCol>
            <IonCol>
              <IonItem>
                <IonLabel>End Date</IonLabel>
                <IonDatetime color="goblin" value = {endDate}  presentation="date" placeholder="Select Date"
                onIonChange={e => endChange(e.detail.value!)}></IonDatetime>
              </IonItem>
            </IonCol>        
          </IonRow>
      </IonGrid>

    </IonList>
    <IonList>
      {/*Place holder for after a chart button is seleccted*/}
    {Axis_Choice()}
     </IonList>
     {/*Checkbox for "Show All Violations" */}
    <IonItemDivider></IonItemDivider>
    <IonItem> <IonLabel> {allViolationsList[0].val} </IonLabel> <IonCheckbox value={allViolationsList[0].val} slot="start" color="goblin" checked={allViolationsList[0].isChecked} disabled={allViolationsList[0].isDisabled} onIonChange={(e) => changeViolationSubboxes(e.detail.value, e.detail.checked)}/> </IonItem>
    
    <IonList>
      <IonItemDivider>Only Show Selected Violations</IonItemDivider>
          {/* display all the violations checkboxes */}
      {violationsCheckboxList.map(({val, isChecked, isDisabled}, i) => (
          <IonItem key = {i}>
            <IonLabel> {val}</IonLabel>
            <IonCheckbox color="goblin" slot = "start" value = {val} checked={isChecked} disabled={isDisabled} onIonChange={(e) => change(e.detail.value, e.detail.checked, i)}/>
          </IonItem>
        ))}

    </IonList>

    <IonItemDivider></IonItemDivider>
    {/*checkbox for "Show Resolved Violations" */}
    <IonItem> <IonLabel> {resolvedList[0].val} </IonLabel> <IonCheckbox value={resolvedList[0].val} slot="start" color="goblin" checked={resolvedList[0].isChecked} disabled={resolvedList[0].isDisabled} onIonChange={(e) => changeSubCheckboxes(e.detail.value, e.detail.checked)} /> </IonItem>
    {/*checkbox for "Show Only Resolved Violations" */}
    <IonItem> <IonLabel> {resolvedList[1].val} </IonLabel> <IonCheckbox value={resolvedList[1].val} slot="start" color="goblin" checked={resolvedList[1].isChecked} disabled={resolvedList[1].isDisabled}  onIonChange={(e) => changeSubCheckboxes(e.detail.value, e.detail.checked)}/> </IonItem>
    
    {/* <IonItemDivider></IonItemDivider>
    {checkbox for "Show Updated Violations"}
    <IonItem> <IonLabel> {updatedList[0].val} </IonLabel> <IonCheckbox value={updatedList[0].val} slot="start" color="goblin" checked={updatedList[0].isChecked} disabled={updatedList[0].isDisabled}  onIonChange={(e) => changeSubCheckboxes(e.detail.value, e.detail.checked)}/> </IonItem>
    {checkbox for "Show Only Updated Violations" }
    <IonItem> <IonLabel> {updatedList[1].val} </IonLabel> <IonCheckbox value={updatedList[1].val} slot="start" color="goblin" checked={updatedList[1].isChecked} disabled={updatedList[1].isDisabled}  onIonChange={(e) => changeSubCheckboxes(e.detail.value, e.detail.checked)}/> </IonItem> */}

    {/* <IonItemDivider></IonItemDivider>
    {checkbox for "All Wards"}
    <IonItem> <IonLabel> {allWardsList[0].val} </IonLabel> <IonCheckbox value={allWardsList[0].val} slot="start" color="goblin" checked={allWardsList[0].isChecked} disabled={allWardsList[0].isDisabled}  onIonChange={(e) => changeSubCheckboxes(e.detail.value, e.detail.checked)}/> </IonItem>

    <IonItemDivider>Only Show Selected Wards</IonItemDivider>
      { display the wards checkboxes}
    {wardsCheckboxList.map(({val, isChecked, isDisabled}, i) => (
          <IonItem key = {i}>
            <IonLabel> {val} </IonLabel>
            <IonCheckbox color="goblin" slot = "start" value = {val} checked={isChecked} disabled={isDisabled} />
          </IonItem>
        ))} */}

    <IonItemDivider></IonItemDivider>
    <IonGrid>
          <IonRow>
            <IonCol> </IonCol>
            <IonCol>
              {/* button to generate the graph once the graph is selected along with the respect axis */}
              <IonButton class = "button" size = "large" expand = "block" routerLink={generateButtonList[0].route} onClick={() => Generate(PieChoice, BarXAxis, BarYAxis, LineXAxis, LineYAxis, readStart, readEnd)} color = {generateButtonList[0].color} disabled={!generateButtonList[0].isChecked}>GENERATE GRAPH</IonButton>
            </IonCol>        
            <IonCol> </IonCol>
          </IonRow>
      </IonGrid>

  </IonContent>
</IonPage>
    );
};

export default Charts_page;