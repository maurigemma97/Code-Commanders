import React, {useState} from 'react';
import { useHistory } from "react-router-dom";
import {IonIcon, IonLabel, IonButton, IonButtons, IonBackButton, IonCheckbox, IonCol, IonContent, IonDatetime, IonGrid, IonHeader, IonItem, IonItemDivider, IonList, IonModal, IonPage, IonRow, IonTitle, IonToolbar, IonInput } from "@ionic/react";
import { carOutline } from 'ionicons/icons';

const primaryCheckboxList = [
  {val: "Show Violations Reported on Route", isChecked: true, isDisabled: false},
  {val: "Show All Violations Reported", isChecked: true, isDisabled: false}
];

const routeCheckboxList = [
  {val: "Illegal Occupancy Use", isChecked: false, isDisabled: true},
  {val: "Illegal Construction", isChecked: false, isDisabled: true},
  {val: "Sanitation Issues", isChecked: false, isDisabled: true},
  {val: "Maitenance Issues", isChecked: false, isDisabled: true},
  {val: "Illegal Signage", isChecked: false, isDisabled: true},
  {val: "Visibility Issues", isChecked: false, isDisabled: true},
  {val: "Right-of-Way Issues", isChecked: false, isDisabled: true},
  {val: "Permit Assistance", isChecked: false, isDisabled: true},
  {val: "Other", isChecked: false, isDisabled: true}
];


const Routes_page: React.FC = () => {

    var [id, setid] = useState<string>();
    var [date, setDate] = useState<string>();
    var [check, setCheck] = useState<boolean>(false);

    let history = useHistory();

    const ShowRoute = () => {

      setCheck(true);

      var routeInfo = [
        date,
        id,
        check
      ]

      window.history.pushState(routeInfo, "please", "/home");
    /*
      history.push({
        pathname: '/home',
        state: routeInfo,
      });
      */
    
    };



    const [checked, setChecked] = useState(primaryCheckboxList);
    const [disabled, setUsable] = useState(primaryCheckboxList);

    const changeViolationCheckbox = (value: string, check: boolean) =>{
      const tempListPrime = [...primaryCheckboxList]  
      const tempList = [...routeCheckboxList]

      if(value === "Show Violations Reported on Route" && check === true) {
        tempListPrime[0].isChecked = check
        tempListPrime[1].isChecked = true
        tempListPrime[1].isDisabled = false
      }
      if(value === "Show Violations Reported on Route" && check === false) {
        tempListPrime[0].isChecked = check
        tempListPrime[1].isChecked = false
        tempListPrime[1].isDisabled = true

        tempList.forEach(function(item){
          item.isChecked = false
          item.isDisabled = true
        })
      }
      console.log("tempList", tempList)
      setChecked(tempList)
      setUsable(tempList)      

    }
    const changeViolationSubboxes = (value: string, check: boolean) => {
        const tempListPrime = [...primaryCheckboxList]  
        const tempList = [...routeCheckboxList]

        if(tempListPrime[0].isChecked === false) {
            tempListPrime[1].isChecked = false
            tempListPrime[1].isDisabled = true

            tempList.forEach(function(item){
              item.isChecked = false
              item.isDisabled = true
            })
        }
        else{ 
          if (value === "Show All Violations Reported" && check === true) {
            tempListPrime[1].isChecked = check

            tempList.forEach(function(item){
            item.isChecked = false
            item.isDisabled = true
            })
          }
          if (value === "Show All Violations Reported" && check === false) {
            tempListPrime[1].isChecked = check

            tempList.forEach(function(item){
              item.isChecked = true
              item.isDisabled = false
            })
          }
        }
        console.log("tempListPrime", tempListPrime)
        setChecked(tempListPrime)
        setUsable(tempListPrime)   
        console.log("tempList", tempList)
        setChecked(tempList)
        setUsable(tempList) 

    }
    return (
     <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonButtons slot="start">
            <IonBackButton color="goblin" defaultHref="/home" />
                <IonIcon icon={carOutline} size="large" />          
          </IonButtons>
            <IonTitle>Previous Routes</IonTitle>
        </IonToolbar>
      </IonHeader>
  
    <IonContent>

    <IonList>

      <IonItem>
            <IonLabel>Employee ID:</IonLabel>
            <IonInput class="idBox" value={id} onIonInput={(e: any) => setid(e.target.value)} onIonChange={(e: any) => setid(e.detail.value!)} ></IonInput>
      </IonItem>

      <IonItem>
            <IonLabel>Date Driven:</IonLabel>
            <IonInput class="dateBox" value={date} onIonInput={(e: any) => setDate(e.target.value)} onIonChange={(e: any) => setDate(e.detail.value!)} ></IonInput>
      </IonItem>
      
    </IonList>

    <IonButton color="goblin" class="pullButton" size="large" expand="block" onClick={ShowRoute} routerLink = "/home">Show Route</IonButton>
        &nbsp; &nbsp;&nbsp; &nbsp;
{/* 
    <IonList>
      <IonItemDivider>Show Routes within Date Range</IonItemDivider>

        <IonButton id="open-start">Select Start Date</IonButton>
      <IonModal trigger="open-start">
      <IonContent>
          <IonDatetime presentation="date" cancelText="Cancel" doneText="Done"></IonDatetime>
        </IonContent>
      </IonModal>

      <IonButton id="open-end">Select End Date</IonButton>
      <IonModal trigger="open-end">
        <IonContent>
          <IonDatetime presentation="date" cancelText="Cancel" doneText="Done"></IonDatetime>
        </IonContent>
      </IonModal>

    </IonList>

    <IonItemDivider></IonItemDivider>
    <IonItem> <IonLabel> {primaryCheckboxList[0].val} </IonLabel> <IonCheckbox value={primaryCheckboxList[0].val} slot="start" color="primary" checked={primaryCheckboxList[0].isChecked} disabled={primaryCheckboxList[0].isDisabled} onIonChange={(e) => changeViolationCheckbox(e.detail.value, e.detail.checked)}/></IonItem>
    <IonItem> <IonLabel> {primaryCheckboxList[1].val} </IonLabel><IonCheckbox value={primaryCheckboxList[1].val} slot="start" color="primary" checked={primaryCheckboxList[1].isChecked} disabled={primaryCheckboxList[1].isDisabled} onIonChange={(e) => changeViolationSubboxes(e.detail.value, e.detail.checked)}/></IonItem>
    <IonList>
      <IonItemDivider>Only Show Selected Violations</IonItemDivider>

        {routeCheckboxList.map(({val, isChecked, isDisabled}, i) => (
          <IonItem key = {i}>
            <IonLabel> {val} </IonLabel>
            <IonCheckbox slot = "start" value = {val} checked={isChecked} disabled={isDisabled} />
          </IonItem>
        ))}

    </IonList>

    <IonItemDivider></IonItemDivider>
    <IonGrid>
          <IonRow>
            <IonCol> </IonCol>
            <IonCol>
              <IonButton class = "button" size = "large" expand = "block">SHOW ROUTES</IonButton>
            </IonCol>        
            <IonCol> </IonCol>
          </IonRow>
      </IonGrid> */}

  </IonContent>
</IonPage>
    );
};

export default Routes_page;