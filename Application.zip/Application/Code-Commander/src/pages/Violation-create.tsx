import React, { useCallback, useEffect, useRef, useState } from "react";
import {IonBackButton, IonButton, IonButtons, IonCheckbox, IonContent, IonDatetime, IonHeader, IonIcon, IonInput, IonItem, IonItemDivider, IonLabel, IonList, IonPage,IonRange, IonRefresher, IonSelect, IonSelectOption, IonTextarea, IonTitle, IonToolbar} from "@ionic/react";
import { useHistory } from "react-router-dom";

import 'mapbox-gl/dist/mapbox-gl.css';
import MapboxGeocoder from '@mapbox/mapbox-gl-geocoder';
import mapboxgl from "mapbox-gl";
import { image } from "ionicons/icons";
import * as Realm from "realm-web";
import ViolationFunc from "../services/Functions.js";
import { getCurrentDate } from "./Navigation-button.js";
import { stringify } from "querystring";
import "../theme/create.css";

const CreateViolation_page: React.FC = () => {

  interface ViolationEntry {
    address: string,
    city: string,
    state: string,
    zip_code: string,
    country: string,
    violations: number,
    over_occupancy: boolean,
    illegal_construction: boolean,
    illegal_signage: boolean,
    sanitation_issues: boolean,
    maintenance_issues: boolean,
    visibility_issues: boolean,
    right_of_way_issues: boolean,
    permit_issues: boolean,
    other: boolean,
    notes: string,
    coordinates: [ number, number ],
    date_added: string,
    date_updated: string,
    date_completed: string,
  };

  const [address, setAddress] = useState<string>();
  const [date, setDate] = useState<string>();
  const [violation_type, setViolationType] = useState<string>("");
  const [notes, setNotes] = useState<string>();
  var [shouldAdd, setAdd] = useState<boolean>();
  let history = useHistory();

    async function addViolationToDatabase(e: ViolationEntry)
    {
      const app = new Realm.App({ id: "code_commander-nxdva" });
      const credentials = Realm.Credentials.anonymous();
      try {
        console.log(e);
        const user = await app.logIn(credentials);
        ViolationFunc.upload(e);                 

      } catch(err) {
        console.error("Failed to log in", err);
      }
    }


    const ProcessViolation = () => {

      var state = history.location.state as ViolationEntry;

      var creation_date = date as string; // Need to fix and not update every change
      var update_date = date as string;

      var current_date = new Date();

      var dd = String(current_date.getDate()).padStart(2, '0');
      var mm = String(current_date.getMonth() + 1).padStart(2, '0'); //January is 0!
      var yyyy = current_date.getFullYear();

      var parsed_date = `${yyyy}-${mm}-${dd}`;

      state.date_added = creation_date.split('T')[0]; // Need to fix and not update every change
      state.date_updated = parsed_date;

      state.notes = notes as string;
      state.violations = 0;

      if(violation_type.includes("Illegal Occupancy Use")){ state.over_occupancy = true; state.violations++; }
      if(violation_type.includes("Illegal Construction")){ state.illegal_construction = true; state.violations++; }
      if(violation_type.includes("Sanitation Issues")){ state.sanitation_issues = true; state.violations++; }
      if(violation_type.includes("Maintenance Issues")){ state.maintenance_issues = true; state.violations++; }
      if(violation_type.includes("Illegal Signage")){ state.illegal_signage = true; state.violations++; }
      if(violation_type.includes("Visibility Issues")){ state.visibility_issues = true; state.violations++; }
      if(violation_type.includes("Right-of-Way Issues")){ state.right_of_way_issues = true; state.violations++; }
      if(violation_type.includes("Permit Assistance")){ state.permit_issues = true; state.violations++; }
      if(violation_type.includes("Other")){ state.other = true; state.violations++; }

      console.log(violation_type);

      addViolationToDatabase(state);

      ViolationFunc.upload(state).then(response => {
        console.log(response.data);
      }).catch(e => {
        console.log(e);
      });

      shouldAdd = true;
      const violation_data = [address, shouldAdd, violation_type, notes];

      history.push({
        pathname: '/home',
        state: violation_data
      });

      ClearPage();

    };

    const ClearPage = () => {

      var current_date = new Date();

      var dd = String(current_date.getDate()).padStart(2, '0');
      var mm = String(current_date.getMonth() + 1).padStart(2, '0'); //January is 0!
      var yyyy = current_date.getFullYear();

      var parsed_date = `${yyyy}-${mm}-${dd}`;

      setDate(parsed_date);
      setViolationType("");
      setNotes("");
    };

    const options = {
      cssClass: 'my-custom-interface'
    };


    return (
     <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Create Violation</IonTitle>
          <IonButtons slot="start">
          <IonBackButton defaultHref="home" color = "goblin"/>
        </IonButtons>
        </IonToolbar>
      </IonHeader>
  
    <IonContent>
     <IonList>
       
       <IonItem>
            <IonLabel>Date of Violation Occurence</IonLabel>
            <IonDatetime color="goblin" id="date_picker" value = {date} presentation="date" placeholder="Select Date" onIonChange={e => setDate(e.detail.value!)}></IonDatetime>
       </IonItem>

       <IonItem>
            <IonLabel>Violation Type</IonLabel>
            <IonSelect interfaceOptions={options} name="violation_picker" value={violation_type} placeholder="Select one" multiple={true} onIonChange={e => setViolationType(e.detail.value!)}>
              <IonSelectOption value="Illegal Occupancy Use">Illegal Occupancy Use</IonSelectOption>
              <IonSelectOption value="Illegal Construction">Illegal Construction</IonSelectOption>
              <IonSelectOption value="Sanitation Issues">Sanitation Issues</IonSelectOption>
              <IonSelectOption value="Maintenance Issues">Maintenance Issues</IonSelectOption>
              <IonSelectOption value="Illegal Signage">Illegal Signage</IonSelectOption>
              <IonSelectOption value="Visibility Issues">Visibility Issues</IonSelectOption>
              <IonSelectOption value="Right-of-Way Issues">Right-of-Way Issues</IonSelectOption>
              <IonSelectOption value="Permit Assistance">Permit Assistance</IonSelectOption>
              <IonSelectOption value="Other">Other</IonSelectOption>
            </IonSelect>
          </IonItem>

          <IonItem>
            <IonButton color = "goblin" class="button">
                <IonIcon icon={image}/> Attach Image
            </IonButton>
          </IonItem>

          <IonItem>
            <IonInput name="notes_textbox" value={notes} placeholder="Additional notes here..." onIonChange={e => setNotes(e.detail.value!)}> </IonInput>
       </IonItem>

      </IonList>

     <IonList>
       <IonItemDivider></IonItemDivider>
        <IonButton color="goblin" class="button" size="large" expand="block" onClick={ProcessViolation}>Add Violation</IonButton>

     </IonList>

  </IonContent>
</IonPage>
    );
};

export default CreateViolation_page;