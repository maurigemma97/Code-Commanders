import { IonContent, IonPage, IonFab, IonFabButton, IonFabList, IonIcon, IonButton, IonToolbar, IonLabel, IonInput } from '@ionic/react';
import { settings, compassOutline, warningOutline, barChartOutline, carOutline, locationOutline, add, removeCircleOutline, remove, playOutline, stopOutline, mapOutline, shareSocialSharp  } from 'ionicons/icons';
import React, {useRef, useEffect, useState} from 'react';
import { useHistory, useParams , Redirect} from "react-router-dom";
import mapboxgl from '!mapbox-gl'; // eslint-disable-line import/no-webpack-loader-syntax
import 'mapbox-gl/dist/mapbox-gl.css';
import MapboxDirections from '@mapbox/mapbox-gl-directions/dist/mapbox-gl-directions';
import '@mapbox/mapbox-gl-directions/dist/mapbox-gl-directions.css'
import { GeoJSONSource, GeolocateControl } from 'mapbox-gl';
import { NavigationControl } from 'mapbox-gl';
import MapboxGeocoder from '@mapbox/mapbox-gl-geocoder';
import { MapboxStyleSwitcherControl } from "mapbox-gl-style-switcher";
import "mapbox-gl-style-switcher/styles.css";
import './Home.css';
import './Settings-menu.css';
import './Navigation-button.css';
import './Violation-create.css';
import mapboxSdk from '@mapbox/mapbox-sdk';
import './Navigation-button'
import * as Realm from "realm-web";
import * as ViolationFunctions from "../services/Functions.js";
import $ from 'jquery';
//import Realm from "realm";

mapboxgl.accessToken = 'pk.eyJ1IjoiYXVyaWdlbSIsImEiOiJja3pkMzBmMGYyMm83MnZwcXlmc3BhYXY1In0.-G6921S10HLyqlXxPODk4g';

export default function Home() {
  
  const mapContainer = useRef(null);
  const geocodeContainer = useRef(null);
  const map = useRef(null);


  // The general address lookup search box on the homescreen
  var std_geocoder = new MapboxGeocoder({
    container: geocodeContainer, 
    accessToken: mapboxgl.accessToken,
    mapboxgl: mapboxgl,
    bbox: [-83.7348, 41.3332, -83.4847, 41.4660],
    marker: true,
    }) 

    // When a place is entered in fly there and zoom in
  std_geocoder.on("result", (e) => {
    map.current.flyTo({
      center: e.result.center,
      zoom: 18,
    })


  });

  const [lng, setLng] = useState(-83.65);  //center lat and long for map when home page is intialized
  const [lat, setLat] = useState(41.378); 
  const [zoom, setZoom] = useState(13.3);  //standard zoom for map when home page is initialized

  let routeState = false;
  var counter = 0;

  var routeCoordinates = [];
  var violationCoordinates = [];

  var [id, setid] = useState("");
  var [date, setDate] = useState("");

  var history = useHistory(); //used to call other pages and to pass data from one page to another
  let shouldAdd = false;
  var directionsExist = false;
  var geocoderExist = false;
  var locationsExist = false;

  var id;
  var date;

  const bounds = [
  [-83.7043, 41.3481], // Southwest coordinates
  [-83.5842, 41.4280], // Northeast coordinates
  ]
  
  var addressClick = "";      //used to save the address that's been double-tapped by a user
  var coordClick = [0.0, 0.0] //used to save the coordinates that's been double-tapped by a user
  var userCoords = [0.0, 0.0]; //used to save user's current coordinates (preliminary, currently unsused)
  var dateThen  = new Date().getTime() / 1000; //used to save current date for date check for recording user's location (preliminary, currently unused)


  var markerList = []; //used to save (and later remove) markers added from Violation Location search request as well as the 'Add Violation' functionality

  /* 
      Parameters:  none
      Description: Display the navigation popup if there isnt one already.
      Output:      none
  */
  const locate = () => {

    var geolocate = new mapboxgl.GeolocateControl({
        positionOptions: {
          enableHighAccuracy: true,
        },
        style: {
          left: 10,
          top: 10
        },
        // When active the map will receive updates to the device's location as it changes.
        trackUserLocation: true,
        ShowUserLocation: true,
        //position: 'top-left',
        // Draw an arrow next to the location dot to indicate which direction the device is heading.
        showUserHeading: true,
        fitBoundsOptions: {
          maxZoom: 17,
        },
      });

    map.current.addControl(geolocate, 'top-left');

    // preliminary work for getting tracking the user's location for route tracking
    geolocate.on('geolocate', function(e) {

          const userLocationTime = () => {
               
              if((userCoords[0] !== e.coords.longitude || userCoords[1] !== e.coords.latitude) && //if the current coordinates are different from last tracked coordinates
              ( (e.coords.longitude < (userCoords[0] - 0.0002) || e.coords.longitude > (userCoords[0] + 0.0002)) || //and if the user has moved far enough away from their 
                (e.coords.latitude < (userCoords[1] - 0.0002) || e.coords.latitude > (userCoords[1] + 0.0002)) )) { //spot (to lessen the size of the route vector)

                var dateNow = new Date(); // get the current date from the OS
                var dateSeconds = dateNow.getTime() / 1000;
                
                //if 10 seconds have passed since the last check
                if (dateSeconds - dateThen >= 10) {
                  //console.log(dateNow);
                  var currentDate = dateNow.toDateString(); // calendar date is converted to string
                  var currentTime = dateNow.toLocaleTimeString(); // current time is converted to string
                  var dateString = 'date: '+ currentDate + ' time: ' + currentTime;
                  console.log('date:', currentDate, 'time:', currentTime);

                  userCoords = [e.coords.longitude, e.coords.latitude]; //userCoord value is changed to current geolocation of user
                  console.log(userCoords);   
                  //alert(userCoords);
                  //alert(dateString); 

                  dateThen = dateSeconds; //global variable for time is set to dateSeconds in order to determine if 10 seconds has passed since last check
                }               
              }

              setTimeout(userLocationTime, 10000); //will recall this function every few seconds (integer it meant to suggest the timeframe for recalling this function
                                                   //but is very unreliable, which is the reason for the date check above which is actually reliable)              

          };

          userLocationTime();

    });

  };

  //sets local storage map request item so violation markers do not reappear when home page is reselceted
  const SetMapRequest = () => {
    var newMapReqest = "false";
    localStorage.setItem('vioMapRequest', newMapReqest);
  }

  //checks to see if the violation location search has has been completed using saved local storage variable.
  const CheckMapValue = () => {
    
    var searchedViolations = localStorage.getItem('vioMapRequest');

    if (searchedViolations === "true") {
      AddVioLocationMarkers(); 
      searchedViolations = "false";
      localStorage.setItem('vioMapRequest', searchedViolations);
    }
    else ClearMarkers();

  }

  /* 
      Parameters:  none
      Description: Calls directions() Cant probably just be removed and use directions instead
      Output:      none
  */
  const showNavigation = () => {
    directions();
  };

  /* 
      Parameters:  none
      Description: Display the navigation popup if there isnt one already.
      Output:      none
  */
  const directions = () => {

    console.log(directionsExist);
    
    if(directionsExist == true){
      return;
    }

    map.current.addControl(
      new MapboxDirections({
        interactive: false, //This entire function has to do with the directions button in the top
        accessToken: mapboxgl.accessToken, //right corner of the app
        unit: 'imperial',
        profile: 'mapbox/driving',
        controls: {profileSwitcher: false},
        placeholderOrigin: "Start",
        placeholderDestination: "End",
        
        style: {
          margin: 150,
          top: 50,
          padding: 100,
          width: 300,
        }
      }), 'top-right'
    );

    directionsExist = true;
    
  }

  /* 
      Parameters:  none
      Description: Display the map control tools in the top-left
      Output:      none
  */
  const navbar = () => {
    map.current.addControl(
      new NavigationControl({ 
        showCompass: true, //this fucntion creates the compass in the top left corner of the app and it is used to recenter the map if you rotate it around to a different angle
        showZoom: true,
        style: {
          left: 100,
          top: 10
        }
      }), 'top-left'
    );
  }

  //intializes map, checks for request for violation markers, and determines the coordinates and address from user's double-click
  useEffect(() => {
    if (map.current) return; // initialize map only once
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/streets-v11',
      center: [lng, lat],
      zoom: zoom,
      maxBounds: bounds
    });

    CheckMapValue();
 
    //lng and lat of the double-clicked area on the map is saved
     map.current.on('dblclick', (e) => {
      console.log(e.lngLat.lng);
      console.log(e.lngLat.lat);
      coordClick = [e.lngLat.lng, e.lngLat.lat]
    var long = e.lngLat.lng.toString();
    var latt = e.lngLat.lat.toString();

    //string created to get reverse-geotracking (lat/lng => address) information
    var reverseGeo = "https://api.mapbox.com/geocoding/v5/mapbox.places/";
    reverseGeo += long + "," + latt + ".json?access_token=" + mapboxgl.accessToken;

    console.log(reverseGeo);

    //url is called and the address is extracted from the JSON site link
    $.ajax({
        url:reverseGeo,
        type: 'get',
        dataType: 'json',
        async: false,
        success: function(e) {
            addressClick = e.features[0].place_name;
          }
      });

    addressClick = addressClick.slice(0, -42); //later portion of address (", Bowing Green, OH 4360X") is cut and then the street address is saved
    console.log(addressClick);
      
    //CreateViolation is called when user double clicks an area
    CreateViolation();
      
    });
  });

  // This is called once when the page is first loaded, calls functions to add
  // all of the controls to the map.
  useEffect(() => {
    navbar(); //this puts into effect the navigation compass thats in the top left corner of the map
    locate(); //this is to put into effect the location button that finds your current location in the top left corner of the map
    findProperty();
    switcher(); //this is to enable the map switcher on the map
  }, [""]);


  useEffect(() => {

   if (!map.current) return; // wait for map to initialize
 
  });

  /* 
      Parameters:  none
      Description: Display the general address search box on home.
      Output:      none
  */
  const findProperty = () => {
    document.getElementById('geocoder').appendChild(std_geocoder.onAdd(map.current));
  }

  /* 
      Parameters:  none
      Description: Takes the coordinates of the clicked area and sends it to create violation
                   page to be further processed.
      Output:      none
  */
  const CreateViolation = () => {


      // template to add violation info to database
      let ViolationEntry = {
        address: addressClick, // set to the address that was double-tapped
        city: "Bowling Green",
        state:"Ohio",
        zip_code:"43402",
        country:"United States of America",
        violations: 0,
        over_occupancy: false,
        illegal_construction: false,
        illegal_signage: false,
        sanitation_issues: false,
        maintenance_issues: false,
        visibility_issues: false,
        right_of_way_issues: false,
        permit_issues: false,
        other: false,
        notes: "",
        coordinates: coordClick, // set to the coordiantes that was double-tapped
        date_added: "0000-00-00",
        date_updated: "0000-00-00",
        date_completed: "0000-00-00",
      };

      var location_data = ViolationEntry;

      console.log(location_data);

      history.push({
        pathname: '/createViolation/:address',
        state: location_data
      });

      waitForViolation(location_data);



  }


  /* 
      Parameters:  string address
      Description: Takes an address and searches the database for a match,
                   if a match is found the violatioin is returned. 
      Output:      Returns promise object containing violation information from database 
  */
  async function getFromDatabase(address)
  {
    const app = new Realm.App({ id: "code_commander-nxdva" });
    const credentials = Realm.Credentials.anonymous();
    try {
      const user = await app.logIn(credentials);
      var response = await ViolationFunctions.default.findByAddr(address);
      return response;               

    } catch(err) {
      console.error("Failed to log in", err);
    }
  }

  /* 
      Parameters:  
      Description: 
      Output:      
  */
  const AddViolationFromPopup = (e) => {

    const parsed_address = addressClick;
    console.log(parsed_address);

    var location_data = getFromDatabase(parsed_address);

    location_data.then(function(contents){ 
      location_data = contents;

      history.push({
        pathname: '/createViolation/:address',
        state: location_data
      });

      console.log(location_data);
      waitForViolationFromPopup(location_data);

    });
      
    };



    function waitForViolationFromPopup (e) {

      if(history.location.state[1] == true) {
  
        var violation = history.location.state[2];
        var notes = history.location.state[3];
  
        PlaceMarkerAtAddressFromPopup(e, violation, notes);
        history.location.state[1] = false;
      } 
      else {
        setTimeout(function() { waitForViolation(e, violation, notes) }, 1000);
      }
  
    }

  /* 
      Parameters:  
      Description: 
      Output:      
  */
    const PlaceMarkerAtAddressFromPopup = (editted_violation_info, violation, notes) => {
  
      const x = 41.37526314261635;
      const y = -83.64724985750716;

      violationCoordinates.push([x,y]);
  
      const full_address = "116 North Summit Streeet";
  
      // Set marker options.
      const marker = new mapboxgl.Marker({
        color: "#FF0000", draggable: false
      }).setLngLat([x, y]).addTo(map.current);
      
  
      marker.getElement().addEventListener('click', () => {
  
        const popup = new mapboxgl.Popup({ closeOnClick: false })
        .setLngLat([x, y])
        .setHTML('<font color = "#000000">' +
                 '<h6 class="htmlAddress"><b>Address:</b></h6>' + full_address +
                 '<h6><b>Violation(s):</b></h6>' + violation +
                 '<h6><b>Image(s):</b></h6>+<button style="font: bold 16px Arial;">Add Image</button>' +
                 '<img src="https://ap.rdcpix.com/182362824/9c4c19d5deeaa8be055d5c9fc2e5cfc8l-m0xd-w200_h150_q80.jpg" alt="Property Image 1" width="100" height="67">' +
                 '<h6><b>Notes:</b></h6>' + notes +
                 '<br><br><button class="addBtn" style="font: bold 16px Arial;">Add Violation</button> <br><br>' +
                 '<button class="editBtn" style="font: bold 16px Arial;">Edit Violation</button> <br><br>' +
                 '</font>')
        .addTo(map.current);
  
        const addBtn = document.getElementsByClassName("addBtn")[0];
        const editBtn = document.getElementsByClassName("editBtn")[0];
        const htmlAddress = document.getElementsByClassName("htmlAddress")[0]; 
  
        const htmlzzzAddress = document.getElementsByClassName("htmlAddress"); 
        console.log(htmlzzzAddress.nextSibling);
  
        addBtn.addEventListener("click", () => {
          AddViolationFromPopup(htmlAddress);
        });
  
        editBtn.addEventListener("click", () => {
          ClearMarkers();
          history.push({
            pathname: '/editViolation',
          });
        });
  
      });
  
    };


  /* 
      Parameters:  
      Description: 
      Output:      
  */
  function waitForViolation (e) {
     
    console.log(history.location.state);
    console.log(history.location.state[1]);
    console.log(history.location.state.address);

    if(history.location.state[1] == true) {

      console.log(history.location.state[1]);
      var violation = history.location.state[2];
      console.log(violation);
      var notes = history.location.state[3];
      console.log(notes);

      PlaceMarkerAtAddress(e, violation, notes);
      history.location.state[1] = false;

    } 
    else {
      setTimeout(function() { waitForViolation(e) }, 1000);
    }

  }


  /* 
      Parameters:  
      Description: 
      Output:      
  */
  const PlaceMarkerAtAddress = (e, violation, notes) => {

    const markLng = e.coordinates[0];
    const markLat = e.coordinates[1];

    // Set marker options.
    const marker = new mapboxgl.Marker({
      color: "#FF0000", draggable: false
    }).setLngLat([markLng, markLat]).addTo(map.current);

    //marker is pushed to list for later deletion
    markerList.push(marker);

    //violation HTML text (and their respective symbol) is created and saved to one variable
    var violation = AddViolations(e);

    marker.getElement().addEventListener('click', () => {

      const popup = new mapboxgl.Popup({ closeOnClick: false })
      .setLngLat([markLng, markLat])
      .setHTML('<font color = "#000000">' +
               '<h6 class="htmlAddress"><b>Address:</b></h6>' + e.address +
               '<h6><b>Violation(s):</b></h6>' + violation +
               '<h6><b>Image(s):</b>' +
               '<br><br>'+
               '<button style="font: bold 16px Arial;">Add Image</button>' +
               '<img src="https://ap.rdcpix.com/182362824/9c4c19d5deeaa8be055d5c9fc2e5cfc8l-m0xd-w200_h150_q80.jpg" alt="Property Image 1" width="100" height="67">' +
               '<h6><b>Notes:</b></h6>' + notes +
               '<br><br><button class="addBtn" style="font: bold 16px Arial;">Add Violation</button> <br><br>' +
               '<button class="editBtn" style="font: bold 16px Arial;">Edit Violation</button> <br><br>' +
               '</font>')
      .addTo(map.current);

      const addBtn = document.getElementsByClassName("addBtn")[0];
      const editBtn = document.getElementsByClassName("editBtn")[0];
      const htmlAddress = document.getElementsByClassName("htmlAddress")[0]; 

      const htmlzzzAddress = document.getElementsByClassName("htmlAddress"); 
      console.log(htmlzzzAddress.nextSibling);

      addBtn.addEventListener("click", () => {
        AddViolationFromPopup(e.address);
      });

      editBtn.addEventListener("click", () => {
        history.push({
          pathname: '/editViolation',
        });
        PlaceMarkerAtAddress(e, violation, notes);
      });

    });

  };
  

  /* 
      Parameters:  
      Description: 
      Output:      
  */
  function waitForViolationLocations (e) {

    if(history.location.state[1] == true) {

      var violation = history.location.state[2];
      var notes = history.location.state[3];

      PlaceMarkerAtAddress(e, violation, notes);
    } 
    else {
      setTimeout(function() { waitForViolation(e, violation, notes) }, 1000);
    }

  };

  //violation HTML string for marker popups is set here to be one string, and adds violatiion symbols with the violation name
  var AddViolations = (vMarker) => {

    var tempVioList = "";

    //source images can be found in the images/viosMini folder to be placed on a different database
    if(vMarker.overOcc === "true" || vMarker.over_occupancy === true) tempVioList += "<img src='https://drive.google.com/uc?id=1I28bTB_JLmZtYAZtncuEpnOQtm5cy63j' style='vertical-align: middle;' width='25' height='25'> <span style='vertical-align: middle;'> Illegal Occupancy Use </span><br>";
    if(vMarker.illConst === "true" || vMarker.illegal_construction === true) tempVioList += "<img src='https://drive.google.com/uc?id=1TlNO0cd5_DBKfmqdC-dJosXAISqSI_3v' style='vertical-align: middle;' width='25' height='25'> <span style='vertical-align: middle;'> Illegal Construction </span><br>";
    if(vMarker.illSign === "true" || vMarker.illegal_signage === true) tempVioList += "<img src='https://drive.google.com/uc?id=1JIlEWyQBVNCJACJ94sffmhv8fTQjXJrc' style='vertical-align: middle;'width='25' height='25'> <span style='vertical-align: middle;'> Illegal Signage </span><br>";
    if(vMarker.issSan === "true" || vMarker.sanitation_issues === true) tempVioList += "<img src='https://drive.google.com/uc?id=1PCjK9UoQ6QN6oA-MKGfd2QuKOWFj2OZc' style='vertical-align: middle;' width='25' height='25'> <span style='vertical-align: middle;'> Sanitation Issue </span><br>";
    if(vMarker.issMait === "true" || vMarker.maintenance_issues === true) tempVioList += "<img src='https://drive.google.com/uc?id=1aM_-QZOGA2uq_gDYHcxbk57VoLYGSIXz' style='vertical-align: middle;' width='25' height='25'> <span style='vertical-align: middle;'> Maitenance Issue </span><br>";
    if(vMarker.issVis === "true" || vMarker.visibility_issues === true) tempVioList += "<img src='https://drive.google.com/uc?id=1h_ciISvHyjemsS1LP8QDm39Hdo__wirA' style='vertical-align: middle;' width='25' height='25'> <span style='vertical-align: middle;'> Visibility Issue </span><br>";
    if(vMarker.issRWay === "true" || vMarker.right_of_way_issues === true) tempVioList += "<img src='https://drive.google.com/uc?id=1zMiQQbqFYWX-nzT9syvwtsqb2P8fJ8vx' style='vertical-align: middle;' width='25' height='25'> <span style='vertical-align: middle;'> Right-of-Way Issue </span><br>";
    if(vMarker.issPerm === "true" || vMarker.permit_issues === true) tempVioList += "<img src='https://drive.google.com/uc?id=146e9OP9h8yWqsOdnffxwiU85HxJOhD5c' style='vertical-align: middle;' width='25' height='25'> <span style='vertical-align: middle;'> Permit Issue </span><br>";
    if(vMarker.other === "true" || vMarker.other === true)  tempVioList += "<img src='https://drive.google.com/uc?id=1bb-2QSCYIcYjnVwM22cLstbfI1PQrBbY' style='vertical-align: middle;' width='25' height='25'> <span style='vertical-align: middle;'> Other </span><br>";

    return tempVioList;
  };

  //when the violation only has one violation, this function will be called to place a unique marker for whatever the violation of the address is
  var GetPreciseMarker = (markerVios) => {

    var tempUrl = "";

    //source images can be found in the images/markerSing folder to be placed on a different database
    if(markerVios.overOcc === "true") tempUrl = 'url(https://drive.google.com/uc?id=108p4ogE8uT6O2OSSr82Ij0WwtHAQxPce)';
    if(markerVios.illConst === "true") tempUrl = 'url(https://drive.google.com/uc?id=1f4D8ZvlDWWCT0czDQJKkVU9uakhn0_qK)';
    if(markerVios.illSign === "true") tempUrl = 'url(https://drive.google.com/uc?id=1hCHyFlZtmpMklEu_VISeMZcDrIXoNqLl)';
    if(markerVios.issSan === "true") tempUrl = 'url(https://drive.google.com/uc?id=1xUwLHOhJ0pgkxAr6zcNF7CUeAKT2IvNG)';
    if(markerVios.issMait === "true") tempUrl = 'url(https://drive.google.com/uc?id=1MUHdHszvwRZGIoORWePHwUFX9WBF7i5H)';
    if(markerVios.issVis === "true") tempUrl = 'url(https://drive.google.com/uc?id=1AZaTsoc-nJpAsm3_Wc0ErmIf7cvjU8YL)';
    if(markerVios.issRWay === "true") tempUrl = 'url(https://drive.google.com/uc?id=1icU6CHusknSIaLYA_1_s4CJGTTWsKx0R)';
    if(markerVios.issPerm === "true") tempUrl = 'url(https://drive.google.com/uc?id=1uZBEFNMvWKLapr3mfuzhKRq47j48AEA-)';
    if(markerVios.other === "true")  tempUrl = 'url(https://drive.google.com/uc?id=1a0_P7jJI46yMRHu_An6h_I3A-zphjLEk)';

    return tempUrl;

  }

  //when the violation has more than one violation, this function will be called to place a marker that corresponds with the number of violations at that address
  var getMarker = (markerInfo, markerVios) => {

    var tempUrl = "";

    if (markerInfo.numVios === 1) tempUrl = GetPreciseMarker(markerVios);
     else {
       
      //source images can be found in the images/markerMult folder to be placed on a different database
       if (markerInfo.numVios === 2) tempUrl = 'url(https://drive.google.com/uc?id=1_nQrxSmrSD4dR2eeYjdonRE3Myof7flJ)';
       if (markerInfo.numVios === 3) tempUrl = 'url(https://drive.google.com/uc?id=15lBXIeN__kaXlOlW9b2sDWRERrVM6EAs)';
       if (markerInfo.numVios === 4) tempUrl = 'url(https://drive.google.com/uc?id=1Iyg0fC87pxYY1Veaz4Mz9kOGwHxfYSFf)';
       if (markerInfo.numVios === 5) tempUrl = 'url(https://drive.google.com/uc?id=1Qo8D9JEQdRhthSmFzISLm_vf1u2V5CEq)';
       if (markerInfo.numVios === 6) tempUrl = 'url(https://drive.google.com/uc?id=1JEgRFjapMUtTPFRKPvwDnIztSoAIr-oe)';
       if (markerInfo.numVios === 7) tempUrl = 'url(https://drive.google.com/uc?id=1RnztvSoM4_dtQfMl1gA9vHr2xhEiAfjW)';
       if (markerInfo.numVios === 8) tempUrl = 'url(https://drive.google.com/uc?id=1S89JZwuHcbqZl18Fk7f0i03IYByF_0Hh)';
       if (markerInfo.numVios === 9) tempUrl = 'url(https://drive.google.com/uc?id=1W2v8zVj8SWczr36kyD1ZWDv0a22I8VIV)';
      }

      return tempUrl;

  }

  /* 
      Parameters:  markerInfo : object with information about the violation
                   markerDetails : (not used currently)
                   markerVios : violations at the location
      Description: Adds the popup at a marker, the popup contains info about the 
                   property located at that marker.
      Output:      none
  */
  const AddViolationPopup = (markerInfo, markerDetails, markerVios) => {
    
    var vioList = "";
    vioList = AddViolations(markerVios); //all violation HTMl text (and respective icons) are determined and saved into one variable

    var el = document.createElement('div');
    el.className = 'marker';
    el.style.backgroundImage = getMarker(markerInfo, markerVios); //function called to get proper marker for the particular address
    el.style.width = '50px'; //style sizing of the marker
    el.style.height = '50px';
    el.style.backgroundSize = '100%';
    el.draggable = false;

    //marker is created
    const vioMarker = new mapboxgl.Marker(el)
        .setLngLat([markerInfo.long, markerInfo.lat])
        .addTo(map.current);
    
    //marker is added to list for later deletion
    markerList.push(vioMarker);

    //creates popup for each respective violation location marker
    vioMarker.getElement().addEventListener('click', () => {
  
      const vioPopup = new mapboxgl.Popup({ closeOnClick: false })
      .setLngLat([markerInfo.long, markerInfo.lat])
      .setHTML('<font color = "#000000">' +
               '<h6><b>Address:</b></h6>' + markerInfo.addr +
               '<h6><b>Number of Violation(s):</b></h6>' + markerInfo.numVios +
               '<h6><b>Specific Violation(s):</b></h6>' + vioList +
               '<h6><b>Image(s):</b></h6>' +
               '<img src="https://ap.rdcpix.com/182362824/9c4c19d5deeaa8be055d5c9fc2e5cfc8l-m0xd-w200_h150_q80.jpg" alt="Property Image 1" width="100" height="67">' +
               '</font>')
      .addTo(map.current);
    });
  };

  /* 
      Parameters:  none
      Description: Adds the markers to the map corresponding to the result of the
                   pulled info on the violocation page. 
      Output:      none
  */
  const AddVioLocationMarkers = () => {

    //information for address violations is collected from local storage to be used to create violation markers
    var vioMarkerInfo = JSON.parse(window.localStorage.getItem("VioInfo"));
    var vioMarkerDetails = JSON.parse(window.localStorage.getItem("VioDetails"));
    var vioMarkerVios = JSON.parse(window.localStorage.getItem("VioVios"));
    console.log(vioMarkerInfo.length);
    console.log(vioMarkerDetails);
    console.log(vioMarkerVios);

    //popup details are created for each violation makrker that appear on the click of said marker
    for (var i = 1; i < vioMarkerInfo.length ; i++) AddViolationPopup(vioMarkerInfo[i], vioMarkerDetails[i], vioMarkerVios[i]);

    console.log(markerList);
  }

  //clears markerList, which collect all violation location markers as well as 'add violation' markers
  const ClearMarkers = () => {

    console.log(markerList.length);

    if(markerList.length > 0) {

      for (var i = 0; i < markerList.length; i++) {
        markerList[i].remove();
        markerList[i] = null;
        console.log(markerList.length);
      }
    }

  console.log(markerList);
}

  //this function is for the map style switcher on the left side of the map
  const switcher = () => {
    map.current.addControl(new MapboxStyleSwitcherControl(), 'top-left')
  } 



  /* 
      Parameters:  none
      Description: Sends the user to the edit violation page
      Output:      none
  */
  const EditViolations = () => {

    history.push({
      pathname: '/editViolation',
    });
  };

  /* 
      Parameters:  none
      Description: When routeState is true we record the coordinates of the user
                   and push it to the userCoordinates array.
      Output:      none
  */
  const RouteTracking = () => {

      if(routeState == true){
      navigator.geolocation.getCurrentPosition(position => {

        const userCoordinates = [position.coords.longitude, position.coords.latitude];
        console.log(userCoordinates); 


       routeCoordinates.push(userCoordinates);
       console.log(routeCoordinates);

       setTimeout(function() { RouteTracking() }, 1000);

      });

      }
    };

  /* 
      Parameters:  none
      Description: Begins tracking the route of the user.
      Output:      none
  */
  const BeginRoute = () => {   

    const startRouteButton = document.getElementsByClassName("startRouteButton"); 
    const endRouteButton = document.getElementsByClassName("endRouteButton"); 

    startRouteButton[0].disabled = true;
    startRouteButton[0].hidden = true;

    endRouteButton[0].disabled = false;
    endRouteButton[0].hidden = false;

    routeState = true;

    RouteTracking();
    

  };

  /* 
      Parameters:  string date, string employee id
      Description: Grab route object from database.
      Output:      Route object (promise) found in database fitting given parameters.
  */
  async function uploadRoute(e)
  {
    const app = new Realm.App({ id: "code_commander-nxdva" });
      const credentials = Realm.Credentials.anonymous();
      try {
        const user = await app.logIn(credentials);
        ViolationFunctions.default.addRoute(e);                 

      } catch(err) {
        console.error("Failed to log in", err);
      }
  }

  /* 
      Parameters:  string date, string employee id
      Description: Grab route object from database.
      Output:      Route object (promise) found in database fitting given parameters.
  */
  async function getRoute(date, id)
    {
      const app = new Realm.App({ id: "code_commander-nxdva" });
      const credentials = Realm.Credentials.anonymous();
      try {
        const user = await app.logIn(credentials);
        return ViolationFunctions.default.routeLookUp(date, id);                 

      } catch(err) {
        console.error("Failed to log in", err);
      }
    }

  
  /* 
    Parameters:  none
    Description: Ends the currently being driven route. 
                 Adds the route information to the database and generates a
                 visualiztion of the route on the map. 
    Output:      none
  */
  const EndRoute = () => {   

    const startRouteButton = document.getElementsByClassName("startRouteButton");
    const endRouteButton = document.getElementsByClassName("endRouteButton"); 

    startRouteButton[0].disabled = false;
    startRouteButton[0].hidden = false;

    endRouteButton[0].disabled = true;
    endRouteButton[0].hidden = true;

    // Stop route and save info

      routeState = false;

      var current_date = new Date();

      var dd = String(current_date.getDate()).padStart(2, '0');
      var mm = String(current_date.getMonth() + 1).padStart(2, '0'); //January is 0!
      var yyyy = current_date.getFullYear();

      var parsed_date = `${yyyy}-${mm}-${dd}`;

      const route_document = {
        employeeID: "124123",
        route_array: routeCoordinates,
        violation_pathed: violationCoordinates,
        date: parsed_date,
      }

      uploadRoute(route_document);

      var routeMarker;
      violationCoordinates.forEach( function(element) {

        routeMarker = new mapboxgl.Marker({
          color: "#FF0000", draggable: false
        }).setLngLat([element[0], element[1]]).addTo(map.current);

        console.log(element);

      });

      map.current.addSource('route', {
      
        'type': 'geojson',
        'data': {
          'type': 'Feature',
          'properties': {},
          'geometry': {
          'type': 'LineString',
          'coordinates': routeCoordinates,
          }
        }
  
        });
  
  
      map.current.addLayer({
        'id': 'route',
        'type': 'line',
        'source': 'route',
        'layout': {
        'line-join': 'round',
        'line-cap': 'round'
        },
        'paint': {
        'line-color': '#FF0000',
        'line-width': 5
        }

      });

  };


  /* 
    Parameters:  none
    Description: Cause the form that allows displaying a previously driven route to unhide itself.
    Output:      none
  */
  const ShowRouteGroup = () => {

    const routeGroup = document.getElementsByClassName("route-group"); 

    routeGroup[0].disabled = false;
    routeGroup[0].hidden = false;
    
  };


  /* 
    Parameters:  none
    Description: Using the information given in the route search box grabs the route
                   and plots it on the map.
    Output:      none
  */
  const DisplayRoute = () => {

    var routeInfo = getRoute(date, id); 

    console.log(date);
    console.log(id);

    var tag = date + id;


    routeInfo.then(function(contents) {

      var fixed = []
      var vios = []

      // Takes the route coordinates and adds them into new array after being parsed
      // Takes $numberDouble coords and parses to floats so it can be used

      contents.data.route_array.forEach( function(element) {

          var x = element[0];
          var y = element[1];
          
          x = x.$numberDouble;
          y = y.$numberDouble;

          x = parseFloat(x);
          y = parseFloat(y);

          fixed.push([x, y])
      });

      contents.data.violation_pathed.forEach( function(element) {

        var a = element[0];
        var b = element[1];
        
        a = a.$numberDouble;
        b = b.$numberDouble;
  
        a = parseFloat(a);
        b = parseFloat(b);

        vios.push([a,b]);
      });

      map.current.addSource('route2', {
      
        'type': 'geojson',
        'data': {
          'type': 'Feature',
          'properties': {},
          'geometry': {
          'type': 'LineString',
          'coordinates': fixed,
          }
        }
  
        });
  
  
      map.current.addLayer({
        'id': 'route2',
        'type': 'line',
        'source': 'route2',
        'layout': {
        'line-join': 'round',
        'line-cap': 'round'
        },
        'paint': {
        'line-color': '#FF0000',
        'line-width': 5
        }
  
      });


      /* Plots a marker for each violation noted along recently finished route */
      var routeMarker;
      vios.forEach( function(element) {
        routeMarker = new mapboxgl.Marker({
          color: "#FF0000", draggable: false
        }).setLngLat([element[0], element[1]]).addTo(map.current);

      });

      var start_coords = [];
      var end_coords = [];

      start_coords = fixed[0];

      var elemCount = fixed.length;

      end_coords = fixed[elemCount - 1];


      var startMarker = new mapboxgl.Marker({
        color: "#00FF00", draggable: false
      }).setLngLat([start_coords[0], start_coords[1]]).addTo(map.current);

      var endtMarker = new mapboxgl.Marker({
        color: "#026440", draggable: false
      }).setLngLat([end_coords[0], end_coords[1]]).addTo(map.current);

      
    });
    
    const routeGroup = document.getElementsByClassName("route-group"); 

    routeGroup[0].disabled = true;
    routeGroup[0].hidden = true;

  
  };

  return (
    <IonPage>
    <IonContent fullscreen>
       
        <div ref={mapContainer} className="map-container"></div>
        <div ref={geocodeContainer} id='geocoder' className='geocoder'></div>

      

        <IonFab vertical="bottom" horizontal="start" slot="fixed">
          <IonFabButton className="startRouteButton" color="secondary" onClick={(e) => {ClearMarkers();BeginRoute();}}>
            <IonIcon icon={playOutline} size="large" color="light"/>
          </IonFabButton>
        </IonFab>


        <IonFab vertical="bottom" horizontal="start" slot="fixed">
          <IonFabButton className="endRouteButton" disabled="true" hidden="true" color="danger" onClick={EndRoute}>
            <IonIcon icon={stopOutline} size="large" color="light"/>
          </IonFabButton>
        </IonFab>

        {/* Directions fab button for user to press to then enter an address to go to */}
        <IonFab vertical="bottom" horizontal="start" slot="fixed">
          <IonFabButton className="navButton" color="success" onClick={showNavigation}>
            <IonIcon icon={compassOutline} size="large" color="light"/>
          </IonFabButton>
        </IonFab>

        {/* Violations fab button for user to go to various settings relating to violations */}
        <IonFab vertical="bottom" horizontal="start" slot="fixed">
          <IonFabButton className="vioButton" color="danger">
            <IonIcon icon={warningOutline} size="large" color="light"/>
          </IonFabButton>
          <IonFabList side="top">

            {/* routerLink redirects to charts_page (route path in App.js)*/}
            <IonFabButton className="chartButton" onClick = {(e) => {SetMapRequest();ClearMarkers();}} color="tertiary" routerLink = "/charts">
              <IonIcon icon={barChartOutline} size="large" color="light"/> 
            </IonFabButton>

            {/* routerLink redirects to routes_page (route path in App.js)*/}
            <IonFabButton className="routesButton" onClick={(e) => {ShowRouteGroup();SetMapRequest();ClearMarkers();}} color="primary">
              <IonIcon icon={carOutline} size="large" color="light"/> 
            </IonFabButton>

            {/* routerLink redirects to violocation_page (route path in App.js)*/}
            <IonFabButton className="vioLocationButton" color="secondary" onClick ={(e) => {SetMapRequest();ClearMarkers();}} routerLink = "/vioLocation">
              <IonIcon icon={locationOutline}  size="large" color="light"/>
            </IonFabButton>
        
        </IonFabList>
        </IonFab>  

        <div className = "route-group" hidden="true" disabled="true">
        <IonInput placeholder="Employee ID" className="id-box" value={id} onIonInput={(e) => setid(e.target.value)} onIonChange={(e) => setid(e.detail.value)} ></IonInput>

        <IonInput placeholder="Date of Route (YYYY-MM-DD)" className="date-box" value={date} onIonInput={(e) => setDate(e.target.value)} onIonChange={(e) => setDate(e.detail.value)} ></IonInput>

        <IonButton color="goblin" className="route-display-button" onClick={DisplayRoute} >Show Route</IonButton>
        </div>
     

    </IonContent>
    </IonPage>
  );
};
