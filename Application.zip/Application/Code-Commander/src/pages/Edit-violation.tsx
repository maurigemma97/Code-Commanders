import React, { useCallback, useEffect, useRef, useState } from "react";
import {IonBackButton, IonButton, IonButtons, IonCheckbox, IonContent, IonDatetime, IonHeader, IonIcon, IonInput, IonItem, IonItemDivider, IonLabel, IonList, IonPage,IonRange, IonSelect, IonSelectOption, IonTextarea, IonTitle, IonToolbar} from "@ionic/react";
import { useHistory } from "react-router-dom";

import 'mapbox-gl/dist/mapbox-gl.css';
import MapboxGeocoder from '@mapbox/mapbox-gl-geocoder';
import mapboxgl from "mapbox-gl";
import { image } from "ionicons/icons";
import * as Realm from "realm-web";
import * as ViolationFunctions from "../services/Functions.js";
import "../theme/create.css";

const EditViolation_page: React.FC = () => {

  interface ViolationEntry {
    address: string,
    city: string,
    state: string,
    zip_code: string,
    country: string,
    violations: number,
    over_occupancy: boolean,
    illegal_construction: boolean,
    illegal_signage: boolean,
    sanitation_issues: boolean,
    maintenance_issues: boolean,
    visibility_issues: boolean,
    right_of_way_issues: boolean,
    permit_issues: boolean,
    other: boolean,
    notes: string,
    coordinates: [ number, number ],
    date_added: string,
    date_updated: string,
    date_completed: string,
  };

  var entry: ViolationEntry = {
    address: newAddress as string,
    city: "",
    state: "",
    zip_code: "",
    country: "",
    violations: 0,
    over_occupancy: newOccupancy as boolean,
    illegal_construction: newConstruction as boolean,
    illegal_signage: newSignage as boolean,
    sanitation_issues: newSanitation as boolean,
    maintenance_issues: newMaintenance as boolean,
    visibility_issues: newVisibility as boolean,
    right_of_way_issues: newROW as boolean,
    permit_issues: newPermit as boolean,
    other: newOther as boolean,
    notes: newNotes as string,
    coordinates: [ 0, 0 ],
    date_added: "",
    date_updated: "",
    date_completed: "",
  };

  var [address, setAddress] = useState<string>();
  const [date, setDate] = useState<string>();
  const [violation_type, setViolationType] = useState<string[]>([]);
  const [notes, setNotes] = useState<string>();
  var [shouldAdd, setAdd] = useState<boolean>();
  let history = useHistory();

  const [doAdd, setDoAdd] = useState<boolean>(false);

  var [newAddress, setNewAddress] = useState<string>();
  var [newCoords, setNewCoords] = useState<any[]>([]);
  var [newDateAdded, setNewDataAdded] = useState<string>();
  var [newDateCompleted, setNewDateCompleted] = useState<string>();
  var [newDateUpdated, setNewDateUpdated] = useState<string>();
  
  var [newOccupancy, setNewOccupancy] = useState<boolean>();
  var [newConstruction, setNewConstruction] = useState<boolean>();
  var [newSignage, setNewSignage] = useState<boolean>();
  var [newMaintenance, setNewMaintenance] = useState<boolean>();
  var [newPermit, setNewPermit] = useState<boolean>();
  var [newSanitation, setNewSanitation] = useState<boolean>();
  var [newROW, setNewROW] = useState<boolean>();
  var [newVisibility, setNewVisibility] = useState<boolean>();
  var [newOther, setNewOther] = useState<boolean>();

  var [newNotes, setNewNotes] = useState<string>();
  var [newZip, setNewZip] = useState<string>();


    async function addViolationToDatabase(e: ViolationEntry)
    {
      const app = new Realm.App({ id: "code_commander-nxdva" });
      const credentials = Realm.Credentials.anonymous();
      try {
        const user = await app.logIn(credentials);
        ViolationFunctions.default.upload(e);                 

      } catch(err) {
        console.error("Failed to log in", err);
      }
    }

    async function getFromDatabase(address: String)
    {
      const app = new Realm.App({ id: "code_commander-nxdva" });
      const credentials = Realm.Credentials.anonymous();
      try {
        const user = await app.logIn(credentials);
        var response = await ViolationFunctions.default.findByAddr(address);
        return response;               

      } catch(err) {
        console.error("Failed to log in", err);
      }
    }

    const PullInfo = () => {

      var abc = getFromDatabase(address as string);

      setTimeout(function() { waitForViolation(abc) }, 1000);

    };

    function waitForViolation (e :any) {

      e.then(function(contents: any){

        setNewAddress(contents.data.address);

        setNewNotes(contents.data.notes);

        setViolationType(violation_type);

        var violation_holder = ["", "", "", "", "", "", "", "", "", ""];


      if(contents.data.over_occupancy == true){ violation_holder[0] = "Illegal Over Occupancy"; }
      if(contents.data.illegal_construction == true){ violation_holder[1] = "Illegal Construction"; }
      if(contents.data.sanitation_issues == true){ violation_holder[2] = "Sanitation Issues"; }
      if(contents.data.maintenance_issues == true){ violation_holder[3] = "Maintenance Issues"; }
      if(contents.data.illegal_signage == true){ violation_holder[4] = "Illegal Signage"; }
      if(contents.data.visibility_issues == true){ violation_holder[5] = "Visibility Issues"; }
      if(contents.data.right_of_way_issues == true){ violation_holder[6] = "Right-of-Way Issues"; }
      if(contents.data.permit_issues == true){ violation_holder[7] = "Permit Assistance"; }
      if(contents.data.other == true){ violation_holder[8] = "Other"; }


      setViolationType(violation_holder);

      entry.city = "Bowling Green";
      entry.country = "United States of America";
      entry.zip_code = "43402";
      entry.address = newAddress as string;
      entry.notes = newNotes as string;
      entry.illegal_construction = newConstruction as boolean;
      entry.illegal_signage = newSignage as boolean;
      entry.sanitation_issues = newSanitation as boolean;
      entry.maintenance_issues = newMaintenance as boolean;
      entry.visibility_issues = newVisibility as boolean;
      entry.right_of_way_issues = newROW as boolean;
      entry.permit_issues = newPermit as boolean;
      entry.other = newOther as boolean;

      //waitToAdd(e);

      })
  
    }

    const waitToAdd = (e: any ) => {
      if(doAdd == true){
        SaveEdits(e);
      }
      else{
        setTimeout(function() { waitToAdd(e) }, 1000);
      }
    }

    const SaveEdits = (e :any) => {

      var vio_count = 0;

      var current_date = new Date();

      var dd = String(current_date.getDate()).padStart(2, '0');
      var mm = String(current_date.getMonth() + 1).padStart(2, '0'); //January is 0!
      var yyyy = current_date.getFullYear();

      var parsed_date = `${yyyy}-${mm}-${dd}`;

      if(violation_type.includes("Illegal Occupancy Use")){ newOccupancy = true; vio_count++; }
      if(violation_type.includes("Illegal Construction")){ newConstruction = true; vio_count++; }
      if(violation_type.includes("Sanitation Issues")){ newSanitation = true; vio_count++; }
      if(violation_type.includes("Maintenance Issues")){ newMaintenance = true; vio_count++; }
      if(violation_type.includes("Illegal Signage")){ newSignage = true; vio_count++; }
      if(violation_type.includes("Visibility Issues")){ newVisibility = true; vio_count++; }
      if(violation_type.includes("Right-of-Way Issues")){ newROW = true; vio_count++; }
      if(violation_type.includes("Permit Assistance")){ newPermit = true; vio_count++; }
      if(violation_type.includes("Other")){ newOther = true; vio_count++; }

      entry = {
        address: newAddress as string,
        city: "Bowling Green",
        state: "Ohio",
        zip_code: "44805",
        country: "United States of America",
        violations: vio_count as number,
        over_occupancy: newOccupancy as boolean,
        illegal_construction: newConstruction as boolean,
        illegal_signage: newSignage as boolean,
        sanitation_issues: newSanitation as boolean,
        maintenance_issues: newMaintenance as boolean,
        visibility_issues: newVisibility as boolean,
        right_of_way_issues: newROW as boolean,
        permit_issues: newPermit as boolean,
        other: newOther as boolean,
        notes: newNotes as string,
        coordinates: newCoords as [number, number],
        date_added: newDateAdded as string,
        date_updated: parsed_date as string,
        date_completed: newDateCompleted as string
      };
      console.log(entry);
      //addViolationToDatabase(entry); COMMENTED OUT TO NOT ADD BUNCH OF STUFF TO DATABASE

      shouldAdd = true;
      const violation_data = [address, shouldAdd, violation_type, notes];

      history.push({
        pathname: '/home',
        state: violation_data
      });

      ClearPage();

    };

    const ChangeDoAdd = () => {
      setDoAdd(true);
    }

    const ClearPage = () => {
      setAddress("");
      setNewAddress("");
      setNewNotes("");
      setViolationType([]);
    };

    async function DeleteAll()
    {
      const app = new Realm.App({ id: "code_commander-nxdva" });
      const credentials = Realm.Credentials.anonymous();
      try {
        const user = await app.logIn(credentials);
        var response = await ViolationFunctions.default.PermanentDelete(address);
        return response;               

      } catch(err) {
        console.error("Failed to log in", err);
      }

      history.push({
        pathname: '/home'
      });

    }

    async function ResolveAll()
    {
      const app = new Realm.App({ id: "code_commander-nxdva" });
      const credentials = Realm.Credentials.anonymous();
      try {
        const user = await app.logIn(credentials);
        var response = await ViolationFunctions.default.Completed(address);
        return response;               

      } catch(err) {
        console.error("Failed to log in", err);
      }

      history.push({
        pathname: '/home'
      });
      
    }

    const options = {
      cssClass: 'my-custom-interface'
    };

    return (
     <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Edit Violation</IonTitle>
          <IonButtons slot="start">
          <IonBackButton defaultHref="home" color="goblin"/>
        </IonButtons>
        </IonToolbar>
      </IonHeader>
  
    <IonContent>
     <IonList>

     <IonItem>
            <IonLabel>Address to Edit:</IonLabel>
            <IonInput class="addrInput" value={address} onIonInput={(e: any) => setAddress(e.target.value)} onIonChange={(e: any) => setAddress(e.detail.value!)} ></IonInput>
       </IonItem>


      </IonList>

        <IonButton color="goblin" class="pullButton" size="large" expand="block" onClick={PullInfo}>Pull Violations</IonButton>
        &nbsp; &nbsp;&nbsp; &nbsp;

      <IonList>
        <IonItem>
          <IonLabel>Address:</IonLabel>
          <IonInput value={newAddress} onIonChange={(e: any) => setNewAddress(e.detail.value!)}></IonInput>
        </IonItem>

        <IonItem>
            <IonLabel>Violation(s)</IonLabel>
            <IonSelect interfaceOptions={options} class="vioSelect" name="violation_picker" value={violation_type} placeholder="Select one" multiple={true} onIonChange={e => setViolationType(e.detail.value!)}>
              <IonSelectOption value="Illegal Occupancy Use" >Illegal Occupancy Use</IonSelectOption>
              <IonSelectOption value="Illegal Construction">Illegal Construction</IonSelectOption>
              <IonSelectOption value="Sanitation Issues">Sanitation Issues</IonSelectOption>
              <IonSelectOption value="Maintenance Issues">Maintenance Issues</IonSelectOption>
              <IonSelectOption value="Illegal Signage">Illegal Signage</IonSelectOption>
              <IonSelectOption value="Visibility Issues">Visibility Issues</IonSelectOption>
              <IonSelectOption value="Right-of-Way Issues">Right-of-Way Issues</IonSelectOption>
              <IonSelectOption value="Permit Assistance">Permit Assistance</IonSelectOption>
              <IonSelectOption value="Other">Other</IonSelectOption>
            </IonSelect>
          </IonItem>

          <IonItem>
          <IonLabel>Notes:</IonLabel>
          <IonInput class="noteBox" value={newNotes} onIonChange={(e: any) => setNewNotes(e.detail.value!)}></IonInput>
        </IonItem>

        &nbsp; &nbsp;

      </IonList>

     <IonButton color="goblin" class="saveButton" size="large" expand="block" onClick={(e: any) => SaveEdits(entry)}>Save Changes</IonButton> &nbsp; &nbsp;

     <IonButton color="goblin" class="deleteButton" size="large" expand="block" onClick={(e: any) => ResolveAll()}>Resolve All</IonButton> &nbsp; &nbsp;

     <IonButton class="deleteButton" color="danger" size="large" expand="block" onClick={(e: any) => DeleteAll()}>DELETE ALL</IonButton>

  </IonContent>
</IonPage>
    );
};

export default EditViolation_page;