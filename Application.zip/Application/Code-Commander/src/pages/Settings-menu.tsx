import React from "react";
import {IonBackButton, IonButton, IonButtons, IonContent, IonHeader, IonIcon, IonItem, IonItemDivider, IonList, IonPage, IonTitle, IonToolbar} from "@ionic/react";
import { settings } from 'ionicons/icons';

/* 
save for attempt on Sprint #9

const layerList = document.getElementById('menu');
const button = layerList?.getElementsByTagName('inputs');

for (const input of button) {
  input.onclick = (layer) => {
    const layerId = layer.target.id;
    map.setstyle('mapbox://styles/mapbox/' + layerId);
  };
}
*/
const Settings_page: React.FC = () => {
    return (
     <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonButtons slot="start">
            <IonBackButton defaultHref="home" />
              <IonIcon icon={settings} size="large" />
         </IonButtons>             
          <IonTitle>Map Settings</IonTitle>
        </IonToolbar>
      </IonHeader>
  
    <IonContent>
     <IonList>
      <IonItemDivider>Map Type</IonItemDivider>

      <IonItem>
        <IonButton class = "button" expand = "block">Standard</IonButton>
      </IonItem>

      <IonItem>
        <IonButton class = "button" expand = "block">Satellite</IonButton>
      </IonItem>

    </IonList>

  </IonContent>
</IonPage>
    );
};

export default Settings_page;