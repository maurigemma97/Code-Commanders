import React, { Component, useState } from 'react';
import { IonBackButton,IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonInput, IonItem, IonList, IonItemDivider, IonButtons } from '@ionic/react';
import * as Realm from "realm-web";
import * as writeTxt from "../services/writeTxt.js";

//fetches the information from the database
async function getAll(addr: any)
{
  const app = new Realm.App({ id: "code_commander-nxdva" });
  const credentials = Realm.Credentials.anonymous();
  try {
    const user = await app.logIn(credentials);
    const result = await user.functions.returnAllRecords("Baddies", "2022Violations");
    console.log(result + addr);
  } catch(err) {
    console.error("Failed to log in", err);
  }
}
//input the date in the search bar to display on the chart
export function getCurrentDate(separator=''){

  let newDate = new Date()
  let date = newDate.getDate();
  let month = newDate.getMonth() + 1;
  let year = newDate.getFullYear();
  
  return `${year}${separator}${month<10?`0${month}`:`${month}`}${separator}${date}`
}

const Navigation_page: React.FC = () => {

  const [text, setText] = useState<string>();
  // const [number, setNumber] = useState<number>();

 

  return (
    <IonPage className="Page">
      <IonHeader>
        <IonToolbar>
          <IonTitle className="Title">Navigation</IonTitle>
          <IonButtons slot="start">
          <IonBackButton defaultHref="home" />
          </IonButtons>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <IonList>
          <IonItem>
            <IonInput type="text" value={text} placeholder={getCurrentDate('/')} onIonChange={e => setText(e.detail.value!)}></IonInput>
          </IonItem>
          <iframe width="500" height={600} src="https://charts.mongodb.com/charts-project-0-qophj/embed/charts?id=623084e4-1a35-4aa7-8d84-45c3c2403df9&maxDataAge=3600&theme=light&autoRefresh=true"></iframe>
        </IonList>
      </IonContent>
    </IonPage>
  );
};

export default Navigation_page
