import React, {useState} from "react";
import {IonButton, IonButtons, IonBackButton, IonCheckbox, IonCol, IonContent, IonDatetime, IonGrid, IonHeader, IonIcon, IonItem, IonItemDivider, IonLabel, IonList, IonModal, IonPage, IonRow, IonTitle, IonToolbar } from "@ionic/react";
import ShowViolations from "../components/showViolations";
import ReactDOM from 'react-dom';


// global array for the Show All Violations checkbox
const allViolationsList = [
  {val: "Show All Violations", isChecked: true, isDisabled: false}
];

// global array for the individual violation type checkboxes 
const violationsCheckboxList = [
  {val: "Illegal Occupancy Use", isChecked: false, isDisabled: true},
  {val: "Illegal Construction", isChecked: false, isDisabled: true},
  {val: "Sanitation Issues", isChecked: false, isDisabled: true},
  {val: "Maitenance Issues", isChecked: false, isDisabled: true},
  {val: "Illegal Signage", isChecked: false, isDisabled: true},
  {val: "Visibility Issues", isChecked: false, isDisabled: true},
  {val: "Right-of-Way Issues", isChecked: false, isDisabled: true},
  {val: "Permit Assistance", isChecked: false, isDisabled: true},
  {val: "Other", isChecked: false, isDisabled: true}
];

// global array for the resolved options checkboxes
const resolvedList = [
  {val: "Show Resolved Violations", isChecked: false, isDisabled: false},
  {val: "Show Only Resolved Violations", isChecked: false, isDisabled: true}
];

// global array for the updated options checkboxes
const updatedList = [
  {val: "Show Updated Violations", isChecked: false, isDisabled: false},
  {val: "Show Only Updated Violations", isChecked: false, isDisabled: true}
];

// global array for the all wards checkbox (location groupings through the city)
const allWardsList = [
  {val: "Show All Wards", isChecked: true, isDisabled: false}
];

// global array for the individual wards checkboxes; currently only used as a space filler for later use in development
const wardsCheckboxList = [
  {val: "Ward 1", isChecked: false, isDisabled: true},
  {val: "Ward 2", isChecked: false, isDisabled: true},
  {val: "Ward 3", isChecked: false, isDisabled: true},
  {val: "Ward 4", isChecked: false, isDisabled: true}
];


const VioLocation_page: React.FC = () => {


  const [checked, setChecked] = useState(allViolationsList); // useState for setting check properties in arrays above
  const [disabled, setUsable] = useState(allViolationsList); // useState for setting disable properties in arrays above


  const [VioCount, setVioCount] = useState(9); // useState for the number of violations selected map on "ShowViolations"
  // next 9 useStates are for the 9 different types of violations
  const [OverOccupancy, setOverOccupancy] = useState(true);
  const [IllegalConstruction, setIllegalConstruction] = useState(true);
  const [Sanitation, setSanitation] = useState(true);
  const [Maintenance, setMaintenance] = useState(true);
  const [IllegalSignage, setIllegalSignage] = useState(true);
  const [VisibilityIssues, setVisibilityIssues] = useState(true);
  const [RightOfWayIssues, setRightOfWayIssues] = useState(true);
  const [PermitIssues, setPermitIssues] = useState(true);
  const [Other, setOther] = useState(true);

  // One piece to note for the two initial state for the two next useStates. When the Date objects are made, they are created with timezones of UTC. When changed to ISO string, time zones would be eliminated. Though a problem here is that when it is about 9PM in Eastern Time Zone, the ISO string will think it is the next day. So April 15 2022 @ 9PM in Date object is April 16 2022 in ISO string
  const [initialDate, setInitialDate] = useState<string>((new Date()).toISOString()); // useState for  ionDateTime "Start Date" calender. 
  const [endDate, setEndDate] = useState<string>((new Date()).toISOString()); // useState for ionDateTime "End Date" calender


  const [readStart, setReadStart] = useState<string>("0000-00-00");
  const [readEnd, setReadEnd] = useState<string>("9999-99-99");

  
  const setMapRequest = () => {

    var mapRequest = "true";
    localStorage.setItem('vioMapRequest', mapRequest);

  }

  // function that will send the props to showViolations
  async function changeCount() {
    var table = 0;

    if(resolvedList[0].isChecked){
      table = 1;
    }
    if(resolvedList[1].isChecked){
      table = 2;
    }
    ReactDOM.render(
      <React.StrictMode>
        <ShowViolations vioCount = {VioCount} overocc = {OverOccupancy} illCons = {IllegalConstruction} sanitation = {Sanitation} maintenance = {Maintenance} illSign = {IllegalSignage} Vis = {VisibilityIssues} row = {RightOfWayIssues} permit = {PermitIssues} other = {Other} 
        dateStart = {readStart} dateEnd = {readEnd} table = {table}/>
      </React.StrictMode>,
      document.getElementById('root')
    );
  }

  //function that changes the violation sheckboxes to being true or false
  const changeViolationSubboxValues = (value: string, check: boolean) =>{
    const tempList = [...violationsCheckboxList]

    if (value === "Illegal Occupancy Use") {
      tempList[0].isChecked = check
      changeOverOccupancy()
    }
    else if (value === "Illegal Construction") {
      tempList[1].isChecked = check
      changeIllegalConstruction()
    }
    else if (value === "Sanitation Issues") {
      tempList[2].isChecked = check
      changeSanitationIssues()
    }
    else if (value === "Maitenance Issues") {
      tempList[3].isChecked = check
      changeMaintenanceIssues()
    }
    else if (value === "Illegal Signage") {
      tempList[4].isChecked = check
      changeIllegalSignage()
    }
    else if (value === "Visibility Issues") {
      tempList[5].isChecked = check
      changeVisibilityIssues()
    }
    else if (value === "Right-of-Way Issues") {
      tempList[6].isChecked = check
      changeRightOfWayIssues()
    }
    else if (value === "Permit Assistance") {
      tempList[7].isChecked = check
      changePermitIssues()
    }
    else {
      tempList[8].isChecked = check
      changeOther()
    }
    setChecked(tempList) // set check for violationsCheckboxList
  }

  // Controls when the resolved/updated violations can be selected and whcih ward to select from
  const changeSubCheckboxes = (value: string, check: boolean) =>{
    if(value === "Show Resolved Violations") { 
      const tempListPrime = [...resolvedList] 
    
      if (check === true) {
        tempListPrime[0].isChecked = check
        tempListPrime[1].isChecked = false
        tempListPrime[1].isDisabled = false
      }
      if (check === false) {
        tempListPrime[0].isChecked = check
        tempListPrime[1].isChecked = false
        tempListPrime[1].isDisabled = true
      }

      setChecked(tempListPrime)
      setUsable(tempListPrime)
    } 
    if(value === "Show Only Resolved Violations") { 
      const tempListPrime = [...resolvedList] 
    
      if (check === true) {
        tempListPrime[1].isChecked = check
      }
      if (check === false) {
        tempListPrime[1].isChecked = check
      }

      setChecked(tempListPrime)
    } 
    if(value === "Show Updated Violations") { 
      const tempListPrime = [...updatedList] 
    
      if (check === true) {
        tempListPrime[0].isChecked = check
        tempListPrime[1].isChecked = false
        tempListPrime[1].isDisabled = false
      }
      if (check === false) {
        tempListPrime[0].isChecked = check
        tempListPrime[1].isChecked = false
        tempListPrime[1].isDisabled = true
      }

      setChecked(tempListPrime)
      setUsable(tempListPrime)
    }
    if(value === "Show All Wards") {
      const tempListPrime = [...allWardsList]  
      const tempList = [...wardsCheckboxList]

      if (check === true) {
        tempListPrime[0].isChecked = check

        tempList.forEach(function(item){
        item.isChecked = false
        item.isDisabled = true
        })
      }
      if (check === false) {
        tempListPrime[0].isChecked = check

        tempList.forEach(function(item){
          item.isChecked = true
          item.isDisabled = false
        })
      }
      setChecked(tempListPrime)
      setUsable(tempListPrime)
      setChecked(tempList)
      setUsable(tempList)       
    }
  }
  // function that will select or unselect all the violation check boxes
  const changeViolationSubboxes = (value: string, check: boolean) => {
    const tempListPrime = [...allViolationsList]  
    const tempList = [...violationsCheckboxList]

    tempListPrime[0].isChecked = check
    // all individual violation type checkboxes are unchecked
    if (check === true) {

      tempList.forEach(function(item){
      item.isChecked = false
      item.isDisabled = true
      })

    }
    else if (check === false) { // all individual violation type checkboxes are unchecked

      tempList.forEach(function(item){
        item.isChecked = true
        item.isDisabled = false
      })

    }

    setChecked(tempListPrime)
    setUsable(tempListPrime)   
    setChecked(tempList)
    setUsable(tempList) 

    setVioCount(9)
    setOverOccupancy(true)
    setIllegalConstruction(true)
    setSanitation(true)
    setMaintenance(true)
    setIllegalSignage(true)
    setVisibilityIssues(true)
    setRightOfWayIssues(true)
    setPermitIssues(true)
    setOther(true)
  }
  // next 9 functions will change the useState of the respective violation and increase or decrease the count of violations
  async function changeOverOccupancy(){
  
    if (OverOccupancy === false){
      setOverOccupancy(true);
      setVioCount(VioCount + 1);
    }
    else {
      setOverOccupancy(false);
      setVioCount(VioCount - 1);
    }
  }

  async function changeIllegalConstruction() {
    if (IllegalConstruction === false){
      setIllegalConstruction(true);
      setVioCount(VioCount + 1);
    }
    else{
      setIllegalConstruction(false);
      setVioCount(VioCount - 1);
    } 
  }

  async function changeSanitationIssues() {
    if(Sanitation === false){
      setSanitation(true);
      setVioCount(VioCount + 1);
    }
    else{
      setSanitation(false);
      setVioCount(VioCount - 1);
    }
  }

  async function changeMaintenanceIssues() {
    if(Maintenance === false){
      setMaintenance(true);
      setVioCount(VioCount + 1);
    }
    else{
      setMaintenance(false);
      setVioCount(VioCount - 1);
    }
  }

  async function changeIllegalSignage() {
    if(IllegalSignage === false){
      setIllegalSignage(true);
      setVioCount(VioCount + 1);
    }
    else{
      setIllegalSignage(false);
      setVioCount(VioCount - 1);
    }
  }

  async function changeVisibilityIssues() {
    if(VisibilityIssues === false){
      setVisibilityIssues(true);
      setVioCount(VioCount + 1);
    }
    else{
      setVisibilityIssues(false);
      setVioCount(VioCount - 1);
    }
  }

  async function changeRightOfWayIssues() {
    if(RightOfWayIssues === false){
      setRightOfWayIssues(true);
      setVioCount(VioCount + 1);
    }
    else{
      setRightOfWayIssues(false);
      setVioCount(VioCount - 1);
    }
  }

    async function changePermitIssues() {
      if(PermitIssues === false){
        setPermitIssues(true);
        setVioCount(VioCount + 1);
      }
      else{
        setPermitIssues(false);
        setVioCount(VioCount - 1);
      }
    }

      async function changeOther() {
        if(Other === false){
          setOther(true);
          setVioCount(VioCount + 1);
        }
        else{
          setOther(false);
          setVioCount(VioCount - 1);
        }
  }

  // saves the starting date from the calender that the user chose for the date range
  const startChange = (tempStart: string) => {
    setReadStart(tempStart.slice(0, 10));

    // double set to get the correct date inside the "setReadStart" useState
    setReadStart(tempStart.slice(0, 10));
  }

  // saves the ending date from the calender that the user chose for the date range
  const endChange = (tempEnd: string) => {
    setReadEnd(tempEnd.slice(0, 10));

    // double set to get the correct date inside the "setReadEnd" useState
    setReadEnd(tempEnd.slice(0, 10));
  }

    return (
     <IonPage>
       
      <IonHeader>
        <IonToolbar>
        <IonButtons slot="start">
            <IonBackButton defaultHref="home" color="goblin"/>
         </IonButtons>    
            <IonTitle>Violation Location Map</IonTitle>

        </IonToolbar>
      </IonHeader>
  
    <IonContent>

    <IonList>
      <IonItemDivider>Adjust Violation Date Range</IonItemDivider>

      {/*Grid for the calenders*/}
      <IonGrid>
          <IonRow>
            <IonCol>
              <IonItem>
                <IonLabel>Start Date</IonLabel>
                <IonDatetime color="goblin" value={initialDate} presentation="date" placeholder="Select Date" onIonChange={e => {startChange(e.detail.value!)}}></IonDatetime>
              </IonItem>   
            </IonCol>
            <IonCol>
            <IonItem>
                <IonLabel>End Date</IonLabel>
                <IonDatetime color="goblin" value={initialDate} presentation="date" placeholder="Select Date" onIonChange={e => {endChange(e.detail.value!)}}></IonDatetime>
              </IonItem>
            </IonCol>        
          </IonRow>
      </IonGrid>

    </IonList>
    {/*Checkbox for "Show All Violations" */}
    <IonItemDivider></IonItemDivider>
    <IonItem> <IonLabel> {allViolationsList[0].val} </IonLabel> <IonCheckbox value={allViolationsList[0].val} slot="start" color="goblin" checked={allViolationsList[0].isChecked} disabled={allViolationsList[0].isDisabled} onIonChange={(e) => changeViolationSubboxes(e.detail.value, e.detail.checked)}/> </IonItem>

    <IonList>
      <IonItemDivider>Only Show Selected Violations</IonItemDivider>

      {/* display all the violations checkboxes */}
      {violationsCheckboxList.map(({val, isChecked, isDisabled}, i) => (
          <IonItem key = {i}>
            <IonLabel> {val} </IonLabel>
            <IonCheckbox color="goblin" slot = "start" value = {val} checked={isChecked} disabled={isDisabled} onIonChange={(e) => changeViolationSubboxValues(e.detail.value, e.detail.checked)}/>
          </IonItem>
        ))}
        
    </IonList>

    <IonItemDivider></IonItemDivider>

    {/*checkbox for "Show Resolved Violations" */}
    <IonItem> <IonLabel> {resolvedList[0].val} </IonLabel> <IonCheckbox value={resolvedList[0].val} slot="start" color="goblin" checked={resolvedList[0].isChecked} disabled={resolvedList[0].isDisabled} onIonChange={(e) => changeSubCheckboxes(e.detail.value, e.detail.checked)} /> </IonItem>
    
    {/*checkbox for "Show Only Resolved Violations" */}
    <IonItem> <IonLabel> {resolvedList[1].val} </IonLabel> <IonCheckbox value={resolvedList[1].val} slot="start" color="goblin" checked={resolvedList[1].isChecked} disabled={resolvedList[1].isDisabled}  onIonChange={(e) => changeSubCheckboxes(e.detail.value, e.detail.checked)}/> </IonItem>

    <IonItemDivider></IonItemDivider>
    <IonGrid>
          <IonRow>
            <IonCol> </IonCol>
            <IonCol>
              {/*button to route to "showViolations" page to list out all the violations that are within the selected parameters */}
              <IonButton color = "goblin" class = "button" size = "large" onClick={(e) => {setMapRequest(); changeCount(); }} routerLink="/components/showViolations" expand = "block">SHOW VIOLATIONS</IonButton>
            </IonCol>        
            <IonCol> </IonCol>
          </IonRow>
      </IonGrid>

        <IonItemDivider></IonItemDivider>

  </IonContent>
</IonPage>
    );
};

export default VioLocation_page;