import emailjs from '@emailjs/browser';
import React, { useRef } from 'react';
import ShowViolations from '../components/showViolations';
//import fs from 'fs';



class createNewTxt{

    constructor(props){
        this.templateParams = {
            email: '',
            my_html: ''
        };
    }
    setEmail(uEmail){
        this.templateParams.email = uEmail;
    }

    setData(uData){
        this.templateParams.my_html += uData;
    }
    
    emailCheck(uCemail){
        if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(uCemail))
        {
            return (false)
        }
            return (true)
        }
   
    // In case file never works this can replace templateID and will write out the data
    

    /*
     This only has 200 tests as of writing we have 198 to be careful this is turned off till write file is created
    // npm install @emailjs/browser --save
    */
    sendEmail(){
        const serviceID = 'default_service';
        const templateID = 'template_55eeixi';

        emailjs.send(serviceID, templateID, this.templateParams, 'RwKHG3d5mnL8Fl7zQ')
        .then(() => {
            alert('Sent!');
        }, (err) => {
            alert(JSON.stringify(err));
        });

        
    }

    
    
}
export default new createNewTxt();