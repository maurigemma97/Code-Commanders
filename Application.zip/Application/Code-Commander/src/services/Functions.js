import { thumbsUpSharp } from "ionicons/icons";
import http from "../http-common";

class ViolationFunc {

    // function that will return an array of objects that will have various information about the selected violation categories, start and end date, and if they are in the all, violation, or solved collection. Realm Function: PARENTSEARCH
    getViolations(vioCount, overocc, illConstruction, illSign, sanitation, maintenance, visibility, ROW, permit, other, startDate, endDate, table) {

        return http.get("/ViolationSearch?vioCount="+ vioCount +"&oo=" + overocc + "&ic=" + illConstruction + "&is=" + illSign + "&si=" + sanitation + "&mi=" + maintenance + "&vi=" + visibility + "&rowi=" + ROW + "&pi=" + permit + "&o=" + other + "&startDate=" + startDate + "&endDate=" + endDate + "&table=" + table);
    }



    /*
    This is a little documentation for the upsert function involving addresses.
    
    data is just an object like:
    const addrAdditionDoc = {
       address: Address Variable (a string),
        city: city Variable (a string),
        state: State Variable (a string),
        zip_code: Zip_Code Variable (a string),
        country: Country Variable (a string),
        violations: violations Variable (an int/number),
        over_occupancy: OverOccupancy Variable (a boolean),
        illegal_construction: IllegalConstruction Variable (a boolean),
        illegal_signage: IllegalSignage Variable (a boolean),
        sanitation_issues: SanitationIssue Variable (a boolean),
        maintenance_issues: MaintenanceIssue Variable (a boolean),
        visibility_issues: VisibilityIssue Variable (a boolean),
        right_of_way_issues: Right_Of_WayIssue Variable (a boolean),
        permit_issues: PermitIssue Variable (a boolean),
        other: OtherIssue Variable (a boolean),
        notes: Notes Variable (a string),
        coordinates: Coordinates Variable (an array of doubles [Latitude, Longitude]),
        date_added: Date_added Variable (a string),
        date_updated: Date_updated Variable (a string),
        date_completed: Date_completed Variable (a string)
    }
        for the dates, if the updated or completed dates aren't up yet, then for the time being have all the digits be zeros.
        Make sure the field names in the object that you make are the same as here. They need to be the same as what is made in mongodb's upsertDoc function. Keep the datatypes consistent as above. The function does NOT do any type conversion, so make sure what gets assigned in the document matches the needed datatype.


        to call this, import this file. Then use: 
                ViolationFunc.upload(WhateverNameYouMakeForTheObject).then(response => {I am optional. 
                The response you get back will just say if there was a match and if there was a modification. ( ie: matchedCount: {$numberInt: '1'}
                                    modifiedCount: {$numberInt: '1'})
                                }).catch(e => {
                                    something good to have if there is an error with transmitting, but again your choice.
                                });

        NOTE: IF THERE IS NO ADDRESS IN THE OBJECT, THIS WILL NOT WORK. PLEASE MAKE SURE YOU HAVE ATLEAST AN ADDRESS THERE.
********FUNCTION STARTS HERE************* Realm Function: UPSERTDOC
*/
    upload(data){
        return http.put("/AddDocument", data);
    }
/*
******** FUNCTION ENDS HERE *******
        If this doesn't work well for you or you have questions, I can make a different one that works like the getViolations function above and have a bunch of queries or answer questions. Message me through discord. If I don't respond with ~1 day then text or email me (way better with those, but I'll try to keep an oculi on it).
    */
    // funciton that will get an array of the numbers based on which violation categories are selected, start and end date, and the appropriate collection. Realm Function: PIECHARTNUMBERS
     getPieNumbers(allVio, overOcc, illCon, illSign, sanitation, maintenance, visibility, ROW, permit, other, startDate, endDate, table){
        const tempArray = http.get("/pieNumbers?allVio=" + allVio + "&oo=" + overOcc + "&ic=" + illCon + "&is=" + illSign + "&si=" + sanitation + "&mi=" + maintenance + "&vi=" + visibility + "&rowi=" + ROW + "&pi=" + permit + "&o=" + other + "&startDate=" + startDate + "&endDate=" + endDate + "&table=" + table);

        return tempArray;
    }
    /*

    to use this, just import this file and use ViolationFunc.findByAddr(<whatever you are searching data for>).then(response => {
        do have a reponse since whatever you get will be inside this response
        setWhatever(response.data)
    }).catch(e => {
        console.log(e);
    }
    An example address that does work: 124 Pearl St
    Realm Function: FINDBYADDR
*/
    findByAddr(address){
        return http.get("/findByAddr?address=" + address);
    }
/*
    to use this, just import this file and use ViolationFunc.findByAddr(<whatever latitude for the address to search for>,<whatever longitude for the address to search for>).then(response => {
        do have a reponse since whatever you get will be inside this response
        setWhatever(response.data)
    }).catch(e => {
        console.log(e);
    }
    A latitude and longitude that does work: 41.3747, -83.64655
    Realm Function: FINDBYCOORD
    */
    findByCoord(lat, long){
        return http.get("/findByCoord?lat=" + lat + "&long=" + long);
    }

    // function endpoint to get the addresses with it respective violation count. Realm Function: PIECHARTSORTBYADDRESS
    getPieByAddr(startDate, endDate, table){
    return http.get("/pieAddr?dateEnd=" + endDate + "&dateStart=" + startDate + "&table=" + table);
    }
    // function endpoint to get the number of times the different violation counts occurred. Realm Function: GETPIENUMBEROFVIOLATIONS
    getPieByNumOfVio(startDate, endDate, table){
        return http.get("/getPieNumOfVio?dateEnd=" + endDate + "&dateStart=" + startDate + "&table=" + table);
    }
    // function endpoint that gets back the occurrence of violations documents were created. Realm Function: BARCHARTSMONTHMADE
    getBarMonths(startDate, endDate, table){
        return http.get("/barMonths?dateStart=" + startDate + "&dateEnd=" + endDate + "&table=" + table);
    }
    // function endpoint that gets the number of violation documents that are still open and still solved.
    // Should have future editting so that open and solved are in different collections. Realm Function: BARCHARTOPEN/SOLVED
    getBarOpenAndSolved(startDate, endDate){
        return http.get("/barOpenAndSolved?dateStart=" + startDate + "&dateEnd=" + endDate);
    }

    // function is used when a violation location gets solved. It will move the document from the
    // Violation Collection (active violations) to the Completed Collection (inactive violations). Realm Function: SOLVED
    Completed(address){
        return http.delete("/SolvedDelete?address=" + address);
    }
    // function used to permanently delete a location from the Violations (active) collection. Realm Function: DELETEDOC
    PermanentDelete(address){
        return http.delete("/PermaDelete?address=" + address);
    }
    // function that will get the arrays needed to chart the line graph from the start date to the end // date with increments in weeks. Realm Function: LINECHARTWEEKS
    getLineChartWeeks(allVio, oo, ic, is, si, mi, vi, rowi, pi, o, startDate, endDate, table){
        return http.get("/lineChartWeeks?allVio=" + allVio + "&oo=" + oo + "&ic=" + ic + "&is=" + is + "&si=" + si + "&mi=" + mi + "&vi=" + vi + "&rowi=" + rowi + "&pi=" + pi + "&o=" + o + "&startDate=" + startDate + "&endDate=" + endDate + "&table=" + table);
    }
    // function that will get the arrays needed to chart the line graph from the start date to the end date with increments in Years. Realm Function: LINECHARTYEARS
    getLineChartYears(allVio, oo, ic, is, si, mi, vi, rowi, pi, o, startDate, endDate, table){
        return http.get("/linechartYears?allVio=" + allVio + "&oo=" + oo + "&ic=" + ic + "&is=" + is + "&si=" + si + "&mi=" + mi + "&vi=" + vi + "&rowi=" + rowi + "&pi=" + pi + "&o=" + o + "&startDate=" + startDate + "&endDate=" + endDate + "&table=" + table);
    }
    // function that will get the arrays needed to chart the line graph from the start date to the end date with increments in Months. Realm Function: LINECHARTMONTHS
    getLineChartMonths(allVio, oo, ic, is, si, mi, vi, rowi, pi, o, startDate, endDate, table){
        return http.get("/lineChartMonths?allVio=" + allVio + "&oo=" + oo + "&ic=" + ic + "&is=" + is + "&si=" + si + "&mi=" + mi + "&vi=" + vi + "&rowi=" + rowi + "&pi=" + pi + "&o=" + o + "&startDate=" + startDate + "&endDate=" + endDate + "&table=" + table);
    }
    // function that will get the array of all the dates that the line chart will use for the x-axis. Realm Function:  LINECHARTSDATES
    getLineChartDates(startDate, endDate, SortByX){
        return http.get("/lineChartDates?startDate=" + startDate + "&endDate=" + endDate + "&sortByX=" + SortByX);
    }
    // function that will look up coordinates of a location based on the address. Realm Function: COORDINATELOOKUP
    getCoords(address){
        return http.get("/CoordLookUp?address=" + address);
    }


    /*
    Current schema for the routes collection
    const RouteDoc = {
    employeeID: string, a string of the employee's ID
    route_array: [[double, double], [double, double], ...], an array of double arrays for the coordinates 
    violation_pathed: [[double, double], [double, double]] array of the coordinates of violations added 
    date: string, a string in YYYY-MM-DD on the date that the route was collected
  }; // let me know if there are other things that would make sense to have.
    Realm Function: ADDROUTE
    */
    addRoute(RouteDoc){
        return http.put("/addRoute", RouteDoc);
    }
    // Look up a single route using the date it was made and the employee's ID. Realm Function: ROUTELOOKUP
    routeLookUp(date, employeeID){
        return http.get("/RouteLookUp?employeeID=" + employeeID + "&date=" + date);
    }
    // delete a single route based off of the date it was made and the employee's ID. Realm Function: DELETEROUTE
    routeDelete(date, employeeID){
        return http.delete("/deleteRoute?employeeID=" + employeeID + "&date=" + date);
    }
}
export default new ViolationFunc();
