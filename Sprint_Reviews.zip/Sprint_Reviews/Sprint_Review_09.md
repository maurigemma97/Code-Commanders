<details><summary>Nicholas Acuncius</summary>
1.Issues completed in Sprint? <br />
        Issue #66, 67, 81. Issue #66 was to have the date ranging for pulling from the database implemented to list violations. Issue #67 was to have the bar and pie graphs have date ranging for pulling from the database implemented. Issue #81 was to make a new collection in MongoDB for only the completed violation documents. <br />
2.What went well? <br />
        Modifying the upload function to work for bothcollections for active and all documents along with a function to move a document from violation (active documents) collection to completed (closed documents) collection was simple. Getting the violation listed with a date range was easy. Some of the functions for getting data for graphs was easily modified for getting documents within a specific date range. Got some of the aggregations simplified. <br />
3.What didn't go well? <br />
        Getting the date range working with aggregation and local user-defined variables was tricky (pipelines had to be compiled for every time a local variable inside the aggregation changed). <br />
4.What have I learned? <br />
        Using local user-defined variables within aggregations. Using some more functions within mongoDB's aggregation.<br />
5.What Still Puzzles You? <br />
        The different syntaxes for aggregation and non-aggregation functions that appear in both, like gte/lte/and (they are slightly different). <br />
6.What will we change to improve? <br />
        Find a way to make a loading screen so that graph generation looks better and make all the line graphs usable with the current x-axis options.<br />
</details>

<details><summary>Evan Buchanan</summary>
<b>1. Issues completed in Sprint? </b><br />
        #85 - Create multiple violations at once <br />
        #86 - Change violation date selection to calendar date picker</br>
        <br /><br />
<b>2. What went well? </b><br />
        I was able to change how the violations creation is done so that multiple violations were able to be entered at once, which will speed up entering in a list of violations greatly. I was able to introduce a dateTime component to be used instead of having to use manually entered date information through text. Took a little bit to get the date it returned parsed into how we want it for the database but I figured it out.<br /><br />
<b>3. What didn't go well? </b><br />
        I was not able to get the other issue I was working on done in time, trying to get the page to reset all fields after use. It is surpringly not easy at all to access ionic components and change their values programmatically. It will take some messing with to get it right.<br /><br />
<b>4. What have I learned? </b><br />
        I learned more about working with the pages and accessing the individual elements through their id's. Learned how to work with and customize more components to do whast we need.<br /><br />
<b>5. What Still Puzzles You? </b><br />
         Still confused about clearing the page after form submission or on press of the back button. I think a solution could be found using useState and setting up default states for the components.<br /><br />
<b>6. What will we change to improve? </b><br />
        Having more information about how to use the different tools will make things easier to introduce improvemnts in other parts of the app. I want to change the formatting of the violation popup to look better in the future, it does what it needs to but its not that pretty yet.<br /><br />
</details>

<details><summary>Caleb Courtney</summary>
1.Issues completed in Sprint? <br />
        Issue #84, and #85 . 84 was setting up an email that can send to people through the app while 85 was working to get a file write to work. <br />
2.What went well? <br />
        Setting up the email took a bit of time, but otherwise was easy and was tested successfully run it in app as well as a template to make an email with the information as text in the email works. The file creater worked outside of the app and with the code added to the branch is can be worked on further. <br />
3.What didn't go well? <br />
        The first is that emailJS needs the paid portion to send files so even with the file part working unless there is another free version or $4 is paid that can't be used. The fs import doesn't seem to work in a react environment because downloading to local folders is heavily protected. React might be able to make a file in app and have a tempory placement, but without the write ability of FS even that wont work. <br />
4.What have I learned? <br />
        How  to create automatic emails and implement them to an app while running. I also learned js write to file which works running in local, but not in app as well as protections react has. <br />
5.What Still Puzzles You? <br />
        If creating a text file is the way to go over the email being copy pasted or if react has another way of creating files that I can send to the email. <br />
6.What will we change to improve? <br />
        Using my time more wisly starting with testing in app lost of my testing for the file changes was outside of the app and run with a js file to speed up recompiling the ionic sever everytime, but in the long run it made some of that progress not worth it.<br />
</details>
<details><summary>Matt Aurigemma</summary>
1.Issues completed in Sprint? <br />
        I completed Issue(s) #80 and #79, however need to make minor tweaks to map style changer <br />
2.What went well? <br />
        I was able to finally get my phone to download our app after finding a really in depth youtube video online.<br />
        Also, I found that mapbox had an npm package that would allow me to easily apply map style changes to the map <br />
3.What didnt go so well? <br />
        I ran into issues for downloading the app to my phone that were software related. Spent a good chunk of time trying <$
        to find out why xcode wouldnt pair with my Iphone, but I realized the fix wasnt the software on my Iphone, but the ve$
        of xcode I was running. Also, Once I was able to run it, I realized that location services werent working for me on <$
        Iphone which I need to address. <br />
4.What have I learned> <br />
        I learned that mapbox SDK may provide slightly different services that are exclusive to ios. These services <br />
        I am thinking will need to be added in order for ios to use mapbox location services.< br />
5.What still puzzles you? <br />
        I am still confused what exact changes need to be made on xcode in order for my iphone to run my current location. <b$
        I tried changing my scheme but that didnt work, and since xcode code is basically a converted version of React, most $
        of the "code" on xcode is just a bunch of random numbers.<br />
6.What will we change to improve? <br />
        I need to change the CCS for the Home file in order to not have my map switcher hidden, and I need to figure out <br $
        what/how mapbox SDK works in comparison to the mapbox I have been using. <br />
</details>

<details><summary>Jaxsin Power</summary>
1.Issues completed in Sprint? <br />
        I completed Issue(s) #89 (Add functionality for getting violation location information to Home page) 
        and #88 (Fix geotracking error on Android devices) this week. <br />
2.What went well? <br />
        I was able to figure out how to consistently access the database and convert that infromation to be brought to the Home
        page and be placed on the map via violation location markers (compared to last week, where the values for the violation
        location markers were hard-coded on the Home page to iron out the basic functionality.) I was also able to figure out a
        issue in the code which resulted in the geolocation tracking to not work when running the application on Android devices.
3.What didnt go so well? <br />
        Both issues took a significantly longer time to deal with than I had previously anticipated, which was unfortunate for me as,
        I had hoped that I could get these issues done early enough in order to work ahead on other issues that I hadn't planned for 
        this week. A significant issue popped up shortly before finalizing my work on the database access and data transfer for the
        violation location markers, which also resulted in me taking extra time to figure out what was causing the sudden issue.<br />
4.What have I learned> <br />
        I have learned about the extra sets of permissions that need to be provided to Ionic React application in order for certain
        phone features (such as GPS tracking) to be used. Additionally, I learned how to transfer the data smoothly from one page to 
        another, even if one of the pages cloeses.< br />
5.What still puzzles you? <br />
        I am still confused on how to modify the imported database functions in the TypeScript pages. While most information is available 
        from prior functionality for accessing the database for violation information, certain details such as written notes are not yet
        accessible in the current set-up.<br />
6.What will we change to improve? <br />
        I will be focusing more heavily on database access and database functionality in order to fully flesh out the violation location
        search feature as well as to finish the routes search functionality.<br />
</details>

