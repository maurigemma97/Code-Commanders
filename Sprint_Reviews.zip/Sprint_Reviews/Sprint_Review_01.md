<details><summary>Jackson Conrad -- Click to expand</summary>
1. Issue(s) completed in the sprint?<br />
    Issue #9, researching the MongoDB service to learn how to create/use functions.<br />
2. What went well?<br />
    The amount of YouTube videos on the subject was very plentiful. I was able to learn a lot <br />
    about functions and able to test them on a personal DB.<br />
3. What didn’t go so well?<br />
    I only learned a small slice of the functionality of the service. This semester will<br />
    consist of a lot of continual learning of MongoDB.<br />
4. What have I learned?<br />
    The basic way to write functions in MongoDB, as well as some of the base functions.<br />
5. What still puzzles me?<br />
    There are countless functions in the service. Learning all of these is tough so I will be<br />
    focusing on the ones that we need for the app.<br />
6. What will we change to improve?<br />
    Spending more time on practicing the implementation of the functions on a personal test database.<br />
</details>

<details><summary>Caleb Courtney -- Click to expand</summary>
1. Issue(s) completed in the sprint?<br />
    Issue #7, seeing how to connect the database to the application.<br />
2. What went well?<br />
    I was able to get the code needed to both connect the database and call things from it. <br />
3. What didn’t go so well?<br />
    It took a lot longer then expected due to miss understanding what connecting ment. <br />
    I thought it was going to be a connection through the apps instead it was a node.js <br /> 
    and javascript command that connects the two.
4. What have I learned?<br />
    How to call information from the database using javascript.<br />
5. What still puzzles me?<br />
    Using the javascript in the app. I was personally unable to build the app and test it <br />
    outside console command.<br />
6. What will we change to improve?<br />
    Speaking to my group when I ready to test things that I learned.<br />
</details>


<details><summary>Evan Buchanan -- Click to expand</summary>
<b>1. Issue(s) completed in the sprint?</b><br />
    - Issue #1, Get the mobile application up and running on android devices.<br />
    - Issue #3, implement a settings button on the main page of the app, the button needs to be clickable and have some sort of visual way of understanding its a settings icon.<br /><br />
<b>2. What went well?</b><br />
    - Getting the initial application setup was quite a task but it went smoothly and was able to be run non mobile devices quickly. We were able to get it up and running on android devices eventually! <br />
    - It was surprisingly easy and quick to add a nice looking button in the exact spot I wanted it in, so im excited that it was so easy to do, hopefully things like this will continue to be easy in the future. <br /><br />
<b>3. What didn’t go so well?</b><br />
    - We ran into about every issue we could imagine trying to get the app to work on andorid devices. It was enough of a process getting it setup and working on our pc's at first, getting it to run on android devices was much more of a process. <br /><br />
<b>4. What have I learned?</b><br />
    - I learned a lot more about what all goes into building mobile applications and the multitude of dependencies that need to be in place for everything to go smoothly.<br />
    - The software we are using makes it super efficient and easy to add simple things like buttons into the application. I have also learned more about how assigning a specific graphic to something like a button will work, how to get the button where I want it on the page, how to size it, etc. <br /><br />
<b>5. What still puzzles me?</b><br />
    - Getting the app to work for everyone quickly on their phone is something we need to figure out, it takes a lot of setup to start trying to debug using our phone so we need to get everyone set up to test still.<br />
    - I am still figuring out how to get the settings button that I have created to trigger an event and open up the menu that will contain all of the options the user can select. <br /><br />
<b>6. What will we change to improve?</b><br />
    - We will want to add some more documentation about everything that needs to be setup in order to test the application using various personal devices.<br />
    - I think I might mess around with the graphic used for the settings button at a later time, but thats not a priority right now, I just mainly wanted to add a settings button to get myself used to adding different UI components into the applciation. <br />
</details>

<details><summary>Nicholas Acuncius --Click to expand</summary>
1. Issue(s) completed in the Sprint? <br />
	Issue #8, researching how Mongo Atlas and Realm works for use within the project. <br />
2. What went well? <br />
	I was able to work with some of Atlas's functinoality that is outside of the Mongo website 
	and reading on about Realm gave ideas on how we may want to try and implement later user stories. <br />
3. What didn't go so well? <br />
	MongoDB has a lot of functionality and figuring out which ones will be needed  is difficult, so 
	I may have missed learning about some functions. <br />
4. What have I learned? <br />
	Different function calls used for Realm and Atlas, some prerequisites for connecting to VS Code <br />
	and, potentially, how to connect ultimately to the app (haven't fully explored this piece). <br />
	How to use some of these functions inside a coding environment setting. Some Schema structuring <br />
	like getting Dates set. <br />
5. What still puzzles me? <br />
	Largely how we will get this into the project (Java Script is still a very new language to me. Reading it <br />
	is significantly easier than writing it), but this should also be partailly fixed with discussing the project <br />
	with the front-end team. <br /> 
6. What will we change to improve? <br />
	Increase team discussions about this project (so we all know the general basis of the different files) and <br />
	learn more about Java Script's language and to use it. <br />
</details>

<details><summary>Matt Aurigemma --Click to expand</summary>
1.Issues completed in Sprint?<br />
	Issue #10, Application can successfully open on Iphone. <br />
2.What went well? <br />
	I was able to download xcode and pull up the xcodeworkspace without much problems which made it easy to edit and work on things to make<br /> 
	the app show up on ios.<br />
3.What didn't go well? <br />
	xcode took forever to download on my computer for an unknown reason, and then once downloaded, I had to go though a lot of<br />
	troubleshooting in order to get the pods component to install for the xcodeworkspace.<br />
4.What have I learned? <br />
	I learned that there's a lot of plug-ins and extra installations in order ro make ios/android run and theirs no easy route to it really.<br />
	Also, I learned a decent amount about how react works and how to code in react. <br />
5.What Still Puzzles You? <br />
	I still have a lot to learn about react/ionic/mapbox. Still kind of confused what additions need to be made in order for mapbox to <br />
	function. Also, still confused about a lot of the commands in React <br />
6.What will we change to improve? <br />
	Going forward we probably should try to communicate more and communicate what issues we are going to work on sooner. <br />
</details>

<details><summary>Jaxsin Power --Click to expand</summary>
1.Issues completed in Sprint?<br />
	Issue #1, Application can successfully open on Android. <br />
2.What went well? <br />
	Once all the dependencies for building are dealt with, yhe building process for creating an Android build was relatively simple and straight forward, with the Android 
    build being sent to the Android phone in a matter of minutes after entering the build command. Ideally this will allow for quicker testing of other issues down the line 
    when they are implented and need to be verified to run on an Android device. <br />
3.What didn't go well? <br />
	Attempting to intitally create a build was extremely difficult, as it resulted in errors that appeared one at a time as each build would fail when there was a needed file 
    or file location that was not present for the builder. Figuring out what files were needed for building as a whole, as well as files needed for the application itself to 
    be compatible Android was not clear cut. As such, it required a lot of research as well as extensive trial-and-error. <br />
4.What have I learned? <br />
	I learned that there are multiple extensions and dependencies needed for building Android versions of the application, and there are multiple points of failure that could 
    present themselves if not all extensions and dependencies are met. I also learned more about creating builds of Ionic React apps, as well as some of the syntax needed for 
    fleshing out an Ionic React app. <br />
5.What Still Puzzles You? <br />
	I'm still unsure of if there will be more extensions or dependencies needed for a production Android build vs. a development build, and if what works on a development     
    build will also work for a production build. I'm also still unsure of how to incorporate a mapbox API to the Ionic React application, and if there will be differences in 
    how this API operates between a Web build and Android build. <br />
6.What will we change to improve? <br />
	I will try to create both development and production builds of Android apps as we continue to add features to the application, and comunicate between the rest of the 
    members when a discrepancy between Web build and Android builds appear. I will also try to solve these discrepancies as they present themselves so that they do not become 
    larger issues later on. <br />
</details>
