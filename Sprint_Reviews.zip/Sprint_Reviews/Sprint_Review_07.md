<details><summary>Nicholas Acuncius</summary>
1.Issues completed in Sprint? <br />
        Issue #54 and 62-64. #54 was to make different types of Bar graphs, which would also complete #64, but it was not fully completed. I got one of the bar charts, but not as many as I would have wanted. #64 was to just implement a bar chart in the app, which was completed. #63 was to implement the line chart in the app which was completed with some of the data that is also acquired from the pie chart. #62 was to create drop down menus in the charts menu to allow the user to choice how the violations will be graphed. <br />
2.What went well? <br />
        The drop down menus went well, but was a little finicky when it would shhift to different graph types and when trying to return the option to the default blank. Getting the bar and line graphs implemented was simple and looks fine. <br />
3.What didn't go well? <br />
        I didn't get all the different way to chart the bar graph done and I am having difficulty trying to get titles for the x and y axis for the bar and line graphs. <br />
4.What have I learned? <br />
        Using the ion-select and ion-select-option was mostly straight forward (had bumps getting the drop menus to look nice).<br />
5.What Still Puzzles You? <br />
        After and hour of trying to get the axis to have titles, I still am unable to get it on the graph, so I am still unsure how to give the graph's axis titles. <br />
6.What will we change to improve? <br />
        Manage time to be able to work on the charts more so that the options in the drop down menu are usable.<br />
</details>
<details><summary>Jackson Conrad</summary>
1.Issues completed in Sprint? <br />
        Issue #57. My issue was to research the Firebase application. <br />
2.What went well? <br />
        Firebase seems to be a good way to store pictures in a database. There is the ability to update things in realtime. It is also easy to set up the database connection in the app. <br />
3.What didn't go well? <br />
        The actual implementation of the database as I was not sure which part of the code to put the connections in. <br />
4.What have I learned? <br />
        How to use the database connections.<br />
5.What Still Puzzles You? <br />
        Where to place the database code. <br />
6.What will we change to improve? <br />
        Work with the team to understand the way that the application works on the frontend. <br />
</details>

<details><summary>Evan Buchanan</summary>
<b>1. Issues completed in Sprint? </b><br />
        Issue #68 -  Fix popup menu to accurately display info about property<br />
        Issue #69 - Make navigation only show up when navigation button has been selected <br />
        Issue #70 - Remove ability to create multiple geocoding and directions controls at the same time<br />
        Issue #71 - Restrict geocoder responses to only Bowling Green area<br /><br />
<b>2. What went well? </b><br />
        Pretty much everything went well this week for me, I realized that the reason the code I had tried before to make the main page wait on the violation creation page to be done was not working because of a simple syntax problem. After I got that done I was able to work out a couple little issues that we wanted to get done.<br /><br />
<b>3. What didn't go well? </b><br />
        Nothing really went to badly this week actually, the problems I ran into I found solutions for pretty quick which was really nice.<br /><br />
<b>4. What have I learned? </b><br />
        I learned a lot more about how to introduce ways for the program to wait on responses from other sections of the program and use information accross different files easily.<br /><br />
<b>5. What Still Puzzles You? </b><br />
         I am still trying to find a way to change the appearance of the mapbox gl geocoder control so I can make it look a bit nicer and hopefully center it on the top middle of the screen.<br /><br />
<b>6. What will we change to improve? </b><br />
        I might want to make more things tied to css stylings so that I can make all of the different buttons, controls work better together visually, there are still some cases of overlapping graphics which would be nice to get rid of.<br /><br />
</details>

<details><summary>Caleb Courtney</summary>
1.Issues completed in Sprint? <br />
        Issue #72 this was too look into all of the different date settings and uploads to the databse. <br />
2.What went well? <br />
<b>2. What went well? </b><br />
        I found many options to create strings, pull the currect date and have everything show up in the database as expected for a string.<br /><br />
<b>3. What didn't go well? </b><br />
        We really wanted it to be a date schema we found earlier in the database, however it looks like trying to make that run from react to the datebase not using a string doesn't help the app.<br /><br />
<b>4. What have I learned? </b><br />
        I learned getting the date from the computer or from a user submitted calander both work and can be implimented into the database as it currently works.<br /><br />
<b>5. What Still Puzzles You? </b><br />
        I need to spend Tuesday working with my group trying to figure out why we can't or won't just use the string version it seems to run the best between the two platforms.<br /><br />
<b>6. What will we change to improve? </b><br />
        Integrating it with my partners. I'm not sure how they want it or need it for the functions they are working on and I might to change or fix a lot of what I did this week to work with what they have. <br /><br />
</details>

<details><summary>Jaxsin Power</summary>
<b>1. Issues completed in Sprint? </b><br />
        I once again spent time working on Issue #61, Mark violations from vioLoctaion search to map, but I was still unable to get this funcationality working.<br />
<b>2. What went well? </b><br />
        It total honesty, very little went well for me this week. Despite my research attempts to solve the issues relating to setback relating to what's kept me behind in 
        this issue (transferring data from one TypeScript page to another, calling functions once a user returns to a page rather than from the click of a button) has still 
        not helped me in getting the violation location marker system to work correctly. <br /><br />
<b>3. What didn't go well? </b><br />
        As above, my research and experimentation in terms of getting the functionality to work has not given me anything in terms of tangible results. While some of this     
        information I've uncovered may be useful later on for other issues, it currently hasn't helped with this issue in particular , at least not with attempted 
        implementations.</b><br />
<b>5. What Still Puzzles You? </b><br />
         While I can access the results from the database, mapping them to the homepage as markers has still proven to be difficult.<br /><br />
<b>6. What will we change to improve? </b><br />
        I will try to continue to eresearch and expriement to find the answers I need to implement this functionality properly. That being said, I may instead focus on other  
        issues simply due to my continued difficulty implementing this particular issue. But until I decide that that is necessary, I will spend  tremendous effort during the 
        first half of this week to try to get this functionality working, as it is very important functionality required for the project.<br /><br />
</details>
<details><summary>Matt Aurigemma</summary>
1.Issues completed this sprint?<br />
	I had issue #65, however I was unable to complete the issue <br />
2.What went well? <br />
	I made some strides learning how turf.js works, since everything I looked up seemed to point in the direction of needing that<br />
	In order to track a route properly<br />
3.What didn't go well?<br />
	I am still unsure about how some things work in turf.js and just underestimated how tricky this issue could be for me. seemed like anything I did<br />
	would crash the map, so I need to do more research this week to find some form of a solution<br />
4.What have I learned?<br />
	I have learned that turf.js is slightly similiar to mapbox, but seems a bit more advanced when it comes to location services<br />
5. What still puzzles you?
	I am still curious if Turf.js is actually needed in order to track the location of a moving person/vehicle. I know that mapbox does seem to have some sort of service<br />
	that provides this functionality, but it seems to be more of a business type request that involves spending money. Also, I have seen SDK mapbox services for mobile device<br />
	So I still am going to need to put a lot of time into nailing this down. <br />
6.What will we change to improve?<br />
	In general, I think fixing the tracking is a must, and finding out exactly what imports I need will be critical so Im not second guessing myself<br />
