<details><summary>Matt Aurigemma</summary>
1.Issues completed in Sprint? <br />
	I was able to complete issues #90, and #91 <br />
2.What went well? <br />
	I was able to move the switcher with little css styling (although this could be subject to change) <br />
3.What didnt go so well? <br />
	I spent a lot of time looking in the wrong places to fix the location issue for io, but I was eventually <br />
	able to figure out what was the problem for me. <br />
4.What have I learned> <br />
	I learned that the Info.Plist file for ios controls a lot of the privacy settings for application use on an Iphone/ Ipad <br />
	Im curious to know what else it is able to do that I don't know right now. <br />
5.What still puzzles you? <br />
	Im still confused why the map still cuts out for me when I intially start up the application on an Iphone/Ipad <br />
	Im able to fix this issue if I click on something or turn the device, but it's still something Id like to fic <br />
6.What will we change to improve? <br />
	I think the styling on the application needs a bit of an overhaul so the back buttons are able to be clicked <br />
	On an Iphone or Ipad device. <br />
</details>
<details><summary>Nicholas Acuncius</summary>
1.Issues completed in Sprint? <br />
	Issues #93 and #94. Issue #93 was to refine how the date ranging will work in Realm, so that what is accepted in the range is no longer only the dates that are added in that date range, but any documents that have their date added to date completed (active date) is within range of the user selected date. Also get the different collection options functioning. Issue #94 was to get the line graph set up to work with violation categories, collection options, and date range. <br />
2.What went well? <br />
	Getting the refined date range was fairly smooth, only minor error in logic. Getting the weeks and years to chart for the line chart was lengthly but easy. <br />
3.What didnt go so well? <br />
	Working with the months for the line graph revealed that the Date objects work differently between Realm and the app (time zones). Trying to get the dates to appropriately adjust based on the maximum number of days in that nothing. (adding 1 month to Jan 31 would not be Feb 28, but more Mar 1).  <br />
4.What have I learned> <br />
	That Date objects in Realm and the app are slightly different (the app will start with a timezone, so when it Date object is Jan 30 9PM GMT, conversion to an ISO String will give Jan 31). When it comes to line graphs, I can get all the objects for the dataset into an array for easy of use and that the graph may have a limit to how many lines can be plotted on the graph.<br />
5.What still puzzles you? <br />
	What the limit to the number of line that can be plotted on the line graph (something I will want to try testing after the demo as it isn't currently critical). <br />
6.What will we change to improve? <br />
	Get a few more of the buttons to be more reactive based on previously selected options and clear up some formating (make things look nicer). <br />
</details>
<details><summary>Caleb Courtney</summary>
1.Issues completed in Sprint? <br />
	Issues #95. It was fixing email to work with the dynamic data and be able to send an email to a user email without hard coding.<br />
2.What went well? <br />
	I got everything to work and be demo ready. The user can type in an email and send it to that email and get the exact same data on the page into the email message. There is also slight error control by having to send an actual email. <br />
3.What didnt go so well? <br />
	A few small spelling mistakes made the process longer then it needed to be like eamil and a few other things. The code for the data is also a bit long and ugly not sure if that could have been done better.  <br />
4.What have I learned> <br />
	Syntax for emailjs and ionic input and button to pass different types of data to different areas of the app.<br />
5.What still puzzles you? <br />
	If I could make it into an actual file right now it is only text that you can copy and paste or forward in the email. <br />
6.What will we change to improve? <br />
	Checking spelling after making changes. <br />
</details>
<details><summary>Jackson Conrad</summary>
1.Issues completed in Sprint? <br />
	I was able to complete issue #92<br />
2.What went well? <br />
	I was able to move the map down to allow for the clipping issue to be resolved. <br />
3.What didnt go so well? <br />
	I was not able to fix every page as they caused me issues. <br />
4.What have I learned> <br />
	I learned a little bit of css. Next week I will fix the rest of the pages to ensure they are all down 10px. <br />
5.What still puzzles you? <br />
	Why some of the pages don't work the same way as others. <br />
6.What will we change to improve? <br />
	Read up on CSS docs to get more familiar with it. <br />
</details>
