<details><summary>Jackson Conrad -- Click to expand</summary>
1. Issue(s) completed in the sprint?<br />
    Issue #13, Creating a function that can search the database for violations by address.<br />
2. What went well?<br />
    The function will return the address, number, and type of violations. <br />
3. What didn’t go so well?<br />
    It took much longer than I thought it would to implement such a simple function.<br />
4. What have I learned?<br />
    The ins and outs of the "find" function. What parameters it takes, and the different<br />
    ways that you can customize what it returns.<br />
5. What still puzzles me?<br />
    Nothing about find, although I know there are more ways to customize it. However,<br />
    there are still many other functions that I am not comfortable with. <br />
6. What will we change to improve?<br />
    Spending more time on practicing the implementation of the functions on a personal test database.<br />
</details>


<details><summary>Matt Aurigemma -- Click to expand</summary>
1. Issues completed in the sprint?<br />
        I was able to complete Issue #23 which was the creation of the map. I worked a little bit on issue #12 too<br />
        but I am going to wait on that for a little bit since theirs more pressing issues to get done with <br />
2. What went well?<br />
        On a webpage, I was able to make the map and it is able to get latitude, longitude, and zoom. <br />
        Also, You are able to scroll through different locations on the map<br />
3. What didn't go so well?<br />
        the map was pretty diffcult to implement the way mapbox wanted it implemented. I had to play around with <br />
        our existing files to see what would work. This took a lot of time to do given we had a lot of .tsx files and <br />
        MapBox seemed to only be compatible with .js files.
4. What have I learned?<br />
        Given the fact I had to change some stuff to javascript, I was able to learn how javascript can still interact <br />
        with .JSX function features (creation of buttons were part of .JSX functions), and was able to learn some more<br />
        about CSS and design.<br />
5. What still puzzles you?<br />
        Theirs stilla lot I need to know about javascript and CSS. Also, although I have the emulator working, signing up<br />
        as an apple developer is still a lot more tricky than i imagined. Jerry told me that one of his software engineers<br />
        may be able to guide me to a free solution instead of a paid solution to launch the app<br />
6. What will we change to improve?<br />
        I think taking more time to learn how javascript works will be benificial going forward, and improving the map size.<br />
        Also,tracking current location may be the next step in order to have the app more functional<br />
</details>

<<<<<<< HEAD

=======
>>>>>>> 886d1a2de554130db80b5c2fa8482bafa2f6c349
<details><summary>Nicholas Acuncius -- Click to expand</summary>
1. Issue(s) completed in the sprint?<br />
    Issue # 17 (Writing to database with Realm) and Issue # 15 (creating the database's schema).<br />
2. What went well?<br />
    Creating the Schema went okay. I has most of what will be needed within the database.<br />
    A React app was possible to be made that created and getting login in from the React app went well. <br />
    Making the functions to communicate between Atlas and Realm using Realm's UI was easy. <br />
3. What didn’t go so well?<br />
    Getting that function to work on the React App was difficult. It repeatly through out <br />
    'Unhandled Promise Rejection' errors in both the console and Realm's log. I also tried to get the app<br />
    to read from Realm, but that doesn't work yet. The schema is mostly done. It just needs a photo array <br />
    the datatype for photos isn't fully determined yet. <br />
4. What have I learned?<br />
    That an API will be necessary for reading and writing between the app and Realm and the functions <br />
    have different levels of authentications. The different BSON datatypes. Different options that photos can <br />
    be stored as in databases. How to use the different Atlas functions and incorporate them into Realm functions. <br />
    
5. What still puzzles me?<br />
    The issue of reading from Realm to apps. How to use an API and the several other. <br />
    installations that will be needed to read and write between the app and Realm. <br />
    Realm also has a large number of features that is likely to be incorporated into the project. <br />
6. What will we change to improve?<br />
    The overall understanding of using an API (and which API that will be used) and how to connect it <br />
    to Realm. More work in understanding how to utilize Realm to the max <br />
<<<<<<< HEAD
>>>>>>> 11fa593ade47d12d4c2c1af1b025da2c7e701c26
=======
</details>


<details><summary>Evan Buchanan -- Click to expand</summary>
1. Issues completed in the sprint?<br />
        Issue #11 - Create settings menu that opens up when settings button is pressed. I made some other miscellaneous changes not directly related to the settings menu that appears as well.<br />
2. What went well?<br />
        I was able to get it working eventually, I think it looks really nice so far and I didnt have to change anything about how the page was previously layed out to get a menu working. It is really easy and intuitive to add different types of items to a list so I look forward to doing more with that.
        <br />
3. What didn't go so well?<br />
        It was surprisngly frustrating trying to find a helpful resource for creating a new page that actually gave all of the information needed so it took a lot of trial and error.<br />
4. What have I learned?
<br />
        I learned how to use a button to run functions, open other pages, effect other parts of the page and much more. I learned a lot more of how to format a list in react and how you can insert a wide variety of components into a list, like buttons, sliding range indicators, checklists, etc. very easily. 
        <br />
5. What still puzzles you?<br />
        I have more to learn about setting up more pages for the application and how to go about routing all of the pages together, so navigation to and from pages is possible. I want to figure out more how all of the buttons and other stuff will work with backend stuff and how data will be passed back and forth.
        <br />
6. What will we change to improve?<br />
        The settings menu still needs a better way to return to the main page so I would like to quickly implement a handy back button in the next sprint so navigation is easier for the user.<br />

</details>

<details><summary>Jaxsin Power --Click to expand</summary>
1.Issues completed in Sprint?<br />
	Issue #14, Add directions button; Issue #19, Add violations button; Issue #20, Add violation location sub-button; Issue #21, Add route sub-button; Issue #22, Add graph    
    sub-button <br />
2.What went well? <br />
	Once I could figure out the syntax for adding fab buttons to the app, placing them in the app was fairly straight-forward. As such, I was able to experiment with button 
    size, color, design and placement in order to make the buttons as clear as they can be in terms of their intended use. <br />
3.What didn't go well? <br />
	Pushing the limits of these fab buttons made it clear that, while there are customization options available for these buttons, adjusting their size and location has    
    proven to be very limited. And unlike other button types, these buttons seem to not allow the addition of words to further clarify a button's purpose. Additonally, I had 
    signficiant difficulty adding custom logos for the buttons, so at this current point the logos currently used on the buttons are placeholders. <br />
4.What have I learned? <br />
	I have learned more about the syntax and logic used for React in particular, and feel more confident in adding additions to the app later on, such as addtions of lists or 
    buttons to menus. I have also leanred the flexibilities and limitations of fab buttons, and can now consider where fab buttons may or may not be useful in other parts of 
    the application.<br />
5.What Still Puzzles You? <br />
	I'm still unsure of how to change the pre-made icons used in fab buttons to more more customized images. That, alongside the greater limitations presented ith fab butons, 
    has me cosndiering modifying the main page on the app to use other types of Ionic buttons where they may be more useful or clear. <br />
6.What will we change to improve? <br />
	I will be testing out other interactive Ionic elements to see what can be used for violation reports and other application necessities, in order to make sure that said 
    interactive elements can prove to be flexibile for changes if needed later on. I will also be learning more about mapbox implementation in order to have the buttons 
    created interact with mapbox where it is needed.<br />
</details>

<details><summary>Caleb Courtney --Click to expand</summary>
1.Issues completed in Sprint?<br />
	Issue #18, Add functions to the existing demo.js that can further handle minimuating data
    in the database
2.What went well? <br />
	Figuring out the syntax needed and having provable changes to the databases as well as handleing general functions that will help with future more complex functions <br />
3.What didn't go well? <br />
	Making sure it could be test with the front end was somthing I wanted to get around to. This will probably end up being the sprint for next week depending on our next meeting. However all of these changes wont mean anything until it can work with the currect application <br />
4.What have I learned? <br />
	I have learned how to change the database, get indivual pieces and other operations that will be involved in the future development of the app. I learned more javascript which is where our app seems to be headed as well <br />
5.What Still Puzzles You? <br />
	I don't know if it will work during a app run time this is a big point that was mentioned as being a big issue the last time this class was using something like this. <br />
6.What will we change to improve? <br />
	Talking to the rest of the group outside of meetings. Last week had a snow day that didn't let us meet and communication kind of dropped. We had a meeting and we all only got it ready an hour before which isn't how we should handle things wwhen a missing day comes up. <br />
>>>>>>> 886d1a2de554130db80b5c2fa8482bafa2f6c349
</details>
