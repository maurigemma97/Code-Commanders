<details><summary>Nicholas Acuncius</summary>
1.Issues completed in Sprint? <br />
        Issue #54, #74, #75. Issue #54 which was make the different bar graphs based on the selected violations from the drop menu. Issue #74 which was to refine the pie charts so that they will be generated based on the selected option from the drop menu. Issue #75 which was to make the generate button work after the drop menu option(s) is selected.  <br />
2.What went well? <br />
        I got the axis titles to work for the graphs. I able t0 make the functions to get the data for the labels and data points for the graphs was able to be accomplished using MongoDB's aggregation functionality. All the drop menus had the selections be mapped out which required some logic tinkering.<br />
3.What didn't go well? <br />
        Currently the charts do not have the ability to select based on start and end dates (as of these Issues), otherwise everything has gone well. <br />
4.What have I learned? <br />
        How to learn some of the MongoDB's aggregation within MongoDB Realm and using a RNG for integers.<br />
5.What Still Puzzles You? <br />
        I still want to get a loading screen for when the graphs haven't been recieved and generated yet, so currently if there is a delay in graph generation, the screen will say that there is no data yet. <br />
6.What will we change to improve? <br />
        Find a way to make a loading screen so that graph generation looks better and get the time frames to work with the graphs.<br />
</details>

<details><summary>Jackson Conrad</summary>
1.Issues completed in Sprint? <br />
        Issue #73. This issue was to research more in depth of how Firebase works and to try to get some basic functions working. <br />
2.What went well? <br />
        I have reached an intermediate level of understand of how Firebase works. I can download pictures and display them. <br />
3.What didn't go well? <br />
        I am not sure how to implement the pictures into the actual app. <br />
4.What have I learned? <br />
        How to download/upload images to Firebase.<br />
5.What Still Puzzles You? <br />
        Implementing the images into the application. I have the files but I do not know the syntax of getting them to appear to the screen. <br />
6.What will we change to improve? <br />
        Talk with the team who does know how this language/framework works so they can assist in displaying the images. <br />
</details>

<details><summary>Caleb Courtney</summary>
1.Issues completed in Sprint? <br />
        Issue #77. I fixed much of the formatting with in the app to have a cleaner way to change the date for all the different parts that use it as well as get it working with the backend. <br />
2.What went well? <br />
        Changing the calander from another page to the same page was easy and the moving the data to the schema I made last time was finished. <br />
3.What didn't go well? <br />
        Adding it to some of the other functions created this sprint. <br />
4.What have I learned? <br />
        How Ionic  handles the date time picker as well as handling the new string within all the already created functions.<br />
5.What Still Puzzles You? <br />
        The best way to implement stuff I'm creating in the week to other peoples work throughout the week. <br />
6.What will we change to improve? <br />
        We are still working to try and finish the day before so we can work on things at the same time at least during demo week I was able to get last weeks works working with what I added. <br />
</details>

<details><summary>Matt Aurigemma</summary>
1.Issues completed in Sprint? <br />
        Issue #76 I was able to complete which was just me testing the user location feature to feel out how it responded to me driving around. In doing that, I was not able to complete issue #65. <br />
2.What went well? <br />
        When driving around It was able to respot my location at times if I stopped for a little while <br />
3.What didn't go well? <br />
        The main issue that contributed into me not being able to figure out issue #65 was that I am unsure if the issue of not being able to track my movements consistently had to do with the fact I was testing the location from my computer, or if I need to implement some time interval whcih can cause it to update more rapidly if implemented correctly. <br />
4.What have I learned? <br />
        I have learned that location services can be a bit tricky to mess with and that tracking a route can't really happen until I feel confident that my location is consistently being updated. I noticed at times it would put me in the correct spot , but sometimes it would just put me on wooster street when I stopped.<br />
5.What Still Puzzles You? <br />
        My main concern again is that I'm not sure if I ran into issues because I was on a laptop, or if the feature actually needs to be improved. This probably should have been tested before I committed to tracking a route, but I'm hoping I will get a better understanding on what I need to do going forward once I test on an android or Iphone. If either of those has an issue with updating my location, then I will get a better idea that the code probably needs to be enhanced a bit in some way. If either of those has no problems updating my location as I drive however, then I will get a better understanding that the problem is most likely my laptop.  <br />
6.What will we change to improve? <br />
        What I need to change going forward is to organize my issues better. This is an issue I should have made a lot sooner, and definitly one I should have made before committing to tracking a route that is taken. <br />
</details>

<details><summary>Evan Buchanan</summary>
<b>1. Issues completed in Sprint? </b><br />
        Issue #78 Created violations get saved to database<br /><br />
<b>2. What went well? </b><br />
        I was able to figure out what changes I needed to make throughout the applciations files to let me use some of the functions that the backend folks created. I am now able to add violations to the database from the violations creation page, also able to update basic info on violations.<br /><br />
<b>3. What didn't go well? </b><br />
        It was super confusing to find out what way we are actually using to use functions with the database because we still had old information in the discord that I was first trying to go off of.<br /><br />
<b>4. What have I learned? </b><br />
        I learned how to use our database, which is going to be what im working with the most in the coming weeks so it is really nice I have it down now.<br /><br />
<b>5. What Still Puzzles You? </b><br />
         I would not ssay there is really anything I am puzzled by after this week, just some stuff I need to look more into for next weeks sprint.<br /><br />
<b>6. What will we change to improve? </b><br />
        I need to make the app update info on the marker popups, it only updates some of the stuff on the popup correctly. <br /><br />
</details>

<details><summary>Jaxsin Power</summary>
<b>1. Issues completed in Sprint? </b><br />
        Issue #61 Add Mark violationLocation marker functionality map.<br />
<b>2. What went well? </b><br />
        I was able add the entirety of needed functionality for adding and removing violation location searhc markers on the map. Outside of some periodic setbacks, work
        towards this goal moved relatively smoothly.<br /><br />
<b>3. What didn't go well? </b><br />
        Due to time limitations I was unable to get database access working properly, and as such the current vioLocation markers are hardcoded. While I think I will be able to get this functionality working in little time, I nonetheless unfortunaely was unable to reach it before this Sprint's deadline.</b><br />
<b>5. What Still Puzzles You? </b><br />
         Mapping data from the database to the homepage markers is still an issue, though one I think I will be able to solve fairly soon..<br /><br />
<b>6. What will we change to improve? </b><br />
        With other projects now out of the way, I can focus more on my work on this project and try to make up for falling behind in terms of tangible improvements to the     
        codebase. I will attempt to use what I've learned here for violation markers and try to use it for other features such as route mapping for the next demo.<br /><br />
</details>

