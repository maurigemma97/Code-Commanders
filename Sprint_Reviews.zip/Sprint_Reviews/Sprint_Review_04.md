<details><summary>Caleb Courtney</summary>
1.Issues completed in Sprint? 
	Issue #38, made more function calls throughout the other pages created by the front end team.<br />
2.What went well? 
	Having things running correctly and the way I wanted worked out fine. Working with other parts of the app to pass the information needed for each function was also solved.<br />
3.What didn't go well? 
	Figuring out react syntax took me longer then it needed to because looking up the syntax isn't as universal as other programming languages as well as looking up Ion syntax sometimes gets me the incorrect example. <br /> 
4.What have I learned? 
	I learned that having the login only on one page doesn't work as well as import realm needs to be on every page a function will be called. I learned how to take input from a text box and pass it to a onclick button then pass it through a function. Here is an example to show how different it ended up being from other languages. <IonButtons onClick={() => getAll(text)}>Add Address</IonButtons><br />
5.What Still Puzzles You? 
	Making sure the object I'm passing is the correct type. In the function I had to set it to text to have it go through other wise it would say incorrect object. At the top however const [text, setText] = useState<string>(); this would have me believe that this is a string type, but passing it through it is not.<br />
6.What will we change to improve? 
	Making sure we have everything we need to start putting the correct functions in the correct place. Right now I created a test button to have an example for the demo which is not what we will have it like later. We need to go through and decide on what we want every page to have and do for the user.<br />
</details>
<details><summary>Jackson Conrad</summary>
1.Issues completed in Sprint?
	Issue #34, I created more functions to be used by the front end team.<br />
2.What went well? 
	These functions all went smoothly. They work as expected and were simple to implement.<br />
3.What didn't go well? 
	Getting Date data types to work correctly. I had to change them to strings and now we just need to ensure that the front end team is aware of this. I also was having trouble with getting an object passed into a function as an argument.<br />
4.What have I learned? 
	That MongoDB's Date data type is rather finicky and I will need to work on it to make our database complete.<br />
5.What Still Puzzles You? 
	How to pass in an object as an argument to a function. As well as the Date data type in MongoDB.<br />
6.What will we change to improve? 
	Ask the team their thoughts on how to go about the date situation. Also, do more research on how to get an object passed through to a function.<br />
</details>
<details><summary>Evan Buchanan</summary>
1.Issues completed in Sprint?
	Issue #37, Create a violation.<br />
2.What went well? 
	I was able to find a way to create a violation and from that add a marker on to the map to show where the violation took place.<br />
3.What didn't go well? 
	It was absolute insanity for some reason figuring out how to pass data inbetween pages, also trying to figure out how to use mapbox gl to do forward geocoding is complex and I need to learn much more about it.<br />
4.What have I learned? 
	I learned how to pass data inbetween pages, which is going to be super important going forward with the next issues we will be working on. I learned a lot more about how geolocation information is held in mapbox and how it can be manipulated.<br />
5.What Still Puzzles You? 
	Using mapbox gl to do forward geocoding, giving the api an address and getting it to pull coordinates out from the map was super not easy to do and I could not find many helpful resources for surprisingly.<br />
6.What will we change to improve? 
	After I figure out how to use an address to plot the marker on the map I will switch the add violations menu to take an address instead of requiring that the user type in coordinated, which is not optimal.<br />
</details>

<details><summary>Nicholas Acuncius</summary>
1.Issues completed in Sprint? 
	Issue #36, routes to a new page that will list the locations and some of their details that have violations only in over_occupancy<br />
2.What went well? 
	The basic way the function is working is good along with getting the call to work and saved into a useState<br />
3.What didn't go well? 
	Getting to map off of the useState was difficult as the useState kept on staying at a never[] and this kept making it impossible to look at the different objects related to each location. Also use queries and props in relation to the http.get is not working well though that is not used in this sprint<br /> 
4.What have I learned? 
	I learned about some of ionic's functionality with buttons and some of the small differences between JS and TS (specifically the useState creating an empty array. Using the ionic's HTML to display the details from the map.<br />
5.What Still Puzzles You? 
	Using props and getting the queries at the end of the endpoint link to be able to be used in ionic<br />
6.What will we change to improve? 
	Look more into how props work in TS and compare the different between http endpoints and the APP-ID realm access.<br />
</details>
<details><summary>Matt Aurigemma</summary>
1.Issues completed in Sprint?<br />
        Issue #39 and Issue #35, created a nav bar to zoom in and out and a directions log to create a new route<br />
2.What went well?<br />
	Creating the navigation bar wasn't too bad because the functionality of if it was already imported previosly<br />
3.What didn't go well?<br />
	Creating the directions tab was a pain because it too me awhile to figure out how to get around a certain error when trying to install new objects inside the json package.<br />
4.What have I learned?<br />
	I learned that theirs a lot of different kinds of mapbox API's and their are still some I need to install for the future. <br />
5.What Still Puzzles You?<br />
	I am still confused on how exactly to place the directions tab on a different page since the main page is becoming a bit more cluttered. <br />
6.What will we change to improve?<br />
	I think the placement and size of certain buttons and tabs need to change in order to have a proper proportion to the rest of the map. <br />
</details>

