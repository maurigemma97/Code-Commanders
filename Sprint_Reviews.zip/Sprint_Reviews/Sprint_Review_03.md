<details><summary>Caleb Courtney --Click to expand</summary>
1.Issues completed in Sprint?<br />
	Issue #26, added a template for a button and function in a seperate folder. Have a working in non app function and a connect function that is still being tested.
2.What went well? <br />
	Figuring out syntax in ionic/react is getting better and learning what works with the app, what needs to being installed for things to function is going well. <br />
3.What didn't go well? <br />
	The connection itself isn't as fleshed out and functioning in a way that is ready for a demo next week. <br />
4.What have I learned? <br />
	I have learned what syntax is needed for ionic fab and how a function can fit into the the code without having errors pop up during run time. Trying to use the atlas method doesn't work and will cause errors during run time. Realm connection doesn't cause any run time errors. <br />
5.What Still Puzzles You? <br />
	I don't know how to use the realm functions we wrote in the app itself. Even with the app not having errors when using the connection function have that then bring back information or wrtie information is still being worked on.<br />
6.What will we change to improve? <br />
	Using the correct parts of mongodb resourse to connect the right app. For clearification there are web SDKs and react SDKs that all work differently solving which we need to use has taken up the most of my time and getting the correct resource from the start will improve the amount of working being done significantly. <br />
</details>


<details><summary>Evan Buchanan --Click to expand</summary>
1. Issues completed in Sprint?<br />
	Issue #24 Add a back button to the settings menu.<br />
	Issue #25 Have the map follow the user's geolocation.<br />
	Issue #27 Add a button to center the view on the user.<br />
2. What went well? <br />
	Adding the back button to the settings menu was even easier and quick then I expected it to be, I didnt have to mess around with finding icons and messing with formatting, there is just a sepcific back-button component you can toss in.<br />
    After looking through some online resources I was able to find a resource that nicely explained how to add geolocation into mapbox and have the user marked on the map.<br />
	The button is able to work nicely to center the screen on the user whenever the user moves the map of of themselves. It looks pretty nice and works well.<br />
3. What didn't go well? <br />
	The button that I was able to add in using mapbox to center the view on the user overlaps with some text that gives current coordinates.<br />
	I was not able to figure out how to get the button exactly where I wanted it at first since it comes as part of mapbox not ionic, it took a lot of time to figure out how to move it to another part of the screen.<br />
4. What have I learned? <br />
	I learned a bunch about using the mapbox api to do various things that I know we will be using soon in upcoming sprints, so having good resources for that stuff ahead of time will help alot. For example being able to use coordinates, addresses, etc. will be super important.<br />
5. What Still Puzzles You? <br />
		I will need to work out a way to move the coordinates text to the middle of the screen so it is not being overlapped by the new button that I created.<br />
6. What will we change to improve? <br />
	The location that the app approximates you at is close, but it could definitely be improved on in order to give a more accurate view of the user's location on the map.<br />

</details>


<details><summary>Nicholas Acuncius --Click to expand</summary>
1. Issues completed in Sprint?<br />
	Issue #16 Photo Storage.<br />
2. What went well? <br />
	I was able to upload a photo in the form of a binary data file onto MongoDB<br />
3. What didn't go well? <br />
	It took a significant amount of time for this to fully execute and there is a lot of bouncing information of how to be able to upload photos. This also only allows for uploading photos.<br />
4. What have I learned? <br />
	I learned how to use Postman and Insomnia to test URL connections, that there are other more common (but more complex) ways to upload photos, and how to use Realm's HTTP endpoints. <br />
5. What Still Puzzles You? <br />
		I don't know how to retrieve and display the uploaded photo and I don't know how I would try to use Realm instead of Atlas. There is GridFS which is used to upload bigger files and that may be needed instead of this current method.<br />
6. What will we change to improve? <br />
	Understand the different steps towards using GridFS and getting the photos to go to and from the front end.<br />

</details>


<details><summary>Matt Aurigemma --Click to expand</summary>
1.Issues completed in Sprint?<br />
	Issue #33 and issue #29. I made new files for the Navigation search button to add an address bar and to also add a back button to the address bar <br />
2.What went well? <br />
	Making the button page wasn't too bad and their were a lot of resources on google to help me. <br />
3.What didn't go well? <br />
	Took me some time to figure out how to get the back button to link to the navigation button, and then trying to have geolocate work for addresses that are being typed in. <br />
4.What have I learned? <br />
	I have learned that ionic has a lot of different design options as to how you want to implent thing like a search button, menu, etc. <br />
5.What Still Puzzles You? <br />
	I am still confused on how you get the search bar to not only understand where an address is, but to make suggestions as you fill in an address. <br />
	For the next sprint those 2 things will most likely be my main objective since that will be a pivotal feature in the application. <br />
6.What will we change to improve? <br />
	I think overall the geolocation is a work in progress. It seems like we have the basic look down at this point, but now is the time to start adding more <br />
	behind the scenes features such as user tracking, routes, ect. <br />
</details>

<details><summary>Jackson Conrad --Click to expand</summary>
1.Issues completed in Sprint?<br />
	Issue #28, added functions for the Realm app to be able to have more functionality.<br />
2.What went well? <br />
	I got a few functions loaded into Realm to help the frontend team have more access.<br />
3.What didn't go well? <br />
	The database is exhibiting weird behavior that I was not expecting and do not know how to fix.<br />
4.What have I learned? <br />
	The atlas/realm connection has quirks that I need to do more research on before it is ready to have the frontend team do queries on the <br />
	database.
5.What Still Puzzles You? <br />
	I don't know how to use the realm functions we wrote in the app itself. These functions seem to be hidden from outside programs and can <br /> only be ran internally, this will take more research.
6.What will we change to improve? <br />
	Doing more research on how MongoDB works. The three apps inside of the main program are what is puzzling me and the team and I will work <br /> together this week to figure out what we need to do to get everything running smoothly before the demo next week.
</details>

<details><summary>Jaxsin Power --Click to expand</summary>
1. Issues completed in Sprint?<br />
	Issue #30: Add filter menu for violation location sub-button <br />
	Issue #31: Add filter menu for route sub-button <br />
	Issue #32: Add filter menu for graph sub-button <br />
2. What went well? <br />
	Adding additional pages for menus for the violation location, route, and graph sub-buttons porved to be quite simple to not only create, but also connect to the home page via 	
	the respective buttons. Adding the basic selection options for each menu also proved to be rather straightforward. <br />
3. What didn't go well? <br />
	Adding advanced fucntionality to the menus (such as only allowing certain options to be availalbe when another particular option are selected) proved to be far more frustrating 
	and hard to deal with than I had anticipated. The additon of functions and methods will be needed for this more complicated functionality, though my ealy attempts of adding 	
	these methods did not work to my satisfaction. <br />
4. What have I learned? <br />
	I have learned more about the various Ionic tools at my disposal, as well as how to implement them in various pages for the most ideal functionality and selection options for 
	the user. I have also learned more about implementing functions and methods into TypeScript and JavaScript.
5. What Still Puzzles You? <br />
	My ability to create and implement functions and methods for TypeScript and JavaScipt is still not at a level that I find satisfactory, especially considering as I have been 
	currently unable to implement said methods for more advanced functionality for menu options. <br />
6. What will we change to improve? <br />
	I will need to continue working on the methods and funcions needed for the violation location, route, and graph menus so the user has a more straightforward and easily 
	usable settings filter that will not result in errors when acessing the database. <br />
</details>

</details
