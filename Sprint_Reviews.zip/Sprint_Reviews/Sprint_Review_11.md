<details><summary>Nicholas Acuncius</summary>
1.Issues completed in Sprint? <br />
        Issues 99-101 and 103. Issue 103 was to get documented in the app MongoDB Realm's functions and webhooks. Issue 99 was to create a way to look up a documnet's coordinates based off of the document's address. Issue 100 was to make some base functions for creating, pulling, and deleting routes. Issue 101 was to shift from using props in the charts to using useHistory() <br />
2.What went well? <br />
        All the functions were made easily and are all tested to work inside the app. Documentation was lengthy, but no problems, and to get useHistory implemented required some slight modifications to the props statements <br />
3.What didnt go so well? <br />
        Getting useHistory() to work well in the app was troubling and trying to use the back button when the charts were generated required two pushes.   <br />
4.What have I learned> <br />
        Creating a button similar to the back button that ionic has natively and how to force a page reload<br />
5.What still puzzles you? <br />
        How I could do a single time page reload and why ionic native back button required a page refresh before it would go back to the charts-menu mage <br />
6.What will we change to improve? <br />
        If this solves the problem of iPad black screening, then useHistroy() will be implemented into Violation-menu, otherwise a new solution needs to be determined. Charts-menu may need to be reformated to make it appear more user friendly<br />
</details>


<details><summary>Evan Buchanan</summary>
1. Issues completed in Sprint? <br />
        #104 - Clear Add and Edit pages on form completion<br />
        #105 - Resolve All Button in Edit<br />
        #106 - Add Delete All Button to Edit<br />
        #107 - Edit Button on Preoprty Popup Menu<br />
2. What went well? <br />
I was able to get 4 of the issues I wanted to do this week done, they were fairly easy to figure out and did not take much time luckily.<br /><br />
4.What have I learned> <br />
        I learned more about tweaking page contents to do what I want and working with html, embedding functions into html objects to make them launch functions when interacted and much more.<br /><br />
5.What still puzzles you? <br />
        I am having an issue with adding the add button funcitonality into the popup menu so I will need to do some work with the fellas and get their opinions some more.<br /><br />
6.What will we change to improve? <br />
        Some changes could be made to autoload some of the information into the edit screen when opened from the popup menu, this would make things more intuitive for the user.<br /><br />
</details>

<details><summary>Caleb Courtney</summary>
1.Issues completed in Sprint? <br />
        Issues 102 and 108. Issue 102 was getting email validation to work with my email function. Issue 108 was testing css changes trying to make reading the show violation section easier to look at with a quick glance. <br />
2.What went well? <br />
        The function to check if it passes a simple email is the correct syntax was easy. The css file wasn't hard either and can be changed as we work to make it look how the whole group wants. <br />>
4.What have I learned> <br />
        How to import style sheets to ionic pages and how you can add multiple functions to a input so the background is always being checked.<br />
5.What still puzzles you? <br />
        Getting a button to enable and disable during run time. I've looked up  so much on the subject and I could not find anything specific to Ionic React. <br />
6.What will we change to improve? <br />
        Stopping some research early to get more other work done when I can ask assistance with smaller problems later.<br />
</details>

<details><summary> Matt Aurigemma</summary>
1. Issues completed in Sprint? <br />
        I was not able to complete Issue #97. I ran into issues with either the map not loading, or just nothing happening<br/>
        So im not totally sure what was happening.
2. What went well? <br />
        I was able to get lucky and find some posts relating to the issue I wanted to accomplish. <br />
3. What didn't go so well?
        Although I was able to find articles relating to my issue, I had a hard time finding anything with exact coorelation <br />
        with mapbox api.
4.What have I learned> <br />
        I have learned more about geojson and how it operates, and also how lines can be generated with coordinates. <br />
5.What still puzzles you? <br />
        I am still very confused with how to plot a point with my current location, and then subsequetly creating a linestring <br />
        with those points that have been planted.
6.What will we change to improve? <br />
        I will try my best to implement the feature come presentation day, but at the very worst I would like to come close so <br />
        Another group can possibly take off where I left off with this issue. Also, I still want to try and clean up some <br />
        Of the buttons for ios use since their have been some minor issues with that. <br />
</details>

<details><summary>Jaxsin Power</summary>
1. Issues completed in Sprint? <br />
        I was able to complete the following issues during this sprint: <br />
                Issue #109 - Add custom violation location markers <br />
                Issue #110 - Fix 'sticky marker' bug <br />
                Issue #111 - Track and record user's current date and time <br />
                Issue #112 - Track and record user's current date and time <br />
2. What went well? <br />
        Compared to last week where getting sick heavily hampered my progress, I made it my duty to make up for it by getting more done this week. And for the most part, 
        while the tasks took a while to complete as a whole, implementing said features and functionalities went surprisingly smooth, where moments where I got stuck were 
        relatively short.<br />
3. What didn't go so well?<br />
        There honestly isn't really anything that didn't go well this week. I was able to reach my goals without much struggle. <br />
4. What have I learned> <br />
        I learned more about manipulating and accessing data within the Mapbox GL API, be that the address of any area clicked, or the precise geocoordinates of a user at any 
        given time. I also learned how to accuratly measure duration of time and repeatedly call functions at timed intervals using JavaScript, something I wasn't 
        particularly aware of before. <br />
5. What still puzzles you? <br />
        With now being able to tap the map to get an adress, this can be used to automatically search the database and allow for the user to add a violation or edit an 
        existing violation without needing the seperate buttons currently on the map used for searching for an address each time. That being said, I am a it unsure of how to  
        achieve this goal without heavily restructuring the add/edit violation pages that are already there/ that being said I intend to figure it out so that a the user has 
        a more inuitive experience when using the app.<br >
6. What will we change to improve? <br />
        I will take time to learn how to write the code needed for the desired functionality mentioned above and use what I've already learned to continue to refine the 
        project for the final sprint and demonstration.<br />
</details>

<details><summary>Jackson Conrad</summary>
1. Issues completed in Sprint? <br />
        I completed issue #98 this sprint.<br />
2. What went well? <br />
        I was able to get a majority of the documentation added to the repository. <br />
3. What didn't go so well?<br />
        There is still some pages and functions that need to have documentation added to the repository for future programmers use.<br />
4.What have I learned> <br />
        The ins and outs of the parts of the project that I did not directly contribute to. <br />
5.What still puzzles you? <br />
        N/A.<br />
6.What will we change to improve? <br />
        I will continue to add documentation this week to ensure that the next group of developers has everything they need. <br />
</details>
