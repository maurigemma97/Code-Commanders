<details><summary>Caleb Courtney</summary>
1.Issues completed in Sprint? <br />
	Issue #44, which was to see if I could use a realm function to upload images to the database and return images from the database.<br />
2.What went well? 
	We had a lot of the supporting work done and a bit of research done on how to upload. Literally doing it wasn't impossible and was done semi quickly.<br />
3.What didn't go well? <br />
	Mongodb isn't really made for handleing such large files. It turned out that most my research ended up being alternatives to doing that as well as other ways of doing that without the use of realm. Realm as pervious research has show is the best way for apps to work with the database, however it doesn't support large files esspecially in the free version. <br /> 
4.What have I learned? <br />
	I learned that you can use mongoose and atlas configuration to handle images through mongodb. You can use javascript and JSON specifically to pass the binary data into and out of mongodb but changing the data back and fourth requires functions built into mongodb which are only in atlas.<br />
5.What Still Puzzles You? <br />
	Despite what I found and even said I can't definitively say it's impossible to run during the app run time because it's still unclear if we can use atlas in an app. It also might not be impossible to do with realm I just can't find a solid answer which made this research and testing of different functions and ways of getting this imaging data took my entire work time this week.<br />
6.What will we change to improve? <br />
	I need to be able to check with the mobile app itself I need to make sure I can't use atlas during run time so I can talk to the client about how this might not be the correct resource for what we are trying to accomplish. I should also probably not be so stubbern to find a solution after a few hours because I became unable to get anything presentable done for the group. <br />
</details>
<details><summary>Jackson Conrad</summary>
1.Issues completed in Sprint? <br />
	Issue #43, which was to Look into the graphing functionality of MongoDB.<br />
2.What went well? 
	The user interface was very simple and self explanatory. I was able to intuitively create graphs that show violations statistics.<br />
3.What didn't go well? <br />
	N/A. <br /> 
4.What have I learned? <br />
	I learned how to use the MongoDB suite to create graphs on their website.<br />
5.What Still Puzzles You? <br />
	How to export these graphs to our screen for the application.<br />
6.What will we change to improve? <br />
	Learn how to get these graphs out to the application to fulfill a requirement of our customer. <br />
</details>
<details><summary>Nicholas Acuncius</summary>
1.Issues completed in Sprint? <br />
	Issue #41, Refine how the violation lookup will work.<br />
2.What went well? 
	The violations are able to be brough up accurately and can be generalized (not hyper specific as it was before). Adding in dependencies to MONGODB was simple and using those dependencies was simple. Adjusting the Schema made it easier to accomplish this. Props were able to get transferred between files. <br />
3.What didn't go well? <br />
	MONGODB's native aggregation was not usable for how I was making my algorithm. Finding the good dependencies was tricky as some of then were very slow in execution. Working with filtering the array of objects was tricky as objects and needed a work around. <br /> 
4.What have I learned? <br />
	I learned how to add and use dependencies and use multiple JS functions<br />
5.What Still Puzzles You? <br />
	I got props working, but I feel I got it done in a lazy way, so they are still some trouble. I also don't work well with MONGODB's aggregation functions.<br />
6.What will we change to improve? <br />
	I have a couple experiments to try with props. Props will become something important for us. <br />
</details>
<details><summary>Matt Aurigemma</summary>
1.Issues completed in Sprint? <br />
	Issue #45, Changed some features with the directions to remove ability to move markers, and to remove some uneeded clutter<br />
2.What went well?<br />
	Once changes were made the map still worked smoothly and never had an issue with it being inconsistent.<br /> 
3.What didn't go well? <br />
	I had issue's seeking a solution to changing the markers restriction. I had to look for examples on the web <br />
	in order to find how to properly change the feature to false. mapboxgl had something similiar that I was trying<br />
	but it occured to me that directions had different components<br />
4.What have I learned? <br />
	I have learned that theirs a lot different types of addcontrols that directions api has that the mapboxgl doesnt have <br />
5.What Still Puzzles You? <br />
	I did some research into moving the directions tab to the navigation button, so that is something I need to figure out <br />
	if we decide to keep that button. Also, for the next sprint I think I am going to try and figure out how to actually track<br />
	the route. Unsure at the moment if this service can only be bought with money. <br />
6.What will we change to improve? <br />
	I need to be better about finding resources and finding examples. spent too much time on this task and wasn't exactly <br />
	able to get to any of the heavy hitter questions to solve like route tracing, geofencing BG, etc <br />
</details>

<details><summary>Evan Buchanan</summary>
1.Issues completed in Sprint? <br />
	Issue #42, Create violation uses address instead of coordinate to place marker<br />
2.What went well? 
	I was able to finally get the app to plot a marker on the map after using a MapboxGeocoder control to search for any location using an address./>
3.What didn't go well? <br />
	It was absolutely awful trying to find complete resources for this, partial walkthroughs or outdated information was everywhere and it was brutal to go through.<br /> 
4.What have I learned? <br />
	I have learned how to do more with pulling data from the map itself and parsing that data so it can be used for various things. I learned a bunch about the Geocoder control that mapbox offers so I know a lot of adjustmenmts I can make to our app going forward.<br />
5.What Still Puzzles You? <br />
	The marker will be plotted before the user confirms all of the violation info, I was struggling a way to set it up so it would wait to plot the marker but found no luck quite yet.<br />
6.What will we change to improve? <br />
	I need to find a way to make the application wait to plot the marker until after it returns from the create violations page and the add violation button there was selected.<br />
</details>

<details><summary>Jaxsin Power</summary>
1.Issues completed in Sprint? <br />
	Issue #46: Add conditional checkbox list functionality to VioLocation page <br />
	Issue #47: Add conditional checkbox list functionality to Charts page <br />
	Issue #48: Add conditional checkbox list functionality to Routes page <br />
2.What went well? 
	Once the initial functionality for the conditional checkboxes was created for the VioLocation page, the checkbox lists for the Charts and Routes pages were fairly 
	similar. As such, it wasn't much of an issue when converting the work done for the VioLocation page to also work for the Charts and Routes pages. <br />
3.What didn't go well? <br />
	The process of initially creating the functionality for the checkboxes the first time for the VioLocation page proved to be immensely difficult. While Ionic does support 
	indeterminate checkboxes, which could have fit with my desired functionality for the checkboxes on these lists, there was practically no resources that I could find which 
	would help in implementing this type of checkbox using the React scripting language. As such, I had to recreate the desired functionality from scratch, which in turn took 
	significant time and trial and error to workthout errors. Merging my branch 'dev-jax' into main also caused a tremendous amount of unusual errors I could not resolve even 
	after resolving all merge conflicts, which resulted in me needing to create a new branch'dev-jax-2' from main and taking the code I initially wrote from 'dev-jax' and 
	implementing it into this new branch into order to sucessfully merge into main without issue. <br /> 
4.What have I learned? <br />
	I have sucessfully learned the syntax and methodology to write and implement JS functions and methods into React pages. I also learned how to call these functions and 
	methods from elements in the React code.<br />
5.What Still Puzzles You? <br />
	While I learned how to write JS functions and methods into React pages, I am still unsure on how to call to the database from these checkboxs and buttons on the pages.<br />
6.What will we change to improve? <br />
	I will research more sources on implementing MongoDB into React TypeScript pages in order to add the needed violation mapping functionality to these buttons and 	
	checkboxes. <br />
</details>

