<details><summary>Caleb Courtney</summary>
1.Issues completed in Sprint? <br />
	Issue #59 and #60, the first was more generic about understanding the charts in modgodb and the second was trying to embed the same charts into the actual app.<br />
2.What went well? 
	Making a chart in mongodb is pretty easy we did have to set it public and change a few other things and for implementing into the app a simple link to the chart with iframe and the link being found within mongodb.<br />
3.What didn't go well? <br />
	formating seems to be a bit strange and needs tweeking and having not premade charts generate is still being looked at. <br /> 
4.What have I learned? <br />
	Mongodb is really good at making quick easy to understand graphs with the different data already in the database and adding the most current version to the app is pretty is to embed.<br />
5.What Still Puzzles You? <br />
	Figuring out making a none premade chart is something we might want just due to the amount of differnt charts the user might want however if it isn't possible making all of the graphs is possible and can change in app when data in the database changes. <br />
6.What will we change to improve? <br />
	Nothing much this week besides starting so late because of spring break. Luckily this time the newest version should have little enough changes to the app that it shouldn't effect the demo, but because of last time I should have been a bit more careful. <br />
</details>

<details><summary>Nicholas Acuncius</summary>
1.Issues completed in Sprint? <br />
	Issue #51-#53 and #55-#56. #51 was to create an upsert (insert/update) function for adding addresses to database. #52 was to create two functions that can be used to search up documents involving locations within the database. #53 was to create a pie chart off of the current violations data. #55 was to make the line, bar, and pie buttons in the charts menu change based on which is selected and change a value so the correct page will be used. #56 was to make the generate button clickable after a graph type has been selected and router to a correct page<br />
2.What went well? 
	Making the different functions were very easy. Modifying the generate button was very quick. Modifying the graph buttons took longer due to some human logic errors (originally was to just disable which is not selected, but changing the color gave better functionality). Making the pie chart was the most difficult. MongoDB returns numbers as $numberInt or $numberDouble, so those arrays had to be adjusted before displaying. Getting everything for the graph was simple (just deciding on how to currently make the graphs and therefore the functions took some time to decide).<br />
3.What didn't go well? <br />
	Getting the checkbox values to go to the pieChart page took much time. Since when selecting them normally didn't change their check values, so an additional function was needed (decided after much error checking of my own function) <br /> 
4.What have I learned? <br />
	Making charts/graphs using react-chartsjs is very easy and straight forward.<br />
5.What Still Puzzles You? <br />
	On if we should be using MongoDB Charts (in that is can be sent to the app) or to continue using react-chartsjs. If the charts menu should be changed to make graph generation for malleable.<br />
6.What will we change to improve? <br />
	Potentially the graphs menu if it makes the most sense. Otherwise nothing else. <br />
</details>

<details><summary>Matt Aurigemma</summary>
1.Issues completed in Sprint? <br />
	I completed Issue #49 which was to make a boundary around the city of bowling green. <br />
2.What went well? <br />
	I think making the boundary wasn't super hard being familiar with React now at this point and some of the mapbox api. <br />
3.What didnt go well? <br />
	For some reason whenever I made a boundary, the map would instantly freeze whenever I tried to move around. This took me quite a solid amount of time <br />
	to figure out since I didn't know there was another way to make the boundary. Once I found an outside source to help guide me, I was able to have it so <br />
	the map wouldn't freeze everytime I zoomed in and out. <br />
4.What have I learned? <br />
	I have learned that theirs mutiple different ways to go about implementing something, as I found out through this boundary creation. <br />
5.What still puzzles you> <br />
	I am still confused how I am able to create a pop up when I click the navigation button. I want it to display the directions feature, but I havent <br />
	had much luck with it so far. <br />
6.What will we change to improve? <br />
	I am hoping I can figure out that pop up display soon and add tracking of a route in time for the next sprint. tracking the route may need to be done by <br />
	Sprint 8 potentially since it doesn't seem so cut and dry to do. <br />
</details>

<details><summary>Evan Buchanan</summary>
<b>1. Issues completed in Sprint?</b> <br />
	Issue #58 Add clickable markers that display information about property on click<br />
<b>2. What went well? </b><br />
	It was pretty quick setting up the markers on the map to be able to be interacted with by adding a click event during therir creation. Creating the menu that would appear on click was also decently fast and looks alright for now.<br />
<b>3. What didn't go well? </b><br />
	I still was dealing with the same issue from last sprint where pulling the information from pages and the map and working together. Some of the info in the popup is prety much placeholder for now but it lays a good foundation.<br /> 
<b>4. What have I learned? </b><br />
	Learning how to make popups like that is super useful, also I learned more about working with html and the different styling options available.<br />
<b>5. What Still Puzzles You? </b><br />
	Unfortunately the same thing as last week is still a puzzle to me, getting geolocation information stored and able to be used correctly between the pages.<br />
<b>6. What will we change to improve? </b><br />
	Defeinetely need to update the appeareance of some stuff when we have time but core functionality is probably most important at this point anyway.<br />
</details>

<details><summary>Jackson Conrad</summary>
1.Issues completed in Sprint? <br />
	This week I did not end up completing any issues.<br />
2.What went well? 
	I did not end up working very much on the project during this sprint. I had gotten consumed with other tasks (honeymoon, etc).<br />
3.What didn't go well? <br />
	See #2. <br /> 
4.What have I learned? <br />
	See #2. <br />
5.What Still Puzzles You? <br />
	See #2. <br />
6.What will we change to improve? <br />
	From now on there will not be any more distractions (hopefully) to keep me from being able to spend all the necessary time on this project. I have completed one of my other classes that was a seven week course and taken the vacation I had been planning. <br />
</details>

<details><summary>Jaxsin Power</summary>
1.Issues completed in Sprint? <br />
	I sworked on Issue #61: Mark violations from vioLoctaion search to map , but unfortunately was unable to finish it by the end of the sprint.<br />
2.What went well? 
	I was able to determine how to add additional markers to the map.<br />
3.What didn't go well? <br />
	The major potion that proved to be diffcult was getting information from the database that was needed to make the additonal violation markers for showcasing violations 	across the city. Multiple attempts to access the database proved to be errorenous, and other solutions proved to break the intitial map render. <br /> 
4.What have I learned? <br />
	At the very least, I have narrowed down potential soltuions that proved to be unworkable. And since I've already sigured out how to make additional markers, adding 	
	markers to the map map should be a nonissue once I can properly access and parse data from the database.<br />
5.What Still Puzzles You? <br />
	I still need to figure out how to parse data from the database in order to properly map violations on the map. <br />
6.What will we change to improve? <br />
	I will be researching and experiemnting heavily on database access, so that I can figure out the proper way to get and parse the information I need, not only for 		
	violation location markers, but for future goals such as mapping routes.<br />
</details>
